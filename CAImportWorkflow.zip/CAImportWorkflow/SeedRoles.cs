﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using CAImportWorkflow.Data;
using CAImportWorkflow.Data;
using CAImportWorkflow.Models;

namespace CAImportWorkflow
{
    public static class SeedRoles
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new ApplicationDbContext(serviceProvider.GetRequiredService<DbContextOptions<ApplicationDbContext>>()))
            {
                string[] roles = new string[] { "Admin", "User", "QC", "Supervisor", "Manager" };
                string[] thread = new string[] { "PreAlert", "HBL Processor", "Invoicing" };

                var usersWithProperties = new List<UserWithProperties>
                {
                    new UserWithProperties
                    {
                        UserName = "Supervisor",
                        Wnsid = "111111",
                        CitrixId = "Supervisor",
                        DocContact = "Supervisor",
                        IsActive = true,
                        IsDelete = false,
                        IsLDAP = true,
                        IsReset = false
                    },
                    new UserWithProperties
                    {
                        UserName = "User1",
                        Wnsid = "222222",
                        CitrixId = "User1",
                        DocContact = "User1",
                        IsActive = true,
                        IsDelete = false,
                        IsLDAP = true,
                        IsReset = false
                    },
                    new UserWithProperties
                    {
                        UserName = "User2",
                        Wnsid = "333333",
                        CitrixId = "User2",
                        DocContact = "User2",
                        IsActive = true,
                        IsDelete = false,
                        IsLDAP = true,
                        IsReset = false
                    },
                    new UserWithProperties
                    {
                        UserName = "User3",
                        Wnsid = "444444",
                        CitrixId = "User3",
                        DocContact = "User3",
                        IsActive = true,
                        IsDelete = false,
                        IsLDAP = true,
                        IsReset = false
                    },
                    new UserWithProperties
                    {
                        UserName = "Tusharp",
                        Wnsid = "139289",
                        CitrixId = "Tusharp",
                        DocContact = "Tusharp",
                        IsActive = true,
                        IsDelete = false,
                        IsLDAP = true,
                        IsReset = false
                    },
                    new UserWithProperties
                    {
                        UserName = "RahulW",
                        Wnsid = "275401",
                        CitrixId = "RahulW",
                        DocContact = "RahulW",
                        IsActive = true,
                        IsDelete = false,
                        IsLDAP = true,
                        IsReset = false
                    },
                    new UserWithProperties
                    {
                        UserName = "VaibhavA",
                        Wnsid = "310475",
                        CitrixId = "VaibhavA",
                        DocContact = "VaibhavA",
                        IsActive = true,
                        IsDelete = false,
                        IsLDAP = true,
                        IsReset = false
                    },
                    new UserWithProperties
                    {
                        UserName = "RavindraM",
                        Wnsid = "326068",
                        CitrixId = "RavindraM",
                        DocContact = "RavindraM",
                        IsActive = true,
                        IsDelete = false,
                        IsLDAP = true,
                        IsReset = false
                    },
                    new UserWithProperties
                    {
                        UserName = "HimanshuA",
                        Wnsid = "418450",
                        CitrixId = "HimanshuA",
                        DocContact = "HimanshuA",
                        IsActive = true,
                        IsDelete = false,
                        IsLDAP = true,
                        IsReset = false
                    },

                };

                // Process roles
                foreach (string role in roles)
                {
                    var existingRole = context.Role.SingleOrDefault(r => r.Name.ToLower() == role.ToLower());
                    if (existingRole == null)
                    {
                        context.Role.Add(new Role
                        {
                            Name = role.Trim()
                        });
                    }
                    else
                    {
                        existingRole.Name = role.Trim();
                        existingRole.IsActive = true;
                        existingRole.IsDelete = false;
                        context.Role.Update(existingRole);
                    }
                }

                // Process threads
                foreach (string t in thread)
                {
                    if (!context.ThreadMaster.Any(r => r.Name == t))
                    {
                        context.ThreadMaster.Add(new ThreadMaster { Name = t });
                    }
                }

                // Process users
                foreach (var user in usersWithProperties)
                {
                    var existingUser = context.User.SingleOrDefault(u => u.UserName.ToLower() == user.UserName.ToLower());
                    if (existingUser == null)
                    {
                        context.User.Add(new User
                        {
                            Id = Guid.NewGuid().ToString(),
                            UserName = user.UserName,
                            Wnsid = user.Wnsid,
                            CitrixId = user.CitrixId,
                            DocContact = user.DocContact,
                            IsActive = user.IsActive ?? true,
                            IsDelete = user.IsDelete ?? false,
                            IsLDAP = user.IsLDAP ?? true,
                            IsReset = user.IsReset ?? false,
                            NormalizedUserName = user.CitrixId?.ToUpper()
                        });
                    }
                    else
                    {
                        existingUser.Wnsid = user.Wnsid;
                        existingUser.CitrixId = user.CitrixId;
                        existingUser.DocContact = user.DocContact;
                        existingUser.IsActive = user.IsActive ?? true;
                        existingUser.IsDelete = user.IsDelete ?? false;
                        existingUser.IsLDAP = user.IsLDAP ?? true;
                        existingUser.IsReset = user.IsReset ?? false;
                        existingUser.NormalizedUserName = user.CitrixId?.ToUpper();
                        context.User.Update(existingUser);
                    }
                }

                context.SaveChanges();
            }
        }
    }
}
