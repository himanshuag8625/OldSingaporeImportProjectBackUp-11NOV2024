﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace CAImportWorkflow.Data
{
    public partial class FileEntry
    {
        public FileEntry()
        {
            FileActivity = new HashSet<FileActivity>();
            HblEntry = new HashSet<HblEntry>();
        }

        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string? FileNo { get; set; }
        public string? ContainerNo { get; set; }
        public bool? IsEdi { get; set; }
        public string? Pol { get; set; }
        public string? Pod { get; set; }
        public string? FileType { get; set; }
        public string? ProductType { get; set; }
        public string? Hblcount { get; set; }
        public string? ActualHblcount { get; set; }
        public DateTime? EtaAtPod { get; set; }
        public string? MBLFreightTerm { get; set; }
        public string? HBLFreightTerm { get; set; }
        public string? VesselName { get; set; }
        public string? ShippingLine { get; set; }
        public string? Status { get; set; }
        public string? AllocatedTo { get; set; }
        public DateTime? AllocatedDate { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string? CreatedBy { get; set; }
        public virtual ICollection<FileActivity> FileActivity { get; set; }
        public virtual ICollection<HblEntry> HblEntry { get; set; }

        [ForeignKey("CreatedBy")]
        public User User { get; set; }
    }
}
