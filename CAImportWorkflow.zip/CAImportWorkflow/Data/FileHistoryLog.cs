﻿using System.ComponentModel.DataAnnotations.Schema;

namespace CAImportWorkflow.Data
{
    public class FileHistoryLog
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string? FileActivityId { get; set; }
        public string? CurrentStatus { get; set; }
        public string? Comment { get; set; }
        public string? UserId { get; set; }
        public DateTime? StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public DateTime? EnterDate { get; set; }
        public DateTime? EnterStartDate { get; set; }
        public DateTime? EnterEndDate { get; set; }


        [ForeignKey("FileActivityId")]
        public virtual FileActivity FileActivity { get; set; }
        [ForeignKey("UserId")]
        public virtual User User { get; set; }

    }
}
