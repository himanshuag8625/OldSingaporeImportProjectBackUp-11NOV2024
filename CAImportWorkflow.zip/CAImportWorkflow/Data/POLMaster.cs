﻿namespace CAImportWorkflow.Data
{
    public class POLMaster
    {
        public POLMaster()
        {
            PolLocationRelation = new HashSet<PolLocationRelation>();
        }
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string Name { get; set; } = string.Empty;
        public bool IsActive { get; set; } = true;

        public ICollection<PolLocationRelation> PolLocationRelation { get; set; }
    }
}
