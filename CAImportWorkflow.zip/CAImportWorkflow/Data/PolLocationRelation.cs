﻿using System.ComponentModel.DataAnnotations.Schema;

namespace CAImportWorkflow.Data
{
    public class PolLocationRelation
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string LocationId { get; set; }
        public string PolId { get; set; }

        [ForeignKey("LocationId")]
        public LocationMaster LocationMaster { get; set; }

        [ForeignKey("PolId")]
        public POLMaster POLMaster { get; set; }
    }
}
