﻿using CAImportWorkflow.Data;
using CAImportWorkflow.Models;
using ClosedXML.Excel;
using DocumentFormat.OpenXml.InkML;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Linq.Dynamic.Core;
using System.Reflection;
using System.Security.Claims;
using IHostingEnvironment = Microsoft.AspNetCore.Hosting.IHostingEnvironment;

namespace CAImportWorkflow.Controllers
{

    public class AdminController : Controller
    {
        public ApplicationDbContext _ctx;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IHostingEnvironment hostingEnvironment;
        public AdminController(ApplicationDbContext ctx, IHttpContextAccessor httpContextAccessor, IHostingEnvironment _hostingEnvironment)
        {
            hostingEnvironment = _hostingEnvironment;
            _httpContextAccessor = httpContextAccessor;
            _ctx = ctx;
        }
        public IActionResult Index()
        {
            return View();
        }

        [Authorize(Roles = "Admin,Supervisor,Manager")]
        public IActionResult AdminDashboard()
        {
            ViewData["UserName"] = _ctx.User.Where(x => x.IsActive == true).ToList();
            ViewData["ThreadName"] = _ctx.ThreadMaster.Where(x => x.IsActive == true).ToList();
            return View();
        }



        ///Add Location
        ///
        [Authorize(Roles = "Admin,Supervisor,Manager")]
        [HttpGet]
        public IActionResult InsertLocation()
        {
            List<LocationMaster> locationMaster = _ctx.LocationMaster.ToList();
            return View(locationMaster);
        }


        [Authorize(Roles = "Admin,Supervisor,Manager")]
        [HttpGet]
        public IActionResult ShowPolList()
        {
            List<POLMaster> PolMaster = _ctx.POLMaster.ToList();
            return View(PolMaster);
        }


        [Authorize(Roles = "Admin,Supervisor,Manager")]
        [HttpGet]
        public IActionResult CreatePOL()
        {
            ViewData["POLId"] = Guid.NewGuid().ToString();
            return PartialView();
        }

        [HttpPost]
        public JsonResult CreatePOL(POLMaster model)
        {
            if (ModelState.IsValid)
            {
                POLMaster PolMaster = _ctx.POLMaster.Where(x => x.Id == model.Id.Trim()).FirstOrDefault();

                if (PolMaster == null)
                {
                    POLMaster polName = _ctx.POLMaster.Where(x => x.Name == model.Name.Trim()).FirstOrDefault();
                    if (polName == null)
                    {
                        _ctx.POLMaster.Add(
                            new POLMaster
                            {
                                Id = model.Id,
                                Name = model.Name,
                                IsActive = true
                            });
                    }
                    else
                    {
                        return Json("Duplicate");
                    }
                }
                else
                {
                    POLMaster polName = _ctx.POLMaster.Where(x => x.Name == model.Name.Trim()).FirstOrDefault();
                    if (polName == null)
                    {
                        PolMaster.Name = model.Name;
                        _ctx.POLMaster.Update(PolMaster);
                    }
                    else
                    {
                        return Json("Duplicate");
                    }
                }

                _ctx.SaveChanges();
                return Json(ModelState);
            }
            else
            {
                return Json("Something went wrong");
            }
        }


        [Authorize(Roles = "Admin,Supervisor,Manager")]
        [HttpGet]
        public IActionResult EditPOL(string POLId)
        {
            ViewData["PolName"] = _ctx.POLMaster.Where(x => x.Id == POLId).FirstOrDefault();

            return PartialView();
        }

        public JsonResult ActivatePOL(string Id)
        {
            string message = "";
            if (Id != null)
            {
                POLMaster master = _ctx.POLMaster.Where(x => x.Id == Id).FirstOrDefault();
                if (master != null)
                {
                    master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    _ctx.POLMaster.Update(master);
                    _ctx.SaveChanges();
                    message = master.IsActive == true ? master.Name + " POL Activated!" : master.Name + " POL Deactivated!";

                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }
        /// <summary>
        /// Create New Location
        /// </summary>
        /// <returns></returns>

        [Authorize(Roles = "Admin,Supervisor,Manager")]
        [HttpGet]
        public IActionResult ShowPolLocationList()
        {
            var polocationList = _ctx.PolLocationRelation.Select(x => new PolLocationRelation
            {
                PolId = x.POLMaster.Name,
                LocationId = x.LocationMaster.Name,
                Id = x.Id,

            }).ToList();

            return View(polocationList);
        }

        [Authorize(Roles = "Admin,Supervisor,Manager")]
        [HttpGet]

        public IActionResult CreatePolLocation()
        {
            ViewData["PolId"] = new SelectList(_ctx.POLMaster, "Id", "Name");
            ViewData["LocationId"] = new SelectList(_ctx.LocationMaster, "Id", "Name");
            return PartialView();
        }

        [HttpPost]
        public JsonResult CreatePolLocation(string polId, string locationId)
        {
            if (ModelState.IsValid)
            {
                var result = _ctx.PolLocationRelation.Where(x => x.PolId == polId && x.LocationId == locationId).FirstOrDefault();
                if (result == null)
                {
                    _ctx.PolLocationRelation.Add(new PolLocationRelation
                    {
                        PolId = polId,
                        LocationId = locationId,

                    });
                    _ctx.SaveChanges();
                    return Json("Success");
                }
                else
                {
                    return Json("Duplicate");
                }

            }
            else
            {
                return Json("Something went wrong");
            }
        }


        [Authorize(Roles = "Admin,Supervisor,Manager")]
        [HttpGet]
        public IActionResult EditPolLocation(string actcont)
        {
            if (actcont == null)
            {
                return NotFound();
            }
            var pollocation = _ctx.PolLocationRelation.Where(x => x.Id == actcont).FirstOrDefault();
            ViewData["pollocation"] = pollocation;
            ViewData["PolId"] = new SelectList(_ctx.POLMaster, "Id", "Name", pollocation.PolId);
            ViewData["LocationId"] = new SelectList(_ctx.LocationMaster, "Id", "Name", pollocation.LocationId);

            return PartialView();
        }

        [HttpPost]
        public async Task<JsonResult> EditPolLocation(PolLocationRelation model)
        {
            var actcount = _ctx.PolLocationRelation.Where(x => x.Id == model.Id).FirstOrDefault();
            if (actcount != null)
            {
                actcount.PolId = model.PolId;
                actcount.LocationId = model.LocationId;
                _ctx.PolLocationRelation.Update(actcount);

                _ctx.SaveChanges();
                return Json("Updated Successfully..!");
            }
            else
            {
                return Json("Error while processing the request");
            }
        }
        /// <summary>
        /// Create New Location
        /// </summary>
        /// <returns></returns>
        [Authorize(Roles = "Admin,Supervisor,Manager")]
        [HttpGet]
        public IActionResult CreateLocation()
        {
            ViewData["LocationId"] = Guid.NewGuid().ToString();
            return PartialView();
        }


        /// <summary>
        /// Edit Location
        /// </summary>
        /// <param name="locationId"></param>
        /// <returns></returns>
        [Authorize(Roles = "Admin,Supervisor,Manager")]
        [HttpGet]
        public IActionResult EditLocation(string locationId)
        {
            ViewData["LocationName"] = _ctx.LocationMaster.Where(x => x.Id == locationId).FirstOrDefault();

            return PartialView();
        }


        [HttpPost]
        public JsonResult CreateLocation(LocationMaster model)
        {
            if (ModelState.IsValid)
            {
                LocationMaster locationMaster = _ctx.LocationMaster.Where(x => x.Id == model.Id.Trim()).FirstOrDefault();

                if (locationMaster == null)
                {
                    LocationMaster locationName = _ctx.LocationMaster.Where(x => x.Name == model.Name.Trim()).FirstOrDefault();
                    if (locationName == null)
                    {
                        _ctx.LocationMaster.Add(
                            new LocationMaster
                            {
                                Id = model.Id,
                                Name = model.Name,
                                IsActive = true
                            });
                    }
                    else
                    {
                        return Json("Duplicate");
                    }
                }
                else
                {
                    LocationMaster locationName = _ctx.LocationMaster.Where(x => x.Name == model.Name.Trim()).FirstOrDefault();
                    if (locationName == null)
                    {
                        locationMaster.Name = model.Name;
                        _ctx.LocationMaster.Update(locationMaster);
                    }
                    else
                    {
                        return Json("Duplicate");
                    }
                }

                _ctx.SaveChanges();
                return Json(ModelState);
            }
            else
            {
                return Json("Something went wrong");
            }
        }

        /// <summary>
        /// Activate Location        /// 
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        public JsonResult ActivateLocation(string Id)
        {
            string message = "";
            if (Id != null)
            {
                LocationMaster master = _ctx.LocationMaster.Where(x => x.Id == Id).FirstOrDefault();
                if (master != null)
                {
                    master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    _ctx.LocationMaster.Update(master);
                    _ctx.SaveChanges();
                    message = master.IsActive == true ? master.Name + " Location Activated!" : master.Name + " Location Deactivated!";

                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }

        ///Create Activity
        ///
        [Authorize(Roles = "Admin,Supervisor,Manager")]
        [HttpGet]
        public IActionResult InsertActivity()
        {
            ViewData["ActivityId"] = Guid.NewGuid().ToString();
            ViewData["ThreadList"] = _ctx.ThreadMaster.Where(x => x.IsActive == true).ToList();
            ViewData["ActivityList"] = _ctx.ActivityMaster.Select(x => new ActivityMasterModel { Id = x.Id, Name = x.Name, BasedOn = x.BasedOn, Sequence = x.Sequence, IsActive = x.IsActive, ThreadId = x.ThreadId, ThreadName = x.ThreadMaster.Name }).ToList();
            return PartialView();
        }


        [HttpPost]
        public JsonResult InsertActivity(ActivityMasterModel model)
        {
            if (ModelState.IsValid)
            {
                ActivityMaster activityMaster = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.Id == model.Id.Trim() && x.ThreadMaster.IsActive == true && x.IsActive == true).FirstOrDefault();

                if (activityMaster == null)
                {
                    ActivityMaster activityName = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.Name == model.Name.Trim() && x.ThreadMaster.IsActive == true && x.IsActive == true).FirstOrDefault();
                    if (activityName == null)
                    {
                        _ctx.ActivityMaster.Add(
                            new ActivityMaster
                            {
                                Id = model.Id,
                                Name = model.Name,
                                BasedOn = model.BasedOn,
                                ThreadId = model.ThreadId,
                                Sequence = model.Sequence,
                                IsActive = true
                            });
                    }
                    else
                    {
                        return Json("Duplicate");
                    }
                }
                else
                {
                    activityMaster.Name = model.Name;
                    activityMaster.BasedOn = model.BasedOn;
                    activityMaster.ThreadId = model.ThreadId;
                    activityMaster.Sequence = model.Sequence;
                    _ctx.ActivityMaster.Update(activityMaster);

                }

                _ctx.SaveChanges();
                return Json(ModelState);
            }
            else
            {
                return Json("Something went wrong");
            }
        }

        ///Create Activity
        ///
        [Authorize(Roles = "Admin,Supervisor,Manager")]
        [HttpGet]
        public IActionResult InsertThread()
        {
            ViewData["ThreadId"] = Guid.NewGuid().ToString();
            ViewData["ThreadList"] = _ctx.ThreadMaster.Where(x => x.IsActive == true).ToList();
            return PartialView();
        }

        [HttpPost]
        public JsonResult InsertThread(ThreadMaster model)
        {
            if (ModelState.IsValid)
            {
                ThreadMaster threadMaster = _ctx.ThreadMaster.Where(x => x.Id == model.Id.Trim() && x.IsActive == true).FirstOrDefault();

                if (threadMaster == null)
                {
                    ThreadMaster threadName = _ctx.ThreadMaster.Where(x => x.Name == model.Name.Trim() && x.IsActive == true).FirstOrDefault();
                    if (threadName == null)
                    {
                        _ctx.ThreadMaster.Add(
                            new ThreadMaster
                            {
                                Id = model.Id,
                                Name = model.Name,
                                Sequance = model.Sequance,
                                IsActive = true
                            });
                    }
                    else
                    {
                        return Json("Duplicate");
                    }
                }
                else
                {
                    ThreadMaster threadName = _ctx.ThreadMaster.Where(x => x.Name == model.Name.Trim() && x.IsActive == true).FirstOrDefault();
                    threadMaster.Name = model.Name;
                    threadMaster.Sequance = model.Sequance;
                    _ctx.ThreadMaster.Update(threadMaster);

                }

                _ctx.SaveChanges();
                return Json(ModelState);
            }
            else
            {
                return Json("Something went wrong");
            }
        }


        ///Add File
        ///
        [Authorize(Roles = "Admin,Supervisor,Manager")]
        [HttpGet]
        public IActionResult InsertFile()
        {
            ViewData["Location"] = _ctx.LocationMaster.Where(x => x.IsActive == true).ToList();
            ViewData["Pol"] = _ctx.POLMaster.Where(x => x.IsActive == true).ToList();
            return View();
        }

        public JsonResult GetLocationbasedOnPOL(string Id)
        {
            var result = _ctx.PolLocationRelation.Where(x => x.PolId == Id).Select(x => new LocationMaster
            {
                Id = x.LocationId,
                Name = x.LocationMaster.Name

            }).ToList();

            if (result == null)
            {
                return Json("Something went wrong..!");
            }
            else
            {
                return Json(result);
            }
        }

        [HttpPost]
        public IActionResult InsertFile(FileEntryViewModel model)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var act = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.BasedOn == "File" && x.ThreadMaster.Name == "HBL User" && x.ThreadMaster.IsActive == true && x.IsActive == true).ToList();

            var present = _ctx.FileEntry.Where(x => x.ContainerNo == model.ContainerNo).FirstOrDefault();
            if (present == null)
            {
                FileEntry file = new FileEntry
                {
                    FileNo = model.FileNo,
                    ContainerNo = model.ContainerNo,
                    IsEdi = (model.IsEdi.ToUpper() == "TRUE" || model.IsEdi.ToUpper() == "YES" ? true : false),
                    Pol = model.Pol,
                    Pod = model.Pod,
                    Hblcount = model.Hblcount,
                    ActualHblcount = model.ActualHblcount,
                    ProductType = model.ProductType,
                    FileType = model.FileType,
                    EtaAtPod = model.EtaAtPod,
                    Status = null,
                    CreatedDate = model.CreatedDate == null ? DateTime.UtcNow : Convert.ToDateTime(model.CreatedDate).ToUniversalTime(),
                    CreatedBy = null,

                };
                _ctx.FileEntry.Add(file);

                foreach (ActivityMaster activity in act)
                {
                    _ctx.FileActivity.Add(new FileActivity
                    {
                        Id = Guid.NewGuid().ToString(),
                        FileId = file.Id,
                        ActivityId = activity.Id,
                        CurrentStatus = "WIP",
                        Comment = null,
                        UserId = null,
                        EnterDate = DateTime.UtcNow,
                    });
                }
                _ctx.SaveChanges();
                return Json("Success");
            }
            else
            {
                return Json("Container Already present.!");
            }

        }



        [HttpPost]
        public JsonResult GetData(string fileno, string type, string etadate, string container, string status, string thread, string user)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            int totalRecord = 0;
            int filterRecord = 0;
            int hblrecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            _ctx.Database.SetCommandTimeout(120);
            IQueryable<FileEntry> data = _ctx.Set<FileEntry>().AsQueryable();

            //List<FileEntryViewModel> fileEntryViewModels = new List<FileEntryViewModel>();

            //fileEntryViewModels = data.Include(x => x.FileActivity).ThenInclude(x => x.ActivityMaster.ThreadMaster).Select(x => new FileEntryViewModel
            //{
            //    Id = x.Id,
            //    CreatedDate = x.CreatedDate,
            //    FileNo = x.FileNo,
            //    ContainerNo = x.ContainerNo,
            //    IsEdi = x.IsEdi == true ? "Yes" : "No",
            //    Pol = _ctx.POLMaster.Where(y => y.Id == x.Pol).Select(y => y.Name).FirstOrDefault(),
            //    Pod = _ctx.LocationMaster.Where(y => y.Id == x.Pod).Select(y => y.Name).FirstOrDefault(),
            //    FileType = x.FileType == null ? "" : x.FileType,
            //    ProductType = x.ProductType == null ? "" : x.ProductType,
            //    Hblcount = x.HblEntry.Count() != 0 ? x.HblEntry.Count().ToString() : x.Hblcount,
            //    EtaAtPod = x.EtaAtPod,
            //    VesselName = x.VesselName == null ? "" : x.VesselName,
            //    ShippingLine = x.ShippingLine == null ? "" : x.ShippingLine,
            //    ThreadName = _ctx.FileActivity.Where(y => y.FileId == x.Id && y.ActivityMaster.ThreadMaster.IsActive == true && y.ActivityMaster.IsActive == true).OrderByDescending(y => y.EnterDate).Select(y => y.ActivityMaster.ThreadMaster.Name).FirstOrDefault(),
            //    AllocatedTo = _ctx.FileActivity.Where(y => y.FileId == x.Id).OrderByDescending(y => y.EnterDate).Select(y => _ctx.User.Where(z => z.Id == y.UserId).Select(z => z.UserName).FirstOrDefault()).FirstOrDefault(),
            //    Status = _ctx.FileActivity.Where(y => y.FileId == x.Id).OrderByDescending(y => y.EnterDate).Select(y => _ctx.User.Where(z => z.Id == y.UserId).Select(z => z.UserName).FirstOrDefault()).FirstOrDefault() == null ? "Pending" : _ctx.FileActivity.Where(y => y.FileId == x.Id).OrderByDescending(y => y.EnterDate).Select(y => y.CurrentStatus).FirstOrDefault(),
            //    //FileActivities = x.FileActivity.OrderByDescending(x => x.EnterDate).Select(x => new FileActivity
            //    //{
            //    //    ActivityMaster = x.ActivityMaster,
            //    //    CurrentStatus = x.CurrentStatus,
            //    //    UserId = _ctx.User.Where(y => y.Id == x.UserId).Select(y => y.UserName).FirstOrDefault(),
            //    //    EndTime = x.EndTime,
            //    //    EnterDate = x.EnterDate

            //    //}).ToList(),
            //    HblEntry = x.HblEntry,

            //}).ToList();

            //var query = _ctx.Set<FileEntryViewModel>().FromSqlRaw("SELECT * FROM vw_AdminDashboardViewModels").AsQueryable();

            //IQueryable<FileEntryViewModel> SortedData = query.AsQueryable();

            //if (!string.IsNullOrEmpty(fileno))
            //{
            //    SortedData = SortedData.Where(x => x.FileNo == fileno.Trim());

            //}
            //if (!string.IsNullOrEmpty(type) && type != "all" && type != "--select--")
            //{
            //    SortedData = SortedData.Where(x => x.FileType == type.Trim());

            //}
            //if (!string.IsNullOrEmpty(etadate))
            //{
            //    SortedData = SortedData.Where(x => x.EtaAtPod == Convert.ToDateTime(etadate));

            //}

            //if (!string.IsNullOrEmpty(container))
            //{
            //    SortedData = SortedData.Where(x => x.ContainerNo == container.Trim());

            //}

            //if (!string.IsNullOrEmpty(user) && user != "none" && user != "--select--")
            //{
            //    SortedData = SortedData.Where(x => x.CreatedBy == user.Trim());

            //}

            //if (!string.IsNullOrEmpty(status) && status != "none" && status != "--select--")
            //{
            //    SortedData = SortedData.Where(x => x.Status == status.Trim());
            //}

            //if (!string.IsNullOrEmpty(thread) && thread != "none" && thread != "--Select--")
            //{
            //    SortedData = SortedData.Where(x => x.ThreadName == thread.Trim());

            //}
            //if (searchValue == "WIP" || searchValue == "Completed" || searchValue == "Pending" || searchValue == "Query" ||
            //            searchValue == "Received" || searchValue == "UnAllocated" || searchValue == "eta10" || searchValue == "eta12")
            //{
            //    if (searchValue == "eta10")
            //    {
            //        //SortedData = SortedData.Where(x => x.EtaAtPod != null && x.EtaAtPod.Value.Date >= DateTime.Now.Date.AddDays(4) && x.EtaAtPod.Value.Date < DateTime.Now.Date.AddDays(11) && (x.Status != "Completed"));
            //        SortedData = SortedData.Where(x => x.EtaAtPod != null && x.EtaAtPod.Value.Date >= DateTime.Now.Date && x.EtaAtPod.Value.Date < DateTime.Now.Date.AddDays(11) && (x.Status != "Completed"));

            //    }
            //    else if (searchValue == "eta12")
            //    {
            //        //SortedData = SortedData.Where(x => x.EtaAtPod != null && x.EtaAtPod.Value.Date >= DateTime.Now.Date && x.EtaAtPod.Value.Date < DateTime.Now.Date.AddDays(4) && x.Status != "Completed");
            //        SortedData = SortedData.Where(x => x.Status == "Discard");
            //    }
            //    else if (searchValue == "Received")
            //    {
            //        SortedData = SortedData;
            //    }
            //    else if (searchValue == "UnAllocated")
            //    {
            //        SortedData = SortedData.Where(x => x.Status == "WIP" && x.AllocatedTo == null);
            //    }
            //    else
            //    {
            //        SortedData = SortedData.Where(x => x.Status == searchValue);
            //    }
            //}

            //if (searchValue == null || searchValue == "")
            //{
            //    SortedData = SortedData.Where(x => x.Status != "Discard");
            //}

            //if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
            //{
            //    SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            //}
            //else
            //{
            //    sortColumn = "createdDate";
            //    sortColumnDirection = "desc";
            //    SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            //}

            //int hblFilter = 0;
            //foreach (var hblcount in SortedData.ToList())
            //{
            //    hblFilter = SortedData.Sum(x => Convert.ToInt32(x.Hblcount));
            //}
            //var returnObj = new
            //{
            //    draw = draw,
            //    recordsTotal = data.Count(),
            //    recordsFiltered = SortedData.Count(),
            //    data = SortedData,
            //    hblCount = hblFilter
            //};
            //ViewData["TotalHBL"] = hblFilter;

            //var query = _ctx.Set<AdminDashboardViewModel>().FromSqlRaw("SELECT * FROM vw_AdminDashboardViewModels").AsQueryable();

            //if (!string.IsNullOrEmpty(fileno))
            //{
            //    query = query.Where(x => x.FileNo == fileno.Trim());
            //}

            //if (!string.IsNullOrEmpty(type) && type != "all" && type != "--select--")
            //{
            //    query = query.Where(x => x.FileType == type.Trim());
            //}

            //if (!string.IsNullOrEmpty(etadate))
            //{
            //    DateTime etaDateTime = Convert.ToDateTime(etadate);
            //    query = query.Where(x => x.EtaAtPod == etaDateTime);
            //}

            //if (!string.IsNullOrEmpty(container))
            //{
            //    query = query.Where(x => x.ContainerNo == container.Trim());
            //}

            //if (!string.IsNullOrEmpty(user) && user != "none" && user != "--select--")
            //{
            //    query = query.Where(x => x.AllocatedTo == user.Trim());
            //}

            //if (!string.IsNullOrEmpty(status) && status != "none" && status != "--select--")
            //{
            //    query = query.Where(x => x.Status == status.Trim());
            //}

            //if (!string.IsNullOrEmpty(thread) && thread != "none" && thread != "--Select--")
            //{
            //    query = query.Where(x => x.ThreadName == thread.Trim());
            //}

            //if (!string.IsNullOrEmpty(searchValue))
            //{
            //    switch (searchValue)
            //    {
            //        case "eta10":
            //            query = query.Where(x => x.EtaAtPod != null && x.EtaAtPod.Value.Date >= DateTime.Now.Date && x.EtaAtPod.Value.Date < DateTime.Now.Date.AddDays(11) && x.Status != "Completed");
            //            break;
            //        case "eta12":
            //            query = query.Where(x => x.Status == "Discard");
            //            break;
            //        case "UnAllocated":
            //            query = query.Where(x => x.Status == "WIP" && x.AllocatedTo == null);
            //            break;
            //        case "WIP":
            //            query = query.Where(x => x.Status == "WIP" && x.AllocatedTo != null);
            //            break;
            //        case "Received":
            //            // No filtering applied
            //            break;
            //        default:
            //            query = query.Where(x => x.Status == searchValue);
            //            break;
            //    }
            //}
            //else
            //{
            //    query = query.Where(x => x.Status != "Discard");
            //}

            var result = _ctx.Set<AdminDashboardViewModel>()
                            .FromSqlRaw("EXEC usp_GetAdminDashboardViewModels @FileNo = {0}, @Type = {1}, @EtaDate = {2}, @ContainerNo = {3}, @User = {4}, @Status = {5}, @ThreadName = {6}, @SearchValue = {7}",
                                fileno, type, etadate, container, user, status, thread, searchValue)
                            .ToList();

            IQueryable<AdminDashboardViewModel> query = result.AsQueryable();
            if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
            {
                query = query.OrderBy(sortColumn + " " + sortColumnDirection);
            }
            else
            {
                sortColumn = "createdDate";
                sortColumnDirection = "desc";
                query = query.OrderBy(sortColumn + " " + sortColumnDirection);
            }

            // Calculate HBL Count directly
            //int hblFilter = query.Sum(x => Convert.ToInt32(x.Hblcount));
            int hblFilter = query.Sum(x => string.IsNullOrEmpty(x.Hblcount) ? 0 : Convert.ToInt32(x.Hblcount));


            // Retrieve the data as a list only when necessary
            var resultData = query.ToList();

            var returnObj = new
            {
                draw = draw,
                recordsTotal = result.Count(),
                recordsFiltered = resultData.Count(),
                data = resultData,
                hblCount = hblFilter
            };

            ViewData["TotalHBL"] = hblFilter;


            return Json(returnObj);
        }

        [HttpGet]
        public IActionResult GetHblData(string fileId, string hblId)
        {

            var hblEntry = _ctx.HblEntry.Where(x => x.FileGuidId == fileId).Select(x => new HBLDataList
            {
                Id = x.Id,
                Hblno = x.Hblno == null ? "" : x.Hblno,
                FileGuidId = x.FileGuidId,
                IsDap = x.IsDap,
                CreatedDate = x.CreatedDate,
                CreatedBy = x.User.UserName == null ? "" : x.User.UserName

            }).ToList();

            var fileEntryData = _ctx.FileActivity.Include(x => x.ActivityMaster).ThenInclude(x => x.ThreadMaster).Include(x => x.FileEntry).ThenInclude(x => x.User).Where(x => x.FileEntry.Id == fileId && x.ActivityMaster.ThreadMaster.IsActive == true && x.ActivityMaster.IsActive == true).Select(x => new FileDataList
            {
                ActivityId = x.ActivityMaster.Name,
                Comment = x.Comment == null ? "" : x.Comment,
                CurrentStatus = x.CurrentStatus,
                EndTime = x.EndTime,
                EnterDate = x.EnterDate,
                FileNo = x.FileEntry.FileNo == null ? "" : x.FileEntry.FileNo,
                Id = x.FileId,
                UserId = x.FileEntry.User.UserName == null ? "" : x.FileEntry.User.UserName,
            }).OrderByDescending(y => y.EndTime).ToList();


            return Json(new { fileEntryData, hblEntry });

        }


        public JsonResult GetDashboardValue()
        {
            _ctx.Database.SetCommandTimeout(300);
            //List<FileEntryViewModel> fileEntryViewModels = new List<FileEntryViewModel>();

            //fileEntryViewModels = data.Include(x => x.FileActivity).ThenInclude(x => x.ActivityMaster.ThreadMaster).Select(x => new FileEntryViewModel
            //{
            //    Id = x.Id,
            //    CreatedDate = x.CreatedDate,
            //    FileNo = x.FileNo,
            //    ContainerNo = x.ContainerNo,
            //    IsEdi = x.IsEdi == true ? "Yes" : "No",
            //    Pol = _ctx.POLMaster.Where(y => y.Id == x.Pol).Select(y => y.Name).FirstOrDefault(),
            //    Pod = _ctx.LocationMaster.Where(y => y.Id == x.Pod).Select(y => y.Name).FirstOrDefault(),
            //    FileType = x.FileType == null ? "" : x.FileType,
            //    ProductType = x.ProductType == null ? "" : x.ProductType,
            //    Hblcount = x.HblEntry.Count() != 0 ? x.HblEntry.Count().ToString() : x.Hblcount,
            //    EtaAtPod = x.EtaAtPod,
            //    VesselName = x.VesselName == null ? "" : x.VesselName,
            //    ShippingLine = x.ShippingLine == null ? "" : x.ShippingLine,
            //    ThreadName = _ctx.FileActivity.Where(y => y.FileId == x.Id && y.ActivityMaster.ThreadMaster.IsActive == true && y.ActivityMaster.IsActive == true).OrderByDescending(y => y.EnterDate).Select(y => y.ActivityMaster.ThreadMaster.Name).FirstOrDefault(),
            //    AllocatedTo = _ctx.FileActivity.Where(y => y.FileId == x.Id).OrderByDescending(y => y.EnterDate).Select(y => _ctx.User.Where(z => z.Id == y.UserId).Select(z => z.UserName).FirstOrDefault()).FirstOrDefault(),
            //    Status = _ctx.FileActivity.Where(y => y.FileId == x.Id).OrderByDescending(y => y.EnterDate).Select(y => _ctx.User.Where(z => z.Id == y.UserId).Select(z => z.UserName).FirstOrDefault()).FirstOrDefault() == null ? "Pending" : _ctx.FileActivity.Where(y => y.FileId == x.Id).OrderByDescending(y => y.EnterDate).Select(y => y.CurrentStatus).FirstOrDefault(),
            //    //FileActivities = x.FileActivity.OrderByDescending(x => x.EnterDate).Select(x => new FileActivity
            //    //{
            //    //    ActivityMaster = x.ActivityMaster,
            //    //    CurrentStatus = x.CurrentStatus,
            //    //    UserId = _ctx.User.Where(y => y.Id == x.UserId).Select(y => y.UserName).FirstOrDefault(),
            //    //    EndTime = x.EndTime,
            //    //    EnterDate = x.EnterDate

            //    //}).ToList(),
            //    HblEntry = x.HblEntry,

            //}).ToList();

            var fileEntryViewModels = _ctx.Set<AdminDashboardViewModel>().FromSqlRaw("SELECT * FROM vw_AdminDashboardCount").AsQueryable();

            var now = DateTime.Now.Date;
            AdminDashboardModel model = new AdminDashboardModel
            {
                Received = fileEntryViewModels.Count(),
                WIP = fileEntryViewModels.Count(x => x.Status == "WIP" && x.AllocatedTo != null),
                Pending = fileEntryViewModels.Count(x => x.Status == "Pending" || x.Status == "Completed With Query"),
                Completed = fileEntryViewModels.Count(x => x.Status == "Completed"),
                Query = fileEntryViewModels.Where(x => x.Status == "Query").ToList().Count,
                UnTouched = fileEntryViewModels.Count(x => x.Status == "WIP" && x.AllocatedTo == null),
                //eta10 = fileEntryViewModels.Count(x => x.Status != "Completed" && x.EtaAtPod.HasValue && x.EtaAtPod.Value.Date >= now.AddDays(4) && x.EtaAtPod.Value.Date < now.AddDays(11)),
                //eta12 = fileEntryViewModels.Count(x => x.Status != "Completed" && x.EtaAtPod.HasValue && x.EtaAtPod.Value.Date >= now && x.EtaAtPod.Value.Date < now.AddDays(4)),
                eta10 = fileEntryViewModels.Count(x => x.Status != "Completed" && x.EtaAtPod.HasValue && x.EtaAtPod.Value.Date >= now && x.EtaAtPod.Value.Date < now.AddDays(11)),
                eta12 = fileEntryViewModels.Count(x => x.Status == "Discard"),
            };

            return Json(model);

        }


        [Authorize(Roles = "Admin,Supervisor,Manager")]
        public ActionResult Report()
        {
            return View();
        }

        [Authorize(Roles = "Supervisor,Manager,Admin")]
        public ActionResult Reports()
        {
            return View();
        }

        //Report download
        [HttpPost]
        public ActionResult Reports(ReportViewModel report)
        {
            //Main Report file and HBL also activity wise filelevel and hbllevel report
            //DataTable filedt = new DataTable();
            DataTable fileactivity = new DataTable();
            DataTable hblactivity = new DataTable();
            var fileactivtydata = new List<FileReportViewModel>();
            var fileactivtyHistory = new List<FileReportViewModel>();
            var HBLdata = new List<HBLReportViewModel>();
            var HBLHistory = new List<HBLReportViewModel>();
            var getFileActivityStatus = new List<FileActivityStatusList>();
            var getHBLActivityStatus = new List<HBLActivityStatusList>();
            //var fileActivityList = new List<FileActivityLog>();
            UserActivityStatusViewModel userActivityStatus = new UserActivityStatusViewModel();
            //var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var fileActivitys = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.IsActive == true && x.ThreadMaster.Name == "File").OrderBy(x => x.Name).ToList();
            var hblActivitys = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.IsActive == true && x.ThreadMaster.Name == "HBL").OrderBy(x => x.Name).ToList();
            var userList = _ctx.User.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CitrixId).ToList();
            //Adhoc Report 
            DataTable adhoc = new DataTable();
            DataTable adhocHBL = new DataTable();
            DataTable adhocfileActivity = new DataTable();
            DataTable adhochblActivity = new DataTable();
            var startDate = report.start_date;
            var endDate = report.end_date;
            IQueryable<User> udata = _ctx.Set<User>().AsQueryable();
            DataTable dt = new DataTable();
            DataTable dt1 = new DataTable();
            const string ISTTimeZoneId = "India Standard Time";
            var istTimeZone = TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId);


            if (report.start_date != null && report.end_date != null)
            {
                if (report.ReportType == "File")
                {
                    //DataTable dt = new DataTable();
                    dt.Columns.Add("Pod");
                    dt.Columns.Add("EtaAtPod");
                    dt.Columns.Add("Received Date");
                    dt.Columns.Add("ContainerNo");
                    dt.Columns.Add("Pol");
                    dt.Columns.Add("FileType");
                    dt.Columns.Add("ProductType");
                    dt.Columns.Add("Hblcount");
                    dt.Columns.Add("IsEdi");
                    dt.Columns.Add("Activity");
                    dt.Columns.Add("Current Status");
                    dt.Columns.Add("Comment");
                    dt.Columns.Add("UserName");
                    dt.Columns.Add("Pages");
                    dt.Columns.Add("StartDate");
                    dt.Columns.Add("EndDate");
                    dt.Columns.Add("FileNo");
                    dt.Columns.Add("VesselName");
                    dt.Columns.Add("ShippingLine");

                    dt1.Columns.Add("Pod");
                    dt1.Columns.Add("EtaAtPod");
                    dt1.Columns.Add("Received Date");
                    dt1.Columns.Add("ContainerNo");
                    dt1.Columns.Add("Pol");
                    dt1.Columns.Add("FileType");
                    dt1.Columns.Add("ProductType");
                    dt1.Columns.Add("Hblcount");
                    dt1.Columns.Add("IsEdi");
                    dt1.Columns.Add("Activity");
                    dt1.Columns.Add("Current Status");
                    dt1.Columns.Add("Comment");
                    dt1.Columns.Add("UserName");
                    dt1.Columns.Add("Pages");
                    dt1.Columns.Add("StartDate");
                    dt1.Columns.Add("EndDate");
                    dt1.Columns.Add("FileNo");
                    dt1.Columns.Add("VesselName");
                    dt1.Columns.Add("ShippingLine");

                    //dt.Columns.Add("Received Date");
                    //dt.Columns.Add("File Number");
                    //dt.Columns.Add("Container Number");
                    //dt.Columns.Add("SI Cut Off");
                    //dt.Columns.Add("User");
                    //dt.Columns.Add("Activity");
                    //dt.Columns.Add("Status");
                    //dt.Columns.Add("Comment");
                    //dt.Columns.Add("ROE");


                    if (report.DateType == "ReceivedDate")
                    {
                       fileactivtydata = _ctx.FileActivity.Include(x => x.FileEntry).Include(x => x.User).Include(x => x.ActivityMaster).Where(x => x.FileEntry.CreatedDate != null && x.FileEntry.CreatedDate.Value.Date >= startDate.Date &&
                                             x.FileEntry.CreatedDate.Value.Date <= endDate.Date)
                                             .Select(x => new FileReportViewModel
                                             {
                                                 POD = _ctx.LocationMaster.Where(y => y.Id == x.FileEntry.Pod).Select(y => y.Name).FirstOrDefault(),
                                                 ETA = x.FileEntry.EtaAtPod,
                                                 ReceivedDate = x.FileEntry.CreatedDate,
                                                 ContainerNo = x.FileEntry.ContainerNo,
                                                 POL = _ctx.POLMaster.Where(y => y.Id == x.FileEntry.Pol).Select(y => y.Name).FirstOrDefault(),
                                                 FileType = x.FileEntry.FileType,
                                                 ProductType = x.FileEntry.ProductType,
                                                 HBLCount = x.FileEntry.Hblcount,
                                                 IsEdi = x.FileEntry.IsEdi,
                                                 Activity = x.ActivityId != null ? x.ActivityMaster.Name : "",
                                                 Status = x.CurrentStatus != null ? x.CurrentStatus : "",
                                                 Comment = x.Comment != null ? x.Comment : "",
                                                 User = x.UserId != null ? x.User.CitrixId : "",
                                                 Pages = x.Pages,
                                                 StartDate = x.StartTime != null ? x.StartTime : (DateTime?) null,
                                                 EndDate = x.EndTime != null ? x.EndTime : (DateTime?)null,
                                                 FileNo = x.FileEntry.FileNo,
                                                 VesselName = x.FileEntry.VesselName,
                                                 ShippingLine = x.FileEntry.ShippingLine,
                                             }).ToList();
                        fileactivtydata = fileactivtydata.Select(x => new FileReportViewModel
                        {
                            POD = x.POD,
                            ETA = x.ETA.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETA.Value, istTimeZone) : (DateTime?)null,
                            ReceivedDate = x.ReceivedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ReceivedDate.Value, istTimeZone) : (DateTime?)null,
                            ContainerNo = x.ContainerNo,
                            POL = x.POL,
                            FileType = x.FileType,
                            ProductType = x.ProductType,
                            HBLCount = x.HBLCount,
                            IsEdi = x.IsEdi,
                            Activity = x.Activity,
                            Status = x.Status,
                            Comment = x.Comment,
                            User = x.User,
                            Pages = x.Pages,
                            StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
                            EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null,
                            FileNo = x.FileNo,
                            VesselName = x.VesselName,
                            ShippingLine = x.ShippingLine,
                        }).ToList();

                        fileactivtyHistory = _ctx.FileHistoryLog.Include(x => x.FileActivity).Include(x => x.FileActivity.FileEntry).Include(x => x.User).Include(x => x.FileActivity.ActivityMaster).Where(x => x.FileActivity.FileEntry.CreatedDate != null && x.FileActivity.FileEntry.CreatedDate.Value.Date >= startDate.Date &&
                                             x.FileActivity.FileEntry.CreatedDate.Value.Date <= endDate.Date)
                                             .Select(x => new FileReportViewModel
                                             {
                                                 POD = _ctx.LocationMaster.Where(y => y.Id == x.FileActivity.FileEntry.Pod).Select(y => y.Name).FirstOrDefault(),
                                                 ETA = x.FileActivity.FileEntry.EtaAtPod,
                                                 ReceivedDate = x.FileActivity.FileEntry.CreatedDate,
                                                 ContainerNo = x.FileActivity.FileEntry.ContainerNo,
                                                 POL = _ctx.POLMaster.Where(y => y.Id == x.FileActivity.FileEntry.Pol).Select(y => y.Name).FirstOrDefault(),
                                                 FileType = x.FileActivity.FileEntry.FileType,
                                                 ProductType = x.FileActivity.FileEntry.ProductType,
                                                 HBLCount = x.FileActivity.FileEntry.Hblcount,
                                                 IsEdi = x.FileActivity.FileEntry.IsEdi,
                                                 Activity = x.FileActivity.ActivityId != null ? x.FileActivity.ActivityMaster.Name : "",
                                                 Status = x.CurrentStatus != null ? x.CurrentStatus : "",
                                                 Comment = x.Comment != null ? x.Comment : "",
                                                 User = x.UserId != null ? x.User.CitrixId : "",
                                                 Pages = x.FileActivity.Pages,
                                                 StartDate = x.StartTime != null ? x.StartTime : (DateTime?)null,
                                                 EndDate = x.EndTime != null ? x.EndTime : (DateTime?)null,
                                                 FileNo = x.FileActivity.FileEntry.FileNo,
                                                 VesselName = x.FileActivity.FileEntry.VesselName,
                                                 ShippingLine = x.FileActivity.FileEntry.ShippingLine,
                                             }).ToList();
                        fileactivtyHistory = fileactivtyHistory.Select(x => new FileReportViewModel
                        {
                            POD = x.POD,
                            ETA = x.ETA.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETA.Value, istTimeZone) : (DateTime?)null,
                            ReceivedDate = x.ReceivedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ReceivedDate.Value, istTimeZone) : (DateTime?)null,
                            ContainerNo = x.ContainerNo,
                            POL = x.POL,
                            FileType = x.FileType,
                            ProductType = x.ProductType,
                            HBLCount = x.HBLCount,
                            IsEdi = x.IsEdi,
                            Activity = x.Activity,
                            Status = x.Status,
                            Comment = x.Comment,
                            User = x.User,
                            Pages = x.Pages,
                            StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
                            EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null,
                            FileNo = x.FileNo,
                            VesselName = x.VesselName,
                            ShippingLine = x.ShippingLine,
                        }).ToList();

                        //fileactivity = ToDataTable(fileactivtydata);
                    }
                    else if ((report.DateType == "EndDate"))
                    {
                        fileactivtydata = _ctx.FileActivity.Include(x => x.FileEntry).Include(x => x.User).Include(x => x.ActivityMaster).Where(x => x.EndTime != null && x.EndTime.Value.Date >= startDate.Date &&
                                             x.EndTime.Value.Date <= endDate.Date)
                                             .Select(x => new FileReportViewModel
                                             {
                                                 POD = _ctx.LocationMaster.Where(y => y.Id == x.FileEntry.Pod).Select(y => y.Name).FirstOrDefault(),
                                                 ETA = x.FileEntry.EtaAtPod,
                                                 ReceivedDate = x.FileEntry.CreatedDate,
                                                 ContainerNo = x.FileEntry.ContainerNo,
                                                 POL = _ctx.POLMaster.Where(y => y.Id == x.FileEntry.Pol).Select(y => y.Name).FirstOrDefault(),
                                                 FileType = x.FileEntry.FileType,
                                                 ProductType = x.FileEntry.ProductType,
                                                 HBLCount = x.FileEntry.Hblcount,
                                                 IsEdi = x.FileEntry.IsEdi,
                                                 Activity = x.ActivityId != null ? x.ActivityMaster.Name : "",
                                                 Status = x.CurrentStatus != null ? x.CurrentStatus : "",
                                                 Comment = x.Comment != null ? x.Comment : "",
                                                 User = x.UserId != null ? x.User.CitrixId : "",
                                                 Pages = x.Pages,
                                                 StartDate = x.StartTime != null ? x.StartTime : (DateTime?)null,
                                                 EndDate = x.EndTime != null ? x.EndTime : (DateTime?)null,
                                                 FileNo = x.FileEntry.FileNo,
                                                 VesselName = x.FileEntry.VesselName,
                                                 ShippingLine = x.FileEntry.ShippingLine,
                                             }).ToList();
                        fileactivtydata = fileactivtydata.Select(x => new FileReportViewModel
                        {
                            POD = x.POD,
                            ETA = x.ETA.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETA.Value, istTimeZone) : (DateTime?)null,
                            ReceivedDate = x.ReceivedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ReceivedDate.Value, istTimeZone) : (DateTime?)null,
                            ContainerNo = x.ContainerNo,
                            POL = x.POL,
                            FileType = x.FileType,
                            ProductType = x.ProductType,
                            HBLCount = x.HBLCount,
                            IsEdi = x.IsEdi,
                            Activity = x.Activity,
                            Status = x.Status,
                            Comment = x.Comment,
                            User = x.User,
                            Pages = x.Pages,
                            StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
                            EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null,
                            FileNo = x.FileNo,
                            VesselName = x.VesselName,
                            ShippingLine = x.ShippingLine,
                        }).ToList();

                        fileactivtyHistory = _ctx.FileHistoryLog.Include(x => x.FileActivity).Include(x => x.FileActivity.FileEntry).Include(x => x.User).Include(x => x.FileActivity.ActivityMaster).Where(x => x.EnterEndDate != null && x.EnterEndDate.Value.Date >= startDate.Date &&
                                             x.EnterEndDate.Value.Date <= endDate.Date)
                                             .Select(x => new FileReportViewModel
                                             {
                                                 POD = _ctx.LocationMaster.Where(y => y.Id == x.FileActivity.FileEntry.Pod).Select(y => y.Name).FirstOrDefault(),
                                                 ETA = x.FileActivity.FileEntry.EtaAtPod,
                                                 ReceivedDate = x.FileActivity.FileEntry.CreatedDate,
                                                 ContainerNo = x.FileActivity.FileEntry.ContainerNo,
                                                 POL = _ctx.POLMaster.Where(y => y.Id == x.FileActivity.FileEntry.Pol).Select(y => y.Name).FirstOrDefault(),
                                                 FileType = x.FileActivity.FileEntry.FileType,
                                                 ProductType = x.FileActivity.FileEntry.ProductType,
                                                 HBLCount = x.FileActivity.FileEntry.Hblcount,
                                                 IsEdi = x.FileActivity.FileEntry.IsEdi,
                                                 Activity = x.FileActivity.ActivityId != null ? x.FileActivity.ActivityMaster.Name : "",
                                                 Status = x.CurrentStatus != null ? x.CurrentStatus : "",
                                                 Comment = x.Comment != null ? x.Comment : "",
                                                 User = x.UserId != null ? x.User.CitrixId : "",
                                                 Pages = x.FileActivity.Pages,
                                                 StartDate = x.StartTime != null ? x.StartTime : (DateTime?)null,
                                                 EndDate = x.EndTime != null ? x.EndTime : (DateTime?)null,
                                                 FileNo = x.FileActivity.FileEntry.FileNo,
                                                 VesselName = x.FileActivity.FileEntry.VesselName,
                                                 ShippingLine = x.FileActivity.FileEntry.ShippingLine,
                                             }).ToList();
                        fileactivtyHistory = fileactivtyHistory.Select(x => new FileReportViewModel
                        {
                            POD = x.POD,
                            ETA = x.ETA.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETA.Value, istTimeZone) : (DateTime?)null,
                            ReceivedDate = x.ReceivedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ReceivedDate.Value, istTimeZone) : (DateTime?)null,
                            ContainerNo = x.ContainerNo,
                            POL = x.POL,
                            FileType = x.FileType,
                            ProductType = x.ProductType,
                            HBLCount = x.HBLCount,
                            IsEdi = x.IsEdi,
                            Activity = x.Activity,
                            Status = x.Status,
                            Comment = x.Comment,
                            User = x.User,
                            Pages = x.Pages,
                            StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
                            EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null,
                            FileNo = x.FileNo,
                            VesselName = x.VesselName,
                            ShippingLine = x.ShippingLine,
                        }).ToList();

                        //fileactivity = ToDataTable(fileactivtydata);
                    }
                    else
                    {
                        fileactivtydata = _ctx.FileActivity.Include(x => x.FileEntry).Include(x => x.User).Include(x => x.ActivityMaster).Where(x => x.StartTime != null && x.StartTime.Value.Date >= startDate.Date &&
                                             x.StartTime.Value.Date <= endDate.Date)
                                             .Select(x => new FileReportViewModel
                                             {
                                                 POD = _ctx.LocationMaster.Where(y => y.Id == x.FileEntry.Pod).Select(y => y.Name).FirstOrDefault(),
                                                 ETA = x.FileEntry.EtaAtPod,
                                                 ReceivedDate = x.FileEntry.CreatedDate,
                                                 ContainerNo = x.FileEntry.ContainerNo,
                                                 POL = _ctx.POLMaster.Where(y => y.Id == x.FileEntry.Pol).Select(y => y.Name).FirstOrDefault(),
                                                 FileType = x.FileEntry.FileType,
                                                 ProductType = x.FileEntry.ProductType,
                                                 HBLCount = x.FileEntry.Hblcount,
                                                 IsEdi = x.FileEntry.IsEdi,
                                                 Activity = x.ActivityId != null ? x.ActivityMaster.Name : "",
                                                 Status = x.CurrentStatus != null ? x.CurrentStatus : "",
                                                 Comment = x.Comment != null ? x.Comment : "",
                                                 User = x.UserId != null ? x.User.CitrixId : "",
                                                 Pages = x.Pages,
                                                 StartDate = x.StartTime != null ? x.StartTime : (DateTime?)null,
                                                 EndDate = x.EndTime != null ? x.EndTime : (DateTime?)null,
                                                 FileNo = x.FileEntry.FileNo,
                                                 VesselName = x.FileEntry.VesselName,
                                                 ShippingLine = x.FileEntry.ShippingLine,
                                             }).ToList();
                        fileactivtydata = fileactivtydata.Select(x => new FileReportViewModel
                        {
                            POD = x.POD,
                            ETA = x.ETA.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETA.Value, istTimeZone) : (DateTime?)null,
                            ReceivedDate = x.ReceivedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ReceivedDate.Value, istTimeZone) : (DateTime?)null,
                            ContainerNo = x.ContainerNo,
                            POL = x.POL,
                            FileType = x.FileType,
                            ProductType = x.ProductType,
                            HBLCount = x.HBLCount,
                            IsEdi = x.IsEdi,
                            Activity = x.Activity,
                            Status = x.Status,
                            Comment = x.Comment,
                            User = x.User,
                            Pages = x.Pages,
                            StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
                            EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null,
                            FileNo = x.FileNo,
                            VesselName = x.VesselName,
                            ShippingLine = x.ShippingLine,
                        }).ToList();

                        fileactivtyHistory = _ctx.FileHistoryLog.Include(x => x.FileActivity).Include(x => x.FileActivity.FileEntry).Include(x => x.User).Include(x => x.FileActivity.ActivityMaster).Where(x => x.EnterStartDate != null && x.EnterStartDate.Value.Date >= startDate.Date &&
                                             x.EnterStartDate.Value.Date <= endDate.Date)
                                             .Select(x => new FileReportViewModel
                                             {
                                                 POD = _ctx.LocationMaster.Where(y => y.Id == x.FileActivity.FileEntry.Pod).Select(y => y.Name).FirstOrDefault(),
                                                 ETA = x.FileActivity.FileEntry.EtaAtPod,
                                                 ReceivedDate = x.FileActivity.FileEntry.CreatedDate,
                                                 ContainerNo = x.FileActivity.FileEntry.ContainerNo,
                                                 POL = _ctx.POLMaster.Where(y => y.Id == x.FileActivity.FileEntry.Pol).Select(y => y.Name).FirstOrDefault(),
                                                 FileType = x.FileActivity.FileEntry.FileType,
                                                 ProductType = x.FileActivity.FileEntry.ProductType,
                                                 HBLCount = x.FileActivity.FileEntry.Hblcount,
                                                 IsEdi = x.FileActivity.FileEntry.IsEdi,
                                                 Activity = x.FileActivity.ActivityId != null ? x.FileActivity.ActivityMaster.Name : "",
                                                 Status = x.CurrentStatus != null ? x.CurrentStatus : "",
                                                 Comment = x.Comment != null ? x.Comment : "",
                                                 User = x.UserId != null ? x.User.CitrixId : "",
                                                 Pages = x.FileActivity.Pages,
                                                 StartDate = x.StartTime != null ? x.StartTime : (DateTime?)null,
                                                 EndDate = x.EndTime != null ? x.EndTime : (DateTime?)null,
                                                 FileNo = x.FileActivity.FileEntry.FileNo,
                                                 VesselName = x.FileActivity.FileEntry.VesselName,
                                                 ShippingLine = x.FileActivity.FileEntry.ShippingLine,
                                             }).ToList();
                        fileactivtyHistory = fileactivtyHistory.Select(x => new FileReportViewModel
                        {
                            POD = x.POD,
                            ETA = x.ETA.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETA.Value, istTimeZone) : (DateTime?)null,
                            ReceivedDate = x.ReceivedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ReceivedDate.Value, istTimeZone) : (DateTime?)null,
                            ContainerNo = x.ContainerNo,
                            POL = x.POL,
                            FileType = x.FileType,
                            ProductType = x.ProductType,
                            HBLCount = x.HBLCount,
                            IsEdi = x.IsEdi,
                            Activity = x.Activity,
                            Status = x.Status,
                            Comment = x.Comment,
                            User = x.User,
                            Pages = x.Pages,
                            StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
                            EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null,
                            FileNo = x.FileNo,
                            VesselName = x.VesselName,
                            ShippingLine = x.ShippingLine,
                        }).ToList();

                        //fileactivity = ToDataTable(fileactivtydata);
                    }

                    DataTable dtt = ToDataTable(fileactivtydata);
                    DataTable dtt1 = ToDataTable(fileactivtyHistory);

                    foreach (DataRow item in dtt.Rows)
                    {
                        DataRow dr = dt.NewRow();
                        for (int i = 0; i < dtt.Columns.Count; i++)
                        {
                            dr[i] = item[i];

                        }
                        dt.Rows.Add(dr);
                    }
                    
                    foreach (DataRow item in dtt1.Rows)
                    {
                        DataRow dr = dt1.NewRow();
                        for (int i = 0; i < dtt1.Columns.Count; i++)
                        {
                            dr[i] = item[i];

                        }
                        dt1.Rows.Add(dr);
                    }

                    string filename = "";
                    //filename = saveFile.FileName;
                    string apath = filename + ".xlsx";
                    using (XLWorkbook wb = new XLWorkbook())
                    {
                        dt.TableName = "File Data Report";
                        dt1.TableName = "File History Data Report";
                        var wsFileData = wb.Worksheets.Add(dt);
                        var wsFileData1 = wb.Worksheets.Add(dt1);
                        wsFileData.Columns().AdjustToContents();
                        wsFileData1.Columns().AdjustToContents();

                        try
                        {
                            using (MemoryStream stream = new MemoryStream())
                            {
                                wb.SaveAs(stream);
                                string excelname = $"FileDataReport-{DateTime.Now.ToString("ddMMyyyy hh:mm:ss")}.xlsx";
                                return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                            }

                            // System.Windows.Forms.MessageBox.Show("File Save Successfully.!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        catch (Exception ex)
                        {
                            // System.Windows.Forms.MessageBox.Show("Something went wrong.!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }

                }
                else if (report.ReportType == "HBL")
                {
                    dt.Columns.Add("Received Date");
                    dt.Columns.Add("FileNo");
                    dt.Columns.Add("ContainerNo");
                    dt.Columns.Add("HBLNo");
                    dt.Columns.Add("IsDap");
                    dt.Columns.Add("Activity");
                    dt.Columns.Add("Current Status");
                    dt.Columns.Add("Comment");
                    dt.Columns.Add("UserName");
                    dt.Columns.Add("StartDate");
                    dt.Columns.Add("EndDate");

                    dt1.Columns.Add("Received Date");
                    dt1.Columns.Add("FileNo");
                    dt1.Columns.Add("ContainerNo");
                    dt1.Columns.Add("HBLNo");
                    dt1.Columns.Add("IsDap");
                    dt1.Columns.Add("Activity");
                    dt1.Columns.Add("Current Status");
                    dt1.Columns.Add("Comment");
                    dt1.Columns.Add("UserName");
                    dt1.Columns.Add("StartDate");
                    dt1.Columns.Add("EndDate");

                    if (report.DateType == "ReceivedDate")
                    {
                        HBLdata = _ctx.HblActivity.Include(x => x.HblEntry).Include(x => x.HblEntry.FileGuid).Include(x => x.ActivityMaster).Include(x => x.User).Where(x => x.HblEntry.CreatedDate != null && x.HblEntry.CreatedDate.Value.Date >= startDate.Date &&
                                  x.HblEntry.CreatedDate.Value.Date <= endDate.Date).Select(x => new HBLReportViewModel
                                  {
                                      ReceivedDate = x.HblEntry.CreatedDate,
                                      FileNo = x.HblEntry.FileGuid.FileNo,
                                      ContainerNo = x.HblEntry.FileGuid.ContainerNo,
                                      HBLNo = x.HblEntry.Hblno,
                                      IsDap = x.HblEntry.IsDap,
                                      Activity = x.ActivityMaster.Name,
                                      Status = x.CurrentStatus,
                                      Comment = x.Comment,
                                      User = x.User.CitrixId,
                                      StartDate = x.StartTime,
                                      EndDate = x.EndTime
                                  }).ToList();

                        HBLdata = HBLdata.Select(x => new HBLReportViewModel
                        {
                            ReceivedDate = x.ReceivedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ReceivedDate.Value, istTimeZone) : (DateTime?)null,
                            FileNo = x.FileNo,
                            ContainerNo = x.ContainerNo,
                            HBLNo = x.HBLNo,
                            IsDap = x.IsDap,
                            Activity = x.Activity,
                            Status = x.Status,
                            Comment = x.Comment,
                            User = x.User,
                            StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
                            EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null

                        }).ToList();

                        HBLHistory = _ctx.HBLHistoryLog.Include(x => x.HblActivity).Include(x => x.HblActivity.HblEntry).Include(x => x.HblActivity.HblEntry.FileGuid).Include(x => x.HblActivity.ActivityMaster).Include(x => x.User).Where(x => x.HblActivity.HblEntry.CreatedDate != null && x.HblActivity.HblEntry.CreatedDate.Value.Date >= startDate.Date &&
                                  x.HblActivity.HblEntry.CreatedDate.Value.Date <= endDate.Date).Select(x => new HBLReportViewModel
                                  {
                                      ReceivedDate = x.HblActivity.HblEntry.CreatedDate,
                                      FileNo = x.HblActivity.HblEntry.FileGuid.FileNo,
                                      ContainerNo = x.HblActivity.HblEntry.FileGuid.ContainerNo,
                                      HBLNo = x.HblActivity.HblEntry.Hblno,
                                      IsDap = x.HblActivity.HblEntry.IsDap,
                                      Activity = x.HblActivity.ActivityMaster.Name,
                                      Status = x.CurrentStatus,
                                      Comment = x.Comment,
                                      User = x.User.CitrixId,
                                      StartDate = x.StartTime,
                                      EndDate = x.EndTime
                                  }).ToList();

                        HBLHistory = HBLHistory.Select(x => new HBLReportViewModel
                        {
                            ReceivedDate = x.ReceivedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ReceivedDate.Value, istTimeZone) : (DateTime?)null,
                            FileNo = x.FileNo,
                            ContainerNo = x.ContainerNo,
                            HBLNo = x.HBLNo,
                            IsDap = x.IsDap,
                            Activity = x.Activity,
                            Status = x.Status,
                            Comment = x.Comment,
                            User = x.User,
                            StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
                            EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null

                        }).ToList();

                        //hblactivity = ToDataTable(HBLdata);
                    }
                    else if (report.DateType == "EndDate")
                    {
                        HBLdata = _ctx.HblActivity.Include(x => x.HblEntry).Include(x => x.HblEntry.FileGuid).Include(x => x.ActivityMaster).Include(x => x.User).Where(x => x.EndTime != null && x.EndTime.Value.Date >= startDate.Date &&
                                  x.EndTime.Value.Date <= endDate.Date).Select(x => new HBLReportViewModel
                                  {
                                      ReceivedDate = x.HblEntry.CreatedDate,
                                      FileNo = x.HblEntry.FileGuid.FileNo,
                                      ContainerNo = x.HblEntry.FileGuid.ContainerNo,
                                      HBLNo = x.HblEntry.Hblno,
                                      IsDap = x.HblEntry.IsDap,
                                      Activity = x.ActivityMaster.Name,
                                      Status = x.CurrentStatus,
                                      Comment = x.Comment,
                                      User = x.User.CitrixId,
                                      StartDate = x.StartTime,
                                      EndDate = x.EndTime
                                  }).ToList();

                        HBLdata = HBLdata.Select(x => new HBLReportViewModel
                        {
                            ReceivedDate = x.ReceivedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ReceivedDate.Value, istTimeZone) : (DateTime?)null,
                            FileNo = x.FileNo,
                            ContainerNo = x.ContainerNo,
                            HBLNo = x.HBLNo,
                            IsDap = x.IsDap,
                            Activity = x.Activity,
                            Status = x.Status,
                            Comment = x.Comment,
                            User = x.User,
                            StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
                            EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null

                        }).ToList();

                        HBLHistory = _ctx.HBLHistoryLog.Include(x => x.HblActivity).Include(x => x.HblActivity.HblEntry).Include(x => x.HblActivity.HblEntry.FileGuid).Include(x => x.HblActivity.ActivityMaster).Include(x => x.User).Where(x => x.EnterEndDate != null && x.EnterEndDate.Value.Date >= startDate.Date &&
                                  x.EnterEndDate.Value.Date <= endDate.Date).Select(x => new HBLReportViewModel
                                  {
                                      ReceivedDate = x.HblActivity.HblEntry.CreatedDate,
                                      FileNo = x.HblActivity.HblEntry.FileGuid.FileNo,
                                      ContainerNo = x.HblActivity.HblEntry.FileGuid.ContainerNo,
                                      HBLNo = x.HblActivity.HblEntry.Hblno,
                                      IsDap = x.HblActivity.HblEntry.IsDap,
                                      Activity = x.HblActivity.ActivityMaster.Name,
                                      Status = x.CurrentStatus,
                                      Comment = x.Comment,
                                      User = x.User.CitrixId,
                                      StartDate = x.StartTime,
                                      EndDate = x.EndTime
                                  }).ToList();

                        HBLHistory = HBLHistory.Select(x => new HBLReportViewModel
                        {
                            ReceivedDate = x.ReceivedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ReceivedDate.Value, istTimeZone) : (DateTime?)null,
                            FileNo = x.FileNo,
                            ContainerNo = x.ContainerNo,
                            HBLNo = x.HBLNo,
                            IsDap = x.IsDap,
                            Activity = x.Activity,
                            Status = x.Status,
                            Comment = x.Comment,
                            User = x.User,
                            StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
                            EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null

                        }).ToList();

                        //hblactivity = ToDataTable(HBLdata);
                    }
                    else
                    {
                        HBLdata = _ctx.HblActivity.Include(x => x.HblEntry).Include(x => x.HblEntry.FileGuid).Include(x => x.ActivityMaster).Include(x => x.User).Where(x => x.StartTime != null && x.StartTime.Value.Date >= startDate.Date &&
                                  x.StartTime.Value.Date <= endDate.Date).Select(x => new HBLReportViewModel
                                  {
                                      ReceivedDate = x.HblEntry.CreatedDate,
                                      FileNo = x.HblEntry.FileGuid.FileNo,
                                      ContainerNo = x.HblEntry.FileGuid.ContainerNo,
                                      HBLNo = x.HblEntry.Hblno,
                                      IsDap = x.HblEntry.IsDap,
                                      Activity = x.ActivityMaster.Name,
                                      Status = x.CurrentStatus,
                                      Comment = x.Comment,
                                      User = x.User.CitrixId,
                                      StartDate = x.StartTime,
                                      EndDate = x.EndTime
                                  }).ToList();

                        HBLdata = HBLdata.Select(x => new HBLReportViewModel
                        {
                            ReceivedDate = x.ReceivedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ReceivedDate.Value, istTimeZone) : (DateTime?)null,
                            FileNo = x.FileNo,
                            ContainerNo = x.ContainerNo,
                            HBLNo = x.HBLNo,
                            IsDap = x.IsDap,
                            Activity = x.Activity,
                            Status = x.Status,
                            Comment = x.Comment,
                            User = x.User,
                            StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
                            EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null

                        }).ToList();

                        HBLHistory = _ctx.HBLHistoryLog.Include(x => x.HblActivity).Include(x => x.HblActivity.HblEntry).Include(x => x.HblActivity.HblEntry.FileGuid).Include(x => x.HblActivity.ActivityMaster).Include(x => x.User).Where(x => x.EnterStartDate != null && x.EnterStartDate.Value.Date >= startDate.Date &&
                                  x.EnterStartDate.Value.Date <= endDate.Date).Select(x => new HBLReportViewModel
                                  {
                                      ReceivedDate = x.HblActivity.HblEntry.CreatedDate,
                                      FileNo = x.HblActivity.HblEntry.FileGuid.FileNo,
                                      ContainerNo = x.HblActivity.HblEntry.FileGuid.ContainerNo,
                                      HBLNo = x.HblActivity.HblEntry.Hblno,
                                      IsDap = x.HblActivity.HblEntry.IsDap,
                                      Activity = x.HblActivity.ActivityMaster.Name,
                                      Status = x.CurrentStatus,
                                      Comment = x.Comment,
                                      User = x.User.CitrixId,
                                      StartDate = x.StartTime,
                                      EndDate = x.EndTime
                                  }).ToList();

                        HBLHistory = HBLHistory.Select(x => new HBLReportViewModel
                        {
                            ReceivedDate = x.ReceivedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ReceivedDate.Value, istTimeZone) : (DateTime?)null,
                            FileNo = x.FileNo,
                            ContainerNo = x.ContainerNo,
                            HBLNo = x.HBLNo,
                            IsDap = x.IsDap,
                            Activity = x.Activity,
                            Status = x.Status,
                            Comment = x.Comment,
                            User = x.User,
                            StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
                            EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null

                        }).ToList();

                        //hblactivity = ToDataTable(HBLdata);

                    }
                    DataTable dtt = ToDataTable(HBLdata);
                    DataTable dtt1 = ToDataTable(HBLHistory);

                    foreach (DataRow item in dtt.Rows)
                    {
                        DataRow dr = dt.NewRow();
                        for (int i = 0; i < dtt.Columns.Count; i++)
                        {
                            dr[i] = item[i];

                        }
                        dt.Rows.Add(dr);
                    }
                    
                    foreach (DataRow item in dtt1.Rows)
                    {
                        DataRow dr = dt1.NewRow();
                        for (int i = 0; i < dtt1.Columns.Count; i++)
                        {
                            dr[i] = item[i];

                        }
                        dt1.Rows.Add(dr);
                    }

                    string filename = "";
                    string apath = filename + ".xlsx";
                    using (XLWorkbook wb = new XLWorkbook())
                    {
                        dt.TableName = "HBL Data Report";
                        dt1.TableName = "HBL History Data Report";
                        var wsFileData = wb.Worksheets.Add(dt);
                        var wsFileData1 = wb.Worksheets.Add(dt1);
                        wsFileData.Columns().AdjustToContents();
                        wsFileData1.Columns().AdjustToContents();

                        try
                        {
                            using (MemoryStream stream = new MemoryStream())
                            {
                                wb.SaveAs(stream);
                                string excelname = $"HBLDataReport-{DateTime.Now.ToString("ddMMyyyy hh:mm:ss")}.xlsx";
                                return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                            }
                        }
                        catch (Exception ex)
                        {

                        }
                    }

                }
                //else if (report.ReportType == "UserProductionReport")
                //{
                //    if (report.DateType == "ReceivedDate")
                //    {
                //        foreach (var user in userList)
                //        {
                //            getFileActivityStatus = new List<FileActivityStatusList>();
                //            getHBLActivityStatus = new List<HBLActivityStatusList>();
                //            fileActivityList = _context.FileActivityLog.Where(x => x.ContainerMaster.FileMaster.EnterDate >= startDate && x.ContainerMaster.FileMaster.EnterDate <= endDate).ToList();

                //            foreach (var item in fileActivitys)
                //            {
                //                getFileActivityStatus.Add(new FileActivityStatusList
                //                {
                //                    Activity = _context.ActivityMaster.Where(x => x.Id == item.Id).Select(x => x.NameOfActivity).FirstOrDefault(),
                //                    ActivityType = _context.ActivityMaster.Where(x => x.Id == item.Id).Select(x => x.ActivityType).FirstOrDefault(),
                //                    WIP = fileActivityList.Where(x => x.StatusId == "WIP" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                //                    Completed = fileActivityList.Where(x => x.StatusId == "Completed" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                //                    Pending = fileActivityList.Where(x => x.StatusId == "Pending" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                //                    Query = fileActivityList.Where(x => x.StatusId == "Query" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                //                    CompletedWithQuery = fileActivityList.Where(x => x.StatusId == "Completed With Query" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                //                    Total = fileActivityList.Where(x => x.ActivityId == item.Id && x.UserId == user.Id).Count(),

                //                });
                //            }

                //            userActivityStatus.GetUserStatusList.Add(new UserStatusList
                //            {
                //                UserId = user.UserName,
                //                WIP = fileActivityList.Where(x => x.StatusId == "WIP" && x.UserId == user.Id).Count(),
                //                Completed = fileActivityList.Where(x => x.StatusId == "Completed" && x.UserId == user.Id).Count(),
                //                Pending = fileActivityList.Where(x => x.StatusId == "Pending" && x.UserId == user.Id).Count(),
                //                Query = fileActivityList.Where(x => x.StatusId == "Query" && x.UserId == user.Id).Count(),
                //                CompletedWithQuery = fileActivityList.Where(x => x.StatusId == "Completed With Query" && x.UserId == user.Id).Count(),
                //                Total = fileActivityList.Where(x => x.UserId == user.Id).Count(),
                //                GetFileActivityStatus = getFileActivityStatus,
                //                GetHBLActivityStatus = getHBLActivityStatus
                //            });
                //        }


                //        var fileStatus = userActivityStatus.GetUserStatusList.Select(x => new UserStatusList
                //        {
                //            UserId = x.UserId,
                //            Total = x.Total,
                //            WIP = x.WIP,
                //            Query = x.Query,
                //            Pending = x.Pending,
                //            Completed = x.Completed,
                //            CompletedWithQuery = x.CompletedWithQuery,
                //            GetFileActivityStatus = x.GetFileActivityStatus

                //        }).ToList();

                //        DataTable FileActivityStatus = ToDataTable(fileStatus);

                //        dt.Columns.Add("Username");
                //        dt.Columns.Add("Activity");
                //        dt.Columns.Add("ActivityType");
                //        dt.Columns.Add("Total");
                //        dt.Columns.Add("Completed");
                //        dt.Columns.Add("CompletedWithQuery");
                //        dt.Columns.Add("Pending");
                //        dt.Columns.Add("Query");
                //        dt.Columns.Add("WIP");



                //        foreach (var dr in fileStatus)
                //        {
                //            foreach (var file in dr.GetFileActivityStatus)
                //            {
                //                DataRow tr = dt.NewRow();
                //                tr[0] = dr.UserId;
                //                tr[0] = dr.UserId;
                //                tr[1] = file.Activity;
                //                tr[2] = file.ActivityType;
                //                tr[3] = file.Total;
                //                tr[4] = file.Completed;
                //                tr[5] = file.CompletedWithQuery;
                //                tr[6] = file.Pending;
                //                tr[7] = file.Query;
                //                tr[8] = file.WIP;
                //                dt.Rows.Add(tr);
                //            }
                //        }

                //        using (XLWorkbook wb = new XLWorkbook())
                //        {
                //            dt.TableName = "User Production Report";
                //            var wsData = wb.Worksheets.Add(dt);
                //            using (MemoryStream stream = new MemoryStream())
                //            {
                //                wb.SaveAs(stream);
                //                string excelname = $"UserProductionReport-{DateTime.UtcNow.ToString("ddMMyyyy hh:mm:ss")}.xlsx";
                //                return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                //            }
                //        }
                //    }
                //    else if (report.DateType == "EndDate")
                //    {
                //        foreach (var user in userList)
                //        {
                //            getFileActivityStatus = new List<FileActivityStatusList>();
                //            getHBLActivityStatus = new List<HBLActivityStatusList>();
                //            fileActivityList = _context.FileActivityLog.Where(x => x.EndDate >= startDate && x.EndDate <= endDate).ToList();

                //            foreach (var item in fileActivitys)
                //            {
                //                getFileActivityStatus.Add(new FileActivityStatusList
                //                {
                //                    Activity = _context.ActivityMaster.Where(x => x.Id == item.Id).Select(x => x.NameOfActivity).FirstOrDefault(),
                //                    ActivityType = _context.ActivityMaster.Where(x => x.Id == item.Id).Select(x => x.ActivityType).FirstOrDefault(),
                //                    WIP = fileActivityList.Where(x => x.StatusId == "WIP" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                //                    Completed = fileActivityList.Where(x => x.StatusId == "Completed" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                //                    Pending = fileActivityList.Where(x => x.StatusId == "Pending" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                //                    Query = fileActivityList.Where(x => x.StatusId == "Query" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                //                    CompletedWithQuery = fileActivityList.Where(x => x.StatusId == "Completed With Query" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                //                    Total = fileActivityList.Where(x => x.ActivityId == item.Id && x.UserId == user.Id).Count(),

                //                });
                //            }

                //            userActivityStatus.GetUserStatusList.Add(new UserStatusList
                //            {
                //                UserId = user.UserName,
                //                WIP = fileActivityList.Where(x => x.StatusId == "WIP" && x.UserId == user.Id).Count(),
                //                Completed = fileActivityList.Where(x => x.StatusId == "Completed" && x.UserId == user.Id).Count(),
                //                Pending = fileActivityList.Where(x => x.StatusId == "Pending" && x.UserId == user.Id).Count(),
                //                Query = fileActivityList.Where(x => x.StatusId == "Query" && x.UserId == user.Id).Count(),
                //                CompletedWithQuery = fileActivityList.Where(x => x.StatusId == "Completed With Query" && x.UserId == user.Id).Count(),
                //                Total = fileActivityList.Where(x => x.UserId == user.Id).Count(),
                //                GetFileActivityStatus = getFileActivityStatus,
                //                GetHBLActivityStatus = getHBLActivityStatus
                //            });
                //        }


                //        var fileStatus = userActivityStatus.GetUserStatusList.Select(x => new UserStatusList
                //        {
                //            UserId = x.UserId,
                //            Total = x.Total,
                //            WIP = x.WIP,
                //            Query = x.Query,
                //            Pending = x.Pending,
                //            Completed = x.Completed,
                //            CompletedWithQuery = x.CompletedWithQuery,
                //            GetFileActivityStatus = x.GetFileActivityStatus

                //        }).ToList();

                //        DataTable FileActivityStatus = ToDataTable(fileStatus);

                //        dt.Columns.Add("User");
                //        dt.Columns.Add("Activity");
                //        dt.Columns.Add("ActivityType");
                //        dt.Columns.Add("Total");
                //        dt.Columns.Add("Completed");
                //        dt.Columns.Add("CompletedWithQuery");
                //        dt.Columns.Add("Pending");
                //        dt.Columns.Add("Query");
                //        dt.Columns.Add("WIP");



                //        foreach (var dr in fileStatus)
                //        {
                //            foreach (var file in dr.GetFileActivityStatus)
                //            {
                //                DataRow tr = dt.NewRow();
                //                tr[0] = dr.UserId;
                //                tr[0] = dr.UserId;
                //                tr[1] = file.Activity;
                //                tr[2] = file.ActivityType;
                //                tr[3] = file.Total;
                //                tr[4] = file.Completed;
                //                tr[5] = file.CompletedWithQuery;
                //                tr[6] = file.Pending;
                //                tr[7] = file.Query;
                //                tr[8] = file.WIP;
                //                dt.Rows.Add(tr);
                //            }
                //        }

                //        using (XLWorkbook wb = new XLWorkbook())
                //        {
                //            dt.TableName = "User Production Report";
                //            var wsData = wb.Worksheets.Add(dt);
                //            using (MemoryStream stream = new MemoryStream())
                //            {
                //                wb.SaveAs(stream);
                //                string excelname = $"UserProductionReport-{DateTime.UtcNow.ToString("ddMMyyyy hh:mm:ss")}.xlsx";
                //                return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                //            }
                //        }
                //    }
                //    else
                //    {
                //        foreach (var user in userList)
                //        {
                //            getFileActivityStatus = new List<FileActivityStatusList>();
                //            getHBLActivityStatus = new List<HBLActivityStatusList>();
                //            fileActivityList = _context.FileActivityLog.Where(x => x.StartDate >= startDate && x.StartDate <= endDate).ToList();

                //            foreach (var item in fileActivitys)
                //            {
                //                getFileActivityStatus.Add(new FileActivityStatusList
                //                {
                //                    Activity = _context.ActivityMaster.Where(x => x.Id == item.Id).Select(x => x.NameOfActivity).FirstOrDefault(),
                //                    ActivityType = _context.ActivityMaster.Where(x => x.Id == item.Id).Select(x => x.ActivityType).FirstOrDefault(),
                //                    WIP = fileActivityList.Where(x => x.StatusId == "WIP" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                //                    Completed = fileActivityList.Where(x => x.StatusId == "Completed" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                //                    Pending = fileActivityList.Where(x => x.StatusId == "Pending" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                //                    Query = fileActivityList.Where(x => x.StatusId == "Query" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                //                    CompletedWithQuery = fileActivityList.Where(x => x.StatusId == "Completed With Query" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                //                    Total = fileActivityList.Where(x => x.ActivityId == item.Id && x.UserId == user.Id).Count(),

                //                });
                //            }

                //            userActivityStatus.GetUserStatusList.Add(new UserStatusList
                //            {
                //                UserId = user.UserName,
                //                WIP = fileActivityList.Where(x => x.StatusId == "WIP" && x.UserId == user.Id).Count(),
                //                Completed = fileActivityList.Where(x => x.StatusId == "Completed" && x.UserId == user.Id).Count(),
                //                Pending = fileActivityList.Where(x => x.StatusId == "Pending" && x.UserId == user.Id).Count(),
                //                Query = fileActivityList.Where(x => x.StatusId == "Query" && x.UserId == user.Id).Count(),
                //                CompletedWithQuery = fileActivityList.Where(x => x.StatusId == "Completed With Query" && x.UserId == user.Id).Count(),
                //                Total = fileActivityList.Where(x => x.UserId == user.Id).Count(),
                //                GetFileActivityStatus = getFileActivityStatus,
                //                GetHBLActivityStatus = getHBLActivityStatus
                //            });
                //        }


                //        var fileStatus = userActivityStatus.GetUserStatusList.Select(x => new UserStatusList
                //        {
                //            UserId = x.UserId,
                //            Total = x.Total,
                //            WIP = x.WIP,
                //            Query = x.Query,
                //            Pending = x.Pending,
                //            Completed = x.Completed,
                //            CompletedWithQuery = x.CompletedWithQuery,
                //            GetFileActivityStatus = x.GetFileActivityStatus

                //        }).ToList();

                //        DataTable FileActivityStatus = ToDataTable(fileStatus);

                //        dt.Columns.Add("User");
                //        dt.Columns.Add("Activity");
                //        dt.Columns.Add("ActivityType");
                //        dt.Columns.Add("Total");
                //        dt.Columns.Add("Completed");
                //        dt.Columns.Add("CompletedWithQuery");
                //        dt.Columns.Add("Pending");
                //        dt.Columns.Add("Query");
                //        dt.Columns.Add("WIP");



                //        foreach (var dr in fileStatus)
                //        {
                //            foreach (var file in dr.GetFileActivityStatus)
                //            {
                //                DataRow tr = dt.NewRow();
                //                tr[0] = dr.UserId;
                //                tr[0] = dr.UserId;
                //                tr[1] = file.Activity;
                //                tr[2] = file.ActivityType;
                //                tr[3] = file.Total;
                //                tr[4] = file.Completed;
                //                tr[5] = file.CompletedWithQuery;
                //                tr[6] = file.Pending;
                //                tr[7] = file.Query;
                //                tr[8] = file.WIP;
                //                dt.Rows.Add(tr);
                //            }
                //        }

                //        using (XLWorkbook wb = new XLWorkbook())
                //        {
                //            dt.TableName = "User Production Report";
                //            var wsData = wb.Worksheets.Add(dt);
                //            using (MemoryStream stream = new MemoryStream())
                //            {
                //                wb.SaveAs(stream);
                //                string excelname = $"UserProductionReport-{DateTime.UtcNow.ToString("ddMMyyyy hh:mm:ss")}.xlsx";
                //                return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                //            }
                //        }
                //    }


                //}
                //else if (report.ReportType == "ActivityWiseUserHBLProduction")
                //{
                //    if (report.DateType == "ReceivedDate")
                //    {
                //        List<UserDashboardViewModel> userdashboardModel = new List<UserDashboardViewModel>();
                //        ViewData["Activity"] = _context.ActivityMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.FileSequence).ThenBy(x => x.NameOfActivity).ToList();
                //        ViewData["User"] = _context.Users.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CitrixId).ToList();
                //        ViewData["Status"] = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Status).ToList();
                //        var activityList = _context.ActivityMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.FileSequence).ThenBy(x => x.NameOfActivity).ToList();
                //        List<StatusMaster> _status = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Status).ToList();
                //        string completed = _status.Where(x => x.Status == "Completed").Select(x => x.Id).FirstOrDefault();
                //        string pending = _status.Where(x => x.Status == "Pending").Select(x => x.Id).FirstOrDefault();
                //        string query = _status.Where(x => x.Status == "Query").Select(x => x.Id).FirstOrDefault();
                //        string wip = _status.Where(x => x.Status == "WIP").Select(x => x.Id).FirstOrDefault();
                //        string completedWithQuery = _status.Where(x => x.Status == "Completed With Query").Select(x => x.Id).FirstOrDefault();

                //        var data = _context.HBLActivityLog.Where(x => x.Hbl.ContainerMaster.FileMaster.EnterDate >= startDate && x.Hbl.ContainerMaster.FileMaster.EnterDate <= endDate).Include(x => x.Hbl.ContainerMaster).GroupBy(x => new
                //        {
                //            x.ApplicationUser.CitrixId,
                //        }).Select(x => new UserDashboardViewModel
                //        {
                //            User = x.Key.CitrixId,
                //            Count = x.Count(),
                //        }).ToList();

                //        foreach (UserDashboardViewModel dashboard in data)
                //        {
                //            dashboard.HBLCount = _context.HBLActivityLog.Where(x => x.ApplicationUser.CitrixId == dashboard.User && x.Hbl.ContainerMaster.FileMaster.EnterDate >= startDate && x.Hbl.ContainerMaster.FileMaster.EnterDate <= endDate).Include(x => x.Hbl.ContainerMaster).Include(x => x.Activity)
                //            .GroupBy(x =>
                //            new
                //            {
                //                x.Activity.Id,
                //                x.StatusId,
                //            }).Select(x => new HBLCount
                //            {
                //                Count = x.Count(),
                //                Status = x.Key.StatusId,
                //                ActivityId = x.Key.Id,
                //            }).ToList();

                //            foreach (ActivityMaster activityMaster in activityList.Where(x => x.IsActive == true && x.ActivityType == "HBL").OrderBy(x => x.FileSequence).ThenBy(x => x.NameOfActivity))
                //            {
                //                dashboard.Completed = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == completed).Sum(x => x.Count);
                //                dashboard.Pending = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == pending).Sum(x => x.Count);
                //                dashboard.Query = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == query).Sum(x => x.Count);
                //                dashboard.WIP = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == wip).Sum(x => x.Count);
                //                dashboard.CompletedWithQuery = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(completedWithQuery)).Sum(x => x.Count);

                //                dashboard.HBLStatusCount.Add(new HBLStatusCount
                //                {
                //                    Completed = dashboard.Completed,
                //                    Pending = dashboard.Pending,
                //                    Query = dashboard.Query,
                //                    WIP = dashboard.WIP,
                //                    CompletedWithQuery = dashboard.CompletedWithQuery
                //                });
                //                dashboard.TotalCompleted = dashboard.TotalCompleted + dashboard.Completed;
                //                dashboard.TotalPending += dashboard.Pending;
                //                dashboard.TotalQuery += dashboard.Query;
                //                dashboard.TotalWIP += dashboard.WIP;
                //                dashboard.TotalCompletedWithQuery += dashboard.CompletedWithQuery;
                //            }
                //        }

                //        var overallTotal = new UserDashboardViewModel
                //        {
                //            User = "Total",
                //            Count = data.Sum(x => x.Count),
                //            TotalCompleted = data.Sum(x => x.TotalCompleted),
                //            TotalPending = data.Sum(x => x.TotalPending),
                //            TotalQuery = data.Sum(x => x.TotalQuery),
                //            TotalWIP = data.Sum(x => x.TotalWIP),
                //            TotalCompletedWithQuery = data.Sum(x => x.TotalCompletedWithQuery),
                //        };

                //        foreach (ActivityMaster activityMaster in activityList.Where(x => x.IsActive == true && x.IsDelete == false && x.ActivityType == "HBL").OrderBy(x => x.FileSequence).ThenBy(x => x.NameOfActivity))
                //        {
                //            var activityTotal = new HBLStatusCount
                //            {
                //                ActivityId = activityMaster.Id,
                //                Completed = data.Sum(x => x.HBLCount
                //                    .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(completed))
                //                    .Sum(c => c.Count)),
                //                Pending = data.Sum(x => x.HBLCount
                //                    .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(pending))
                //                    .Sum(c => c.Count)),
                //                Query = data.Sum(x => x.HBLCount
                //                    .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(query))
                //                    .Sum(c => c.Count)),
                //                WIP = data.Sum(x => x.HBLCount
                //                    .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(wip))
                //                    .Sum(c => c.Count)),
                //                CompletedWithQuery = data.Sum(x => x.HBLCount
                //                    .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(completedWithQuery))
                //                    .Sum(c => c.Count))
                //            };
                //            overallTotal.HBLStatusCount.Add(activityTotal);
                //        }

                //        data.Add(overallTotal);

                //        userdashboardModel.AddRange(data);

                //        // Create a new workbook
                //        using (var workbook = new XLWorkbook())
                //        {
                //            var worksheet = workbook.Worksheets.Add("UserActivity");

                //            // Add headers to the worksheet
                //            worksheet.Cell(1, 1).Value = "User Name";
                //            worksheet.Cell(1, 2).Value = "Total";
                //            worksheet.Cell(1, 3).Value = "Completed";
                //            worksheet.Cell(1, 4).Value = "Pending";
                //            worksheet.Cell(1, 5).Value = "Query";
                //            worksheet.Cell(1, 6).Value = "WIP";

                //            int colIndex = 7;

                //            // Add headers for each activity
                //            foreach (ActivityMaster activity in activityList.Where(x => x.IsActive == true && x.IsDelete == false && x.ActivityType == "HBL").OrderBy(x => x.FileSequence).ThenBy(x => x.NameOfActivity))
                //            {
                //                worksheet.Cell(1, colIndex).Value = $"{activity.NameOfActivity} (C)";
                //                worksheet.Cell(1, colIndex + 1).Value = $"{activity.NameOfActivity} (P)";
                //                worksheet.Cell(1, colIndex + 2).Value = $"{activity.NameOfActivity} (Q)";
                //                worksheet.Cell(1, colIndex + 3).Value = $"{activity.NameOfActivity} (W)";
                //                colIndex += 4;
                //            }

                //            // Populate data in the worksheet
                //            int rowIndex = 2;
                //            foreach (UserDashboardViewModel d in userdashboardModel.Where(x => x.HBLCount != null))
                //            {
                //                worksheet.Cell(rowIndex, 1).Value = d.User;
                //                worksheet.Cell(rowIndex, 2).Value = d.Count;
                //                worksheet.Cell(rowIndex, 3).Value = d.TotalCompleted;
                //                worksheet.Cell(rowIndex, 4).Value = d.TotalPending;
                //                worksheet.Cell(rowIndex, 5).Value = d.TotalQuery;
                //                worksheet.Cell(rowIndex, 6).Value = d.TotalWIP;

                //                colIndex = 7;
                //                foreach (HBLStatusCount hBLStatusCount in d.HBLStatusCount)
                //                {
                //                    worksheet.Cell(rowIndex, colIndex).Value = hBLStatusCount.Completed;
                //                    worksheet.Cell(rowIndex, colIndex + 1).Value = hBLStatusCount.Pending;
                //                    worksheet.Cell(rowIndex, colIndex + 2).Value = hBLStatusCount.Query;
                //                    worksheet.Cell(rowIndex, colIndex + 3).Value = hBLStatusCount.WIP;
                //                    colIndex += 4;
                //                }

                //                rowIndex++;
                //            }

                //            // Create a memory stream to store the Excel file
                //            using (MemoryStream stream = new MemoryStream())
                //            {
                //                workbook.SaveAs(stream);
                //                string excelname = $"ActivityWiseUserHBLProduction-{DateTime.Now.ToString("ddMMyyyy hh:mm:ss")}.xlsx";
                //                return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                //            }
                //        }

                //    }
                //    else if (report.DateType == "EndDate")
                //    {
                //        List<UserDashboardViewModel> userdashboardModel = new List<UserDashboardViewModel>();
                //        ViewData["Activity"] = _context.ActivityMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.FileSequence).ThenBy(x => x.NameOfActivity).ToList();
                //        ViewData["User"] = _context.Users.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CitrixId).ToList();
                //        ViewData["Status"] = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Status).ToList();
                //        var activityList = _context.ActivityMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.FileSequence).ThenBy(x => x.NameOfActivity).ToList();
                //        List<StatusMaster> _status = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Status).ToList();
                //        string completed = _status.Where(x => x.Status == "Completed").Select(x => x.Id).FirstOrDefault();
                //        string pending = _status.Where(x => x.Status == "Pending").Select(x => x.Id).FirstOrDefault();
                //        string query = _status.Where(x => x.Status == "Query").Select(x => x.Id).FirstOrDefault();
                //        string wip = _status.Where(x => x.Status == "WIP").Select(x => x.Id).FirstOrDefault();
                //        string completedWithQuery = _status.Where(x => x.Status == "Completed With Query").Select(x => x.Id).FirstOrDefault();

                //        var data = _context.HBLActivityLog.Where(x => x.EndDate >= startDate && x.EndDate <= endDate).Include(x => x.Hbl.ContainerMaster).GroupBy(x => new
                //        {
                //            x.ApplicationUser.CitrixId,
                //        }).Select(x => new UserDashboardViewModel
                //        {
                //            User = x.Key.CitrixId,
                //            Count = x.Count(),
                //        }).ToList();

                //        foreach (UserDashboardViewModel dashboard in data)
                //        {
                //            dashboard.HBLCount = _context.HBLActivityLog.Where(x => x.ApplicationUser.CitrixId == dashboard.User && x.EndDate >= startDate && x.EndDate <= endDate).Include(x => x.Hbl).Include(x => x.Activity)
                //            .GroupBy(x =>
                //            new
                //            {
                //                x.Activity.Id,
                //                x.StatusId,
                //            }).Select(x => new HBLCount
                //            {
                //                Count = x.Count(),
                //                Status = x.Key.StatusId,
                //                ActivityId = x.Key.Id,
                //            }).ToList();

                //            foreach (ActivityMaster activityMaster in activityList.Where(x => x.IsActive == true && x.IsDelete == false && x.ActivityType == "HBL").OrderBy(x => x.FileSequence).ThenBy(x => x.NameOfActivity))
                //            {
                //                dashboard.Completed = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == completed).Sum(x => x.Count);
                //                dashboard.Pending = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == pending).Sum(x => x.Count);
                //                dashboard.Query = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == query).Sum(x => x.Count);
                //                dashboard.WIP = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == wip).Sum(x => x.Count);
                //                dashboard.CompletedWithQuery = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(completedWithQuery)).Sum(x => x.Count);

                //                dashboard.HBLStatusCount.Add(new HBLStatusCount
                //                {
                //                    Completed = dashboard.Completed,
                //                    Pending = dashboard.Pending,
                //                    Query = dashboard.Query,
                //                    WIP = dashboard.WIP,
                //                    CompletedWithQuery = dashboard.CompletedWithQuery
                //                });
                //                dashboard.TotalCompleted = dashboard.TotalCompleted + dashboard.Completed;
                //                dashboard.TotalPending += dashboard.Pending;
                //                dashboard.TotalQuery += dashboard.Query;
                //                dashboard.TotalWIP += dashboard.WIP;
                //                dashboard.TotalCompletedWithQuery += dashboard.CompletedWithQuery;
                //            }
                //        }

                //        var overallTotal = new UserDashboardViewModel
                //        {
                //            User = "Total",
                //            Count = data.Sum(x => x.Count),
                //            TotalCompleted = data.Sum(x => x.TotalCompleted),
                //            TotalPending = data.Sum(x => x.TotalPending),
                //            TotalQuery = data.Sum(x => x.TotalQuery),
                //            TotalWIP = data.Sum(x => x.TotalWIP),
                //            TotalCompletedWithQuery = data.Sum(x => x.TotalCompletedWithQuery),
                //        };

                //        foreach (ActivityMaster activityMaster in activityList.Where(x => x.IsActive == true && x.IsDelete == false && x.ActivityType == "HBL").OrderBy(x => x.FileSequence).ThenBy(x => x.NameOfActivity))
                //        {
                //            var activityTotal = new HBLStatusCount
                //            {
                //                ActivityId = activityMaster.Id,
                //                Completed = data.Sum(x => x.HBLCount
                //                    .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(completed))
                //                    .Sum(c => c.Count)),
                //                Pending = data.Sum(x => x.HBLCount
                //                    .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(pending))
                //                    .Sum(c => c.Count)),
                //                Query = data.Sum(x => x.HBLCount
                //                    .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(query))
                //                    .Sum(c => c.Count)),
                //                WIP = data.Sum(x => x.HBLCount
                //                    .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(wip))
                //                    .Sum(c => c.Count)),
                //                CompletedWithQuery = data.Sum(x => x.HBLCount
                //                    .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(completedWithQuery))
                //                    .Sum(c => c.Count))
                //            };
                //            overallTotal.HBLStatusCount.Add(activityTotal);
                //        }

                //        data.Add(overallTotal);

                //        userdashboardModel.AddRange(data);

                //        // Create a new workbook
                //        using (var workbook = new XLWorkbook())
                //        {
                //            var worksheet = workbook.Worksheets.Add("UserActivity");

                //            // Add headers to the worksheet
                //            worksheet.Cell(1, 1).Value = "User Name";
                //            worksheet.Cell(1, 2).Value = "Total";
                //            worksheet.Cell(1, 3).Value = "Completed";
                //            worksheet.Cell(1, 4).Value = "Pending";
                //            worksheet.Cell(1, 5).Value = "Query";
                //            worksheet.Cell(1, 6).Value = "WIP";

                //            int colIndex = 7;

                //            // Add headers for each activity
                //            foreach (ActivityMaster activity in activityList.Where(x => x.IsActive == true && x.IsDelete == false && x.ActivityType == "HBL").OrderBy(x => x.FileSequence).ThenBy(x => x.NameOfActivity))
                //            {
                //                worksheet.Cell(1, colIndex).Value = $"{activity.NameOfActivity} (C)";
                //                worksheet.Cell(1, colIndex + 1).Value = $"{activity.NameOfActivity} (P)";
                //                worksheet.Cell(1, colIndex + 2).Value = $"{activity.NameOfActivity} (Q)";
                //                worksheet.Cell(1, colIndex + 3).Value = $"{activity.NameOfActivity} (W)";
                //                colIndex += 4;
                //            }

                //            // Populate data in the worksheet
                //            int rowIndex = 2;
                //            foreach (UserDashboardViewModel d in userdashboardModel.Where(x => x.HBLCount != null))
                //            {
                //                worksheet.Cell(rowIndex, 1).Value = d.User;
                //                worksheet.Cell(rowIndex, 2).Value = d.Count;
                //                worksheet.Cell(rowIndex, 3).Value = d.TotalCompleted;
                //                worksheet.Cell(rowIndex, 4).Value = d.TotalPending;
                //                worksheet.Cell(rowIndex, 5).Value = d.TotalQuery;
                //                worksheet.Cell(rowIndex, 6).Value = d.TotalWIP;

                //                colIndex = 7;
                //                foreach (HBLStatusCount hBLStatusCount in d.HBLStatusCount)
                //                {
                //                    worksheet.Cell(rowIndex, colIndex).Value = hBLStatusCount.Completed;
                //                    worksheet.Cell(rowIndex, colIndex + 1).Value = hBLStatusCount.Pending;
                //                    worksheet.Cell(rowIndex, colIndex + 2).Value = hBLStatusCount.Query;
                //                    worksheet.Cell(rowIndex, colIndex + 3).Value = hBLStatusCount.WIP;
                //                    colIndex += 4;
                //                }

                //                rowIndex++;
                //            }

                //            // Create a memory stream to store the Excel file
                //            using (MemoryStream stream = new MemoryStream())
                //            {
                //                workbook.SaveAs(stream);
                //                string excelname = $"ActivityWiseUserHBLProduction-{DateTime.Now.ToString("ddMMyyyy hh:mm:ss")}.xlsx";
                //                return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                //            }
                //        }
                //    }
                //    else
                //    {

                //        List<UserDashboardViewModel> userdashboardModel = new List<UserDashboardViewModel>();
                //        ViewData["Activity"] = _context.ActivityMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.FileSequence).ThenBy(x => x.NameOfActivity).ToList();
                //        ViewData["User"] = _context.Users.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CitrixId).ToList();
                //        ViewData["Status"] = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Status).ToList();
                //        var activityList = _context.ActivityMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.FileSequence).ThenBy(x => x.NameOfActivity).ToList();
                //        List<StatusMaster> _status = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Status).ToList();
                //        string completed = _status.Where(x => x.Status == "Completed").Select(x => x.Id).FirstOrDefault();
                //        string pending = _status.Where(x => x.Status == "Pending").Select(x => x.Id).FirstOrDefault();
                //        string query = _status.Where(x => x.Status == "Query").Select(x => x.Id).FirstOrDefault();
                //        string wip = _status.Where(x => x.Status == "WIP").Select(x => x.Id).FirstOrDefault();
                //        string completedWithQuery = _status.Where(x => x.Status == "Completed With Query").Select(x => x.Id).FirstOrDefault();

                //        var data = _context.HBLActivityLog.Where(x => x.StartDate >= startDate && x.StartDate <= endDate).Include(x => x.Hbl.ContainerMaster).GroupBy(x => new
                //        {
                //            x.ApplicationUser.CitrixId,
                //        }).Select(x => new UserDashboardViewModel
                //        {
                //            User = x.Key.CitrixId,
                //            Count = x.Count(),
                //        }).ToList();

                //        foreach (UserDashboardViewModel dashboard in data)
                //        {
                //            dashboard.HBLCount = _context.HBLActivityLog.Where(x => x.ApplicationUser.CitrixId == dashboard.User && x.StartDate >= startDate && x.StartDate <= endDate).Include(x => x.Hbl).Include(x => x.Activity)
                //            .GroupBy(x =>
                //            new
                //            {
                //                x.Activity.Id,
                //                x.StatusId,
                //            }).Select(x => new HBLCount
                //            {
                //                Count = x.Count(),
                //                Status = x.Key.StatusId,
                //                ActivityId = x.Key.Id,
                //            }).ToList();

                //            foreach (ActivityMaster activityMaster in activityList.Where(x => x.IsActive == true && x.IsDelete == false && x.ActivityType == "HBL").OrderBy(x => x.FileSequence).ThenBy(x => x.NameOfActivity))
                //            {
                //                dashboard.Completed = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == completed).Sum(x => x.Count);
                //                dashboard.Pending = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == pending).Sum(x => x.Count);
                //                dashboard.Query = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == query).Sum(x => x.Count);
                //                dashboard.WIP = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == wip).Sum(x => x.Count);
                //                dashboard.CompletedWithQuery = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(completedWithQuery)).Sum(x => x.Count);

                //                dashboard.HBLStatusCount.Add(new HBLStatusCount
                //                {
                //                    Completed = dashboard.Completed,
                //                    Pending = dashboard.Pending,
                //                    Query = dashboard.Query,
                //                    WIP = dashboard.WIP,
                //                    CompletedWithQuery = dashboard.CompletedWithQuery
                //                });
                //                dashboard.TotalCompleted = dashboard.TotalCompleted + dashboard.Completed;
                //                dashboard.TotalPending += dashboard.Pending;
                //                dashboard.TotalQuery += dashboard.Query;
                //                dashboard.TotalWIP += dashboard.WIP;
                //                dashboard.TotalCompletedWithQuery += dashboard.CompletedWithQuery;
                //            }
                //        }

                //        var overallTotal = new UserDashboardViewModel
                //        {
                //            User = "Total",
                //            Count = data.Sum(x => x.Count),
                //            TotalCompleted = data.Sum(x => x.TotalCompleted),
                //            TotalPending = data.Sum(x => x.TotalPending),
                //            TotalQuery = data.Sum(x => x.TotalQuery),
                //            TotalWIP = data.Sum(x => x.TotalWIP),
                //            TotalCompletedWithQuery = data.Sum(x => x.TotalCompletedWithQuery),
                //        };

                //        foreach (ActivityMaster activityMaster in activityList.Where(x => x.IsActive == true && x.IsDelete == false && x.ActivityType == "HBL").OrderBy(x => x.FileSequence).ThenBy(x => x.NameOfActivity))
                //        {
                //            var activityTotal = new HBLStatusCount
                //            {
                //                ActivityId = activityMaster.Id,
                //                Completed = data.Sum(x => x.HBLCount
                //                    .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(completed))
                //                    .Sum(c => c.Count)),
                //                Pending = data.Sum(x => x.HBLCount
                //                    .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(pending))
                //                    .Sum(c => c.Count)),
                //                Query = data.Sum(x => x.HBLCount
                //                    .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(query))
                //                    .Sum(c => c.Count)),
                //                WIP = data.Sum(x => x.HBLCount
                //                    .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(wip))
                //                    .Sum(c => c.Count)),
                //                CompletedWithQuery = data.Sum(x => x.HBLCount
                //                    .Where(c => c.ActivityId == activityMaster.Id && c.Status.Contains(completedWithQuery))
                //                    .Sum(c => c.Count))
                //            };
                //            overallTotal.HBLStatusCount.Add(activityTotal);
                //        }

                //        data.Add(overallTotal);

                //        userdashboardModel.AddRange(data);

                //        // Create a new workbook
                //        using (var workbook = new XLWorkbook())
                //        {
                //            var worksheet = workbook.Worksheets.Add("UserActivity");

                //            // Add headers to the worksheet
                //            worksheet.Cell(1, 1).Value = "User Name";
                //            worksheet.Cell(1, 2).Value = "Total";
                //            worksheet.Cell(1, 3).Value = "Completed";
                //            worksheet.Cell(1, 4).Value = "Pending";
                //            worksheet.Cell(1, 5).Value = "Query";
                //            worksheet.Cell(1, 6).Value = "WIP";

                //            int colIndex = 7;

                //            // Add headers for each activity
                //            foreach (ActivityMaster activity in activityList.Where(x => x.IsActive == true && x.IsDelete == false && x.ActivityType == "HBL").OrderBy(x => x.FileSequence).ThenBy(x => x.NameOfActivity))
                //            {
                //                worksheet.Cell(1, colIndex).Value = $"{activity.NameOfActivity} (C)";
                //                worksheet.Cell(1, colIndex + 1).Value = $"{activity.NameOfActivity} (P)";
                //                worksheet.Cell(1, colIndex + 2).Value = $"{activity.NameOfActivity} (Q)";
                //                worksheet.Cell(1, colIndex + 3).Value = $"{activity.NameOfActivity} (W)";
                //                colIndex += 4;
                //            }

                //            // Populate data in the worksheet
                //            int rowIndex = 2;
                //            foreach (UserDashboardViewModel d in userdashboardModel.Where(x => x.HBLCount != null))
                //            {
                //                worksheet.Cell(rowIndex, 1).Value = d.User;
                //                worksheet.Cell(rowIndex, 2).Value = d.Count;
                //                worksheet.Cell(rowIndex, 3).Value = d.TotalCompleted;
                //                worksheet.Cell(rowIndex, 4).Value = d.TotalPending;
                //                worksheet.Cell(rowIndex, 5).Value = d.TotalQuery;
                //                worksheet.Cell(rowIndex, 6).Value = d.TotalWIP;

                //                colIndex = 7;
                //                foreach (HBLStatusCount hBLStatusCount in d.HBLStatusCount)
                //                {
                //                    worksheet.Cell(rowIndex, colIndex).Value = hBLStatusCount.Completed;
                //                    worksheet.Cell(rowIndex, colIndex + 1).Value = hBLStatusCount.Pending;
                //                    worksheet.Cell(rowIndex, colIndex + 2).Value = hBLStatusCount.Query;
                //                    worksheet.Cell(rowIndex, colIndex + 3).Value = hBLStatusCount.WIP;
                //                    colIndex += 4;
                //                }

                //                rowIndex++;
                //            }

                //            // Create a memory stream to store the Excel file
                //            using (MemoryStream stream = new MemoryStream())
                //            {
                //                workbook.SaveAs(stream);
                //                string excelname = $"ActivityWiseUserHBLProduction-{DateTime.Now.ToString("ddMMyyyy hh:mm:ss")}.xlsx";
                //                return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                //            }
                //        }

                //    }

                //}
                //else if (report.ReportType == "ActivityWiseUserFileProduction")
                //{
                //    if (report.DateType == "ReceivedDate")
                //    {
                //        List<UserDashboardViewModel> userdashboardModel = new List<UserDashboardViewModel>();
                //        ViewData["Activity"] = _context.ActivityMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.FileSequence).ThenBy(x => x.NameOfActivity).ToList();
                //        ViewData["User"] = _context.Users.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CitrixId).ToList();
                //        ViewData["Status"] = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Status).ToList();
                //        var activityList = _context.ActivityMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.FileSequence).ThenBy(x => x.NameOfActivity).ToList();
                //        List<StatusMaster> _status = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Status).ToList();
                //        string completed = _status.Where(x => x.Status == "Completed").Select(x => x.Id).FirstOrDefault();
                //        string pending = _status.Where(x => x.Status == "Pending").Select(x => x.Id).FirstOrDefault();
                //        string query = _status.Where(x => x.Status == "Query").Select(x => x.Id).FirstOrDefault();
                //        string wip = _status.Where(x => x.Status == "WIP").Select(x => x.Id).FirstOrDefault();
                //        string completedWithQuery = _status.Where(x => x.Status == "Completed With Query").Select(x => x.Id).FirstOrDefault();

                //        var data = _context.FileActivityLog.Where(x => x.ContainerMaster.FileMaster.EnterDate >= startDate && x.ContainerMaster.FileMaster.EnterDate <= endDate).Include(x => x.ContainerMaster).GroupBy(x => new
                //        {
                //            x.ApplicationUser.CitrixId,
                //        }).Select(x => new UserDashboardViewModel
                //        {
                //            User = x.Key.CitrixId,
                //            Count = x.Count(),
                //        }).ToList();

                //        foreach (UserDashboardViewModel dashboard in data)
                //        {
                //            dashboard.HBLCount = _context.FileActivityLog.Where(x => x.ApplicationUser.CitrixId == dashboard.User && x.ContainerMaster.FileMaster.EnterDate >= startDate && x.ContainerMaster.FileMaster.EnterDate <= endDate).Include(x => x.ContainerMaster).Include(x => x.Activity)
                //            .GroupBy(x =>
                //            new
                //            {
                //                x.Activity.Id,
                //                x.StatusId,
                //            }).Select(x => new HBLCount
                //            {
                //                Count = x.Count(),
                //                Status = x.Key.StatusId,
                //                ActivityId = x.Key.Id,
                //            }).ToList();

                //            foreach (ActivityMaster activityMaster in activityList.Where(x => x.IsActive == true && x.IsDelete == false && x.ActivityType == "File").OrderBy(x => x.FileSequence).ThenBy(x => x.NameOfActivity))
                //            {
                //                dashboard.Completed = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == completed).Sum(x => x.Count);
                //                dashboard.Pending = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == pending).Sum(x => x.Count);
                //                dashboard.Query = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == query).Sum(x => x.Count);
                //                dashboard.WIP = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == wip).Sum(x => x.Count);
                //                dashboard.CompletedWithQuery = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == completedWithQuery).Sum(x => x.Count);

                //                dashboard.HBLStatusCount.Add(new HBLStatusCount
                //                {
                //                    Completed = dashboard.Completed,
                //                    Pending = dashboard.Pending,
                //                    Query = dashboard.Query,
                //                    WIP = dashboard.WIP,
                //                    CompletedWithQuery = dashboard.CompletedWithQuery
                //                });
                //                dashboard.TotalCompleted = dashboard.TotalCompleted + dashboard.Completed;
                //                dashboard.TotalPending += dashboard.Pending;
                //                dashboard.TotalQuery += dashboard.Query;
                //                dashboard.TotalWIP += dashboard.WIP;
                //                dashboard.TotalCompletedWithQuery += dashboard.CompletedWithQuery;
                //            }
                //        }

                //        var overallTotal = new UserDashboardViewModel
                //        {
                //            User = "Total",
                //            Count = data.Sum(x => x.Count),
                //            TotalCompleted = data.Sum(x => x.TotalCompleted),
                //            TotalPending = data.Sum(x => x.TotalPending),
                //            TotalQuery = data.Sum(x => x.TotalQuery),
                //            TotalWIP = data.Sum(x => x.TotalWIP),
                //            TotalCompletedWithQuery = data.Sum(x => x.TotalCompletedWithQuery),
                //        };

                //        foreach (ActivityMaster activityMaster in activityList.Where(x => x.IsActive == true && x.IsDelete == false && x.ActivityType == "File").OrderBy(x => x.FileSequence).ThenBy(x => x.NameOfActivity))
                //        {
                //            var activityTotal = new HBLStatusCount
                //            {
                //                ActivityId = activityMaster.Id,
                //                Completed = data.Sum(x => x.HBLCount
                //                    .Where(c => c.ActivityId == activityMaster.Id && c.Status == completed)
                //                    .Sum(c => c.Count)),
                //                Pending = data.Sum(x => x.HBLCount
                //                    .Where(c => c.ActivityId == activityMaster.Id && c.Status == pending)
                //                    .Sum(c => c.Count)),
                //                Query = data.Sum(x => x.HBLCount
                //                    .Where(c => c.ActivityId == activityMaster.Id && c.Status == query)
                //                    .Sum(c => c.Count)),
                //                WIP = data.Sum(x => x.HBLCount
                //                    .Where(c => c.ActivityId == activityMaster.Id && c.Status == wip)
                //                    .Sum(c => c.Count)),
                //                CompletedWithQuery = data.Sum(x => x.HBLCount
                //                    .Where(c => c.ActivityId == activityMaster.Id && c.Status == completedWithQuery)
                //                    .Sum(c => c.Count))
                //            };
                //            overallTotal.HBLStatusCount.Add(activityTotal);
                //        }

                //        data.Add(overallTotal);

                //        userdashboardModel.AddRange(data);

                //        // Create a new workbook
                //        using (var workbook = new XLWorkbook())
                //        {
                //            var worksheet = workbook.Worksheets.Add("UserActivity");

                //            // Add headers to the worksheet
                //            worksheet.Cell(1, 1).Value = "User Name";
                //            worksheet.Cell(1, 2).Value = "Total";
                //            worksheet.Cell(1, 3).Value = "Completed";
                //            worksheet.Cell(1, 4).Value = "Pending";
                //            worksheet.Cell(1, 5).Value = "Query";
                //            worksheet.Cell(1, 6).Value = "WIP";

                //            int colIndex = 7;

                //            // Add headers for each activity
                //            foreach (ActivityMaster activity in activityList.Where(x => x.IsActive == true && x.IsDelete == false && x.ActivityType == "File").OrderBy(x => x.FileSequence).ThenBy(x => x.NameOfActivity))
                //            {
                //                worksheet.Cell(1, colIndex).Value = $"{activity.NameOfActivity} (C)";
                //                worksheet.Cell(1, colIndex + 1).Value = $"{activity.NameOfActivity} (P)";
                //                worksheet.Cell(1, colIndex + 2).Value = $"{activity.NameOfActivity} (Q)";
                //                worksheet.Cell(1, colIndex + 3).Value = $"{activity.NameOfActivity} (W)";
                //                colIndex += 4;
                //            }

                //            // Populate data in the worksheet
                //            int rowIndex = 2;
                //            foreach (UserDashboardViewModel d in userdashboardModel.Where(x => x.HBLCount != null))
                //            {
                //                worksheet.Cell(rowIndex, 1).Value = d.User;
                //                worksheet.Cell(rowIndex, 2).Value = d.Count;
                //                worksheet.Cell(rowIndex, 3).Value = d.TotalCompleted;
                //                worksheet.Cell(rowIndex, 4).Value = d.TotalPending;
                //                worksheet.Cell(rowIndex, 5).Value = d.TotalQuery;
                //                worksheet.Cell(rowIndex, 6).Value = d.TotalWIP;

                //                colIndex = 7;
                //                foreach (HBLStatusCount hBLStatusCount in d.HBLStatusCount)
                //                {
                //                    worksheet.Cell(rowIndex, colIndex).Value = hBLStatusCount.Completed;
                //                    worksheet.Cell(rowIndex, colIndex + 1).Value = hBLStatusCount.Pending;
                //                    worksheet.Cell(rowIndex, colIndex + 2).Value = hBLStatusCount.Query;
                //                    worksheet.Cell(rowIndex, colIndex + 3).Value = hBLStatusCount.WIP;
                //                    colIndex += 4;
                //                }

                //                rowIndex++;
                //            }

                //            // Create a memory stream to store the Excel file
                //            using (MemoryStream stream = new MemoryStream())
                //            {
                //                workbook.SaveAs(stream);
                //                string excelname = $"ActivityWiseUserFileProduction-{DateTime.Now.ToString("ddMMyyyy hh:mm:ss")}.xlsx";
                //                return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                //            }
                //        }

                //    }
                //    else if (report.DateType == "EndDate")
                //    {
                //        List<UserDashboardViewModel> userdashboardModel = new List<UserDashboardViewModel>();
                //        ViewData["Activity"] = _context.ActivityMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.FileSequence).ThenBy(x => x.NameOfActivity).ToList();
                //        ViewData["User"] = _context.Users.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CitrixId).ToList();
                //        ViewData["Status"] = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Status).ToList();
                //        var activityList = _context.ActivityMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.FileSequence).ThenBy(x => x.NameOfActivity).ToList();
                //        List<StatusMaster> _status = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Status).ToList();
                //        string completed = _status.Where(x => x.Status == "Completed").Select(x => x.Id).FirstOrDefault();
                //        string pending = _status.Where(x => x.Status == "Pending").Select(x => x.Id).FirstOrDefault();
                //        string query = _status.Where(x => x.Status == "Query").Select(x => x.Id).FirstOrDefault();
                //        string wip = _status.Where(x => x.Status == "WIP").Select(x => x.Id).FirstOrDefault();
                //        string completedWithQuery = _status.Where(x => x.Status == "Completed With Query").Select(x => x.Id).FirstOrDefault();

                //        var data = _context.FileActivityLog.Where(x => x.EndDate >= startDate && x.EndDate <= endDate).Include(x => x.ContainerMaster).GroupBy(x => new
                //        {
                //            x.ApplicationUser.CitrixId,
                //        }).Select(x => new UserDashboardViewModel
                //        {
                //            User = x.Key.CitrixId,
                //            Count = x.Count(),
                //        }).ToList();

                //        foreach (UserDashboardViewModel dashboard in data)
                //        {
                //            dashboard.HBLCount = _context.FileActivityLog.Where(x => x.ApplicationUser.CitrixId == dashboard.User && x.EndDate >= startDate && x.EndDate <= endDate).Include(x => x.ContainerMaster).Include(x => x.Activity)
                //            .GroupBy(x =>
                //            new
                //            {
                //                x.Activity.Id,
                //                x.StatusId,
                //            }).Select(x => new HBLCount
                //            {
                //                Count = x.Count(),
                //                Status = x.Key.StatusId,
                //                ActivityId = x.Key.Id,
                //            }).ToList();

                //            foreach (ActivityMaster activityMaster in activityList.Where(x => x.IsActive == true && x.IsDelete == false && x.ActivityType == "File").OrderBy(x => x.FileSequence).ThenBy(x => x.NameOfActivity))
                //            {
                //                dashboard.Completed = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == completed).Sum(x => x.Count);
                //                dashboard.Pending = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == pending).Sum(x => x.Count);
                //                dashboard.Query = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == query).Sum(x => x.Count);
                //                dashboard.WIP = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == wip).Sum(x => x.Count);
                //                dashboard.CompletedWithQuery = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == completedWithQuery).Sum(x => x.Count);

                //                dashboard.HBLStatusCount.Add(new HBLStatusCount
                //                {
                //                    Completed = dashboard.Completed,
                //                    Pending = dashboard.Pending,
                //                    Query = dashboard.Query,
                //                    WIP = dashboard.WIP,
                //                    CompletedWithQuery = dashboard.CompletedWithQuery
                //                });
                //                dashboard.TotalCompleted = dashboard.TotalCompleted + dashboard.Completed;
                //                dashboard.TotalPending += dashboard.Pending;
                //                dashboard.TotalQuery += dashboard.Query;
                //                dashboard.TotalWIP += dashboard.WIP;
                //                dashboard.TotalCompletedWithQuery += dashboard.CompletedWithQuery;
                //            }
                //        }

                //        var overallTotal = new UserDashboardViewModel
                //        {
                //            User = "Total",
                //            Count = data.Sum(x => x.Count),
                //            TotalCompleted = data.Sum(x => x.TotalCompleted),
                //            TotalPending = data.Sum(x => x.TotalPending),
                //            TotalQuery = data.Sum(x => x.TotalQuery),
                //            TotalWIP = data.Sum(x => x.TotalWIP),
                //            TotalCompletedWithQuery = data.Sum(x => x.TotalCompletedWithQuery),
                //        };

                //        foreach (ActivityMaster activityMaster in activityList.Where(x => x.IsActive == true && x.IsDelete == false && x.ActivityType == "File").OrderBy(x => x.FileSequence).ThenBy(x => x.NameOfActivity))
                //        {
                //            var activityTotal = new HBLStatusCount
                //            {
                //                ActivityId = activityMaster.Id,
                //                Completed = data.Sum(x => x.HBLCount
                //                    .Where(c => c.ActivityId == activityMaster.Id && c.Status == completed)
                //                    .Sum(c => c.Count)),
                //                Pending = data.Sum(x => x.HBLCount
                //                    .Where(c => c.ActivityId == activityMaster.Id && c.Status == pending)
                //                    .Sum(c => c.Count)),
                //                Query = data.Sum(x => x.HBLCount
                //                    .Where(c => c.ActivityId == activityMaster.Id && c.Status == query)
                //                    .Sum(c => c.Count)),
                //                WIP = data.Sum(x => x.HBLCount
                //                    .Where(c => c.ActivityId == activityMaster.Id && c.Status == wip)
                //                    .Sum(c => c.Count)),
                //                CompletedWithQuery = data.Sum(x => x.HBLCount
                //                    .Where(c => c.ActivityId == activityMaster.Id && c.Status == completedWithQuery)
                //                    .Sum(c => c.Count))
                //            };
                //            overallTotal.HBLStatusCount.Add(activityTotal);
                //        }

                //        data.Add(overallTotal);

                //        userdashboardModel.AddRange(data);

                //        // Create a new workbook
                //        using (var workbook = new XLWorkbook())
                //        {
                //            var worksheet = workbook.Worksheets.Add("UserActivity");

                //            // Add headers to the worksheet
                //            worksheet.Cell(1, 1).Value = "User Name";
                //            worksheet.Cell(1, 2).Value = "Total";
                //            worksheet.Cell(1, 3).Value = "Completed";
                //            worksheet.Cell(1, 4).Value = "Pending";
                //            worksheet.Cell(1, 5).Value = "Query";
                //            worksheet.Cell(1, 6).Value = "WIP";

                //            int colIndex = 7;

                //            // Add headers for each activity
                //            foreach (ActivityMaster activity in activityList.Where(x => x.IsActive == true && x.IsDelete == false && x.ActivityType == "File").OrderBy(x => x.FileSequence).ThenBy(x => x.NameOfActivity))
                //            {
                //                worksheet.Cell(1, colIndex).Value = $"{activity.NameOfActivity} (C)";
                //                worksheet.Cell(1, colIndex + 1).Value = $"{activity.NameOfActivity} (P)";
                //                worksheet.Cell(1, colIndex + 2).Value = $"{activity.NameOfActivity} (Q)";
                //                worksheet.Cell(1, colIndex + 3).Value = $"{activity.NameOfActivity} (W)";
                //                colIndex += 4;
                //            }

                //            // Populate data in the worksheet
                //            int rowIndex = 2;
                //            foreach (UserDashboardViewModel d in userdashboardModel.Where(x => x.HBLCount != null))
                //            {
                //                worksheet.Cell(rowIndex, 1).Value = d.User;
                //                worksheet.Cell(rowIndex, 2).Value = d.Count;
                //                worksheet.Cell(rowIndex, 3).Value = d.TotalCompleted;
                //                worksheet.Cell(rowIndex, 4).Value = d.TotalPending;
                //                worksheet.Cell(rowIndex, 5).Value = d.TotalQuery;
                //                worksheet.Cell(rowIndex, 6).Value = d.TotalWIP;

                //                colIndex = 7;
                //                foreach (HBLStatusCount hBLStatusCount in d.HBLStatusCount)
                //                {
                //                    worksheet.Cell(rowIndex, colIndex).Value = hBLStatusCount.Completed;
                //                    worksheet.Cell(rowIndex, colIndex + 1).Value = hBLStatusCount.Pending;
                //                    worksheet.Cell(rowIndex, colIndex + 2).Value = hBLStatusCount.Query;
                //                    worksheet.Cell(rowIndex, colIndex + 3).Value = hBLStatusCount.WIP;
                //                    colIndex += 4;
                //                }

                //                rowIndex++;
                //            }

                //            // Create a memory stream to store the Excel file
                //            using (MemoryStream stream = new MemoryStream())
                //            {
                //                workbook.SaveAs(stream);
                //                string excelname = $"ActivityWiseUserFileProduction-{DateTime.Now.ToString("ddMMyyyy hh:mm:ss")}.xlsx";
                //                return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                //            }
                //        }
                //    }
                //    else
                //    {

                //        List<UserDashboardViewModel> userdashboardModel = new List<UserDashboardViewModel>();
                //        ViewData["Activity"] = _context.ActivityMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.FileSequence).ThenBy(x => x.NameOfActivity).ToList();
                //        ViewData["User"] = _context.Users.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CitrixId).ToList();
                //        ViewData["Status"] = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Status).ToList();
                //        var activityList = _context.ActivityMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.FileSequence).ThenBy(x => x.NameOfActivity).ToList();
                //        List<StatusMaster> _status = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Status).ToList();
                //        string completed = _status.Where(x => x.Status == "Completed").Select(x => x.Id).FirstOrDefault();
                //        string pending = _status.Where(x => x.Status == "Pending").Select(x => x.Id).FirstOrDefault();
                //        string query = _status.Where(x => x.Status == "Query").Select(x => x.Id).FirstOrDefault();
                //        string wip = _status.Where(x => x.Status == "WIP").Select(x => x.Id).FirstOrDefault();
                //        string completedWithQuery = _status.Where(x => x.Status == "Completed With Query").Select(x => x.Id).FirstOrDefault();

                //        var data = _context.FileActivityLog.Where(x => x.StartDate >= startDate && x.StartDate <= endDate).Include(x => x.ContainerMaster).GroupBy(x => new
                //        {
                //            x.ApplicationUser.CitrixId,
                //        }).Select(x => new UserDashboardViewModel
                //        {
                //            User = x.Key.CitrixId,
                //            Count = x.Count(),
                //        }).ToList();

                //        foreach (UserDashboardViewModel dashboard in data)
                //        {
                //            dashboard.HBLCount = _context.FileActivityLog.Where(x => x.ApplicationUser.CitrixId == dashboard.User && x.StartDate >= startDate && x.StartDate <= endDate).Include(x => x.ContainerMaster).Include(x => x.Activity)
                //            .GroupBy(x =>
                //            new
                //            {
                //                x.Activity.Id,
                //                x.StatusId,
                //            }).Select(x => new HBLCount
                //            {
                //                Count = x.Count(),
                //                Status = x.Key.StatusId,
                //                ActivityId = x.Key.Id,
                //            }).ToList();

                //            foreach (ActivityMaster activityMaster in activityList.Where(x => x.IsActive == true && x.IsDelete == false && x.ActivityType == "File").OrderBy(x => x.FileSequence).ThenBy(x => x.NameOfActivity))
                //            {
                //                dashboard.Completed = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == completed).Sum(x => x.Count);
                //                dashboard.Pending = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == pending).Sum(x => x.Count);
                //                dashboard.Query = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == query).Sum(x => x.Count);
                //                dashboard.WIP = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == wip).Sum(x => x.Count);
                //                dashboard.CompletedWithQuery = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status == completedWithQuery).Sum(x => x.Count);

                //                dashboard.HBLStatusCount.Add(new HBLStatusCount
                //                {
                //                    Completed = dashboard.Completed,
                //                    Pending = dashboard.Pending,
                //                    Query = dashboard.Query,
                //                    WIP = dashboard.WIP,
                //                    CompletedWithQuery = dashboard.CompletedWithQuery
                //                });
                //                dashboard.TotalCompleted = dashboard.TotalCompleted + dashboard.Completed;
                //                dashboard.TotalPending += dashboard.Pending;
                //                dashboard.TotalQuery += dashboard.Query;
                //                dashboard.TotalWIP += dashboard.WIP;
                //                dashboard.TotalCompletedWithQuery += dashboard.CompletedWithQuery;
                //            }
                //        }

                //        var overallTotal = new UserDashboardViewModel
                //        {
                //            User = "Total",
                //            Count = data.Sum(x => x.Count),
                //            TotalCompleted = data.Sum(x => x.TotalCompleted),
                //            TotalPending = data.Sum(x => x.TotalPending),
                //            TotalQuery = data.Sum(x => x.TotalQuery),
                //            TotalWIP = data.Sum(x => x.TotalWIP),
                //            TotalCompletedWithQuery = data.Sum(x => x.TotalCompletedWithQuery),
                //        };

                //        foreach (ActivityMaster activityMaster in activityList.Where(x => x.IsActive == true && x.IsDelete == false && x.ActivityType == "File").OrderBy(x => x.FileSequence).ThenBy(x => x.NameOfActivity))
                //        {
                //            var activityTotal = new HBLStatusCount
                //            {
                //                ActivityId = activityMaster.Id,
                //                Completed = data.Sum(x => x.HBLCount
                //                    .Where(c => c.ActivityId == activityMaster.Id && c.Status == completed)
                //                    .Sum(c => c.Count)),
                //                Pending = data.Sum(x => x.HBLCount
                //                    .Where(c => c.ActivityId == activityMaster.Id && c.Status == pending)
                //                    .Sum(c => c.Count)),
                //                Query = data.Sum(x => x.HBLCount
                //                    .Where(c => c.ActivityId == activityMaster.Id && c.Status == query)
                //                    .Sum(c => c.Count)),
                //                WIP = data.Sum(x => x.HBLCount
                //                    .Where(c => c.ActivityId == activityMaster.Id && c.Status == wip)
                //                    .Sum(c => c.Count)),
                //                CompletedWithQuery = data.Sum(x => x.HBLCount
                //                    .Where(c => c.ActivityId == activityMaster.Id && c.Status == completedWithQuery)
                //                    .Sum(c => c.Count))
                //            };
                //            overallTotal.HBLStatusCount.Add(activityTotal);
                //        }

                //        data.Add(overallTotal);

                //        userdashboardModel.AddRange(data);

                //        // Create a new workbook
                //        using (var workbook = new XLWorkbook())
                //        {
                //            var worksheet = workbook.Worksheets.Add("UserActivity");

                //            // Add headers to the worksheet
                //            worksheet.Cell(1, 1).Value = "User Name";
                //            worksheet.Cell(1, 2).Value = "Total";
                //            worksheet.Cell(1, 3).Value = "Completed";
                //            worksheet.Cell(1, 4).Value = "Pending";
                //            worksheet.Cell(1, 5).Value = "Query";
                //            worksheet.Cell(1, 6).Value = "WIP";

                //            int colIndex = 7;

                //            // Add headers for each activity
                //            foreach (ActivityMaster activity in activityList.Where(x => x.IsActive == true && x.IsDelete == false && x.ActivityType == "File").OrderBy(x => x.FileSequence).ThenBy(x => x.NameOfActivity))
                //            {
                //                worksheet.Cell(1, colIndex).Value = $"{activity.NameOfActivity} (C)";
                //                worksheet.Cell(1, colIndex + 1).Value = $"{activity.NameOfActivity} (P)";
                //                worksheet.Cell(1, colIndex + 2).Value = $"{activity.NameOfActivity} (Q)";
                //                worksheet.Cell(1, colIndex + 3).Value = $"{activity.NameOfActivity} (W)";
                //                colIndex += 4;
                //            }

                //            // Populate data in the worksheet
                //            int rowIndex = 2;
                //            foreach (UserDashboardViewModel d in userdashboardModel.Where(x => x.HBLCount != null))
                //            {
                //                worksheet.Cell(rowIndex, 1).Value = d.User;
                //                worksheet.Cell(rowIndex, 2).Value = d.Count;
                //                worksheet.Cell(rowIndex, 3).Value = d.TotalCompleted;
                //                worksheet.Cell(rowIndex, 4).Value = d.TotalPending;
                //                worksheet.Cell(rowIndex, 5).Value = d.TotalQuery;
                //                worksheet.Cell(rowIndex, 6).Value = d.TotalWIP;

                //                colIndex = 7;
                //                foreach (HBLStatusCount hBLStatusCount in d.HBLStatusCount)
                //                {
                //                    worksheet.Cell(rowIndex, colIndex).Value = hBLStatusCount.Completed;
                //                    worksheet.Cell(rowIndex, colIndex + 1).Value = hBLStatusCount.Pending;
                //                    worksheet.Cell(rowIndex, colIndex + 2).Value = hBLStatusCount.Query;
                //                    worksheet.Cell(rowIndex, colIndex + 3).Value = hBLStatusCount.WIP;
                //                    colIndex += 4;
                //                }

                //                rowIndex++;
                //            }

                //            // Create a memory stream to store the Excel file
                //            using (MemoryStream stream = new MemoryStream())
                //            {
                //                workbook.SaveAs(stream);
                //                string excelname = $"ActivityWiseUserFileProduction-{DateTime.Now.ToString("ddMMyyyy hh:mm:ss")}.xlsx";
                //                return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                //            }
                //        }
                //    }
                //}
            }
            else
            {
                ViewBag.ErrorMessage = "Please Select Date";
            }

            return View();
        }
        public DataTable ToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);
            //Get all the properties by using reflection   
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Setting column names as Property names  
                dataTable.Columns.Add(prop.Name);
            }
            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {

                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }

            return dataTable;
        }

        [Authorize(Roles = "Admin,Supervisor,Manager")]
        [HttpGet]
        public IActionResult ActivityMapping()
        {
            ViewData["HBLStatusList"] = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.BasedOn == "HBL" && x.ThreadMaster.IsActive == true && x.IsActive == true).ToList();

            var result = _ctx.ActivityMaster.Include(x => x.ThreadMaster)
                            .Where(x => x.BasedOn == "File" && x.ThreadMaster.IsActive == true && x.IsActive == true)
                            .Select(x => new ActivityMapModel
                            {
                                FileActivityId = x.Id,
                                FileActivityName = x.Name,
                                ThreadName = x.ThreadMaster.Name,
                                HBLMappedActivityList = _ctx.ActivityMapping.Include(y => y.HBLActivityMaster).Where(y => y.FileActivityMaster.Id == x.Id).Select(y => y.HBLActivityMaster.Id).ToList()
                            }).ToList();

            return View(result);
        }

        [HttpPost]
        public IActionResult ActivityMapping(ActivityMapModel activitymap)
        {
            var assignedHBLStatus = _ctx.ActivityMapping.Where(x => x.FileActivityMaster.Id == activitymap.FileActivityId).ToList();

            try
            {
                _ctx.RemoveRange(assignedHBLStatus);

                if (activitymap.HBLMappedActivityList != null)
                    foreach (var multi in activitymap.HBLMappedActivityList)
                    {
                        _ctx.ActivityMapping.Add(new ActivityMapping
                        {
                            Id = Guid.NewGuid().ToString(),
                            FileActivityId = activitymap.FileActivityId,
                            HBLActivityId = multi.ToString(),
                            IsActive = true
                        });
                    }

                _ctx.SaveChanges();
                return Json("success");

            }
            catch (Exception ex)
            {
                return Json("failed");
            }
        }
        public JsonResult MultiAllocate(MultipleAllocationViewModel model)
        {
            if (model.multiSelectViewModels != null)
            {
                foreach (var multilist in model.multiSelectViewModels)
                {
                    List<FileActivity> fileActivitiesList = _ctx.FileActivity.Where(x => x.FileId == multilist.eId).ToList();

                    foreach (FileActivity fileActivity in fileActivitiesList)
                    {
                        if (fileActivity != null)
                        {
                            fileActivity.UserId = model.uname;
                            _ctx.FileActivity.Update(fileActivity);
                        }
                    }
                }
                _ctx.SaveChanges();
                return Json("Success");
            }
            else
            {
                return Json("Failed");
            }

        }

        public JsonResult MultiDeAllocate(MultipleAllocationViewModel model)
        {
            if (model.multiSelectViewModels != null)
            {
                foreach (var multilist in model.multiSelectViewModels)
                {
                    List<FileActivity> fileActivitiesList = _ctx.FileActivity.Include(x => x.FileEntry).Include(x => x.User).Include(x => x.ActivityMaster).ThenInclude(x => x.ThreadMaster).Where(x => x.FileId == multilist.eId && x.ActivityMaster.IsActive == true && x.User.IsActive == true && x.ActivityMaster.ThreadMaster.IsActive == true).ToList();

                    foreach (FileActivity fileActivity in fileActivitiesList)
                    {
                        if (fileActivity != null)
                        {
                            fileActivity.UserId = model.uname;
                            _ctx.FileActivity.Update(fileActivity);
                        }
                    }
                }
                _ctx.SaveChanges();
                return Json("Success");
            }
            else
            {
                return Json("Failed");
            }

        }

        [HttpPost]
        public JsonResult MultiDiscard(MultipleAllocationViewModel model, string status, string comment)
        {
            if (status == null || status == "--select--")
            {
                return Json("status");
            }
            else if (model.multiSelectViewModels.Count() == 0)
            {
                return Json("checkbox");
            }
            else if (model.multiSelectViewModels.Count != 0 && (status != null || status != "--select--"))
            {
                foreach (var multilist in model.multiSelectViewModels)
                {
                    List<FileActivity> fileActivitiesList = _ctx.FileActivity.Include(x => x.FileEntry).Include(x => x.User).Include(x => x.ActivityMaster).ThenInclude(x => x.ThreadMaster).Where(x => x.FileId == multilist.eId && x.ActivityMaster.IsActive == true && x.User.IsActive == true && x.ActivityMaster.ThreadMaster.IsActive == true).ToList();

                    foreach (FileActivity fileActivity in fileActivitiesList)
                    {
                        if (fileActivity != null)
                        {
                            fileActivity.CurrentStatus = status;
                            fileActivity.Comment = comment;
                            _ctx.FileActivity.Update(fileActivity);
                        }
                    }
                }
                _ctx.SaveChanges();
                return Json("Success");
            }
            else
            {
                return Json("Failed");
            }

        }

        public JsonResult FileDetails(FileDetailsViewModel model)
        {
            var result = _ctx.FileEntry.Where(x => x.Id == model.Filedetails.Id).FirstOrDefault();
            if (result != null)
            {

            }

            return Json(model);
        }

        [HttpPost]
        public IActionResult PreAlertDataReport(string fileno, string type, string etadate, string container, string status, string thread, string user)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            int totalRecord = 0;
            int filterRecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var fileActivity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.ThreadMaster.IsActive == true && x.IsActive == true).OrderBy(x => x.BasedOn).ThenBy(x => x.Name).ToList();

            IQueryable<FileEntry> data = _ctx.Set<FileEntry>().AsQueryable();

            totalRecord = data.Count();
            var indiaTimeZone = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");

            if (!string.IsNullOrEmpty(fileno))
            {
                data = data.Where(x => x.FileNo == fileno.Trim());

            }
            if (!string.IsNullOrEmpty(type) && type != "all" && type != "--select--")
            {
                data = data.Where(x => x.FileType == type.Trim());

            }
            if (!string.IsNullOrEmpty(etadate))
            {
                data = data.Where(x => x.EtaAtPod == Convert.ToDateTime(etadate));

            }

            if (!string.IsNullOrEmpty(container))
            {
                data = data.Where(x => x.ContainerNo == container.Trim());

            }

            if (!string.IsNullOrEmpty(user) && user != "none" && user != "--select--")
            {
                data = data.Where(x => x.CreatedBy == user.Trim());

            }

            if (!string.IsNullOrEmpty(status) && status != "none" && status != "--select--")
            {
                data = data.Where(x => x.Status == status.Trim());

            }

            if (searchValue == "WIP" || searchValue == "Completed" || searchValue == "Pending" || searchValue == "Query" ||
                        searchValue == "Received" || searchValue == "UnAllocated" || searchValue == "eta10" || searchValue == "eta12")
            {
                if (searchValue == "eta10")
                {
                    data = data.Where(x => x.EtaAtPod != null && Convert.ToDateTime(x.EtaAtPod).AddDays(-10) <= DateTime.Now && (x.Status != "Completed"));

                }
                else if (searchValue == "eta12")
                {
                    data = data.Where(x => x.EtaAtPod != null && Convert.ToDateTime(x.EtaAtPod).AddDays(-10) > DateTime.Now && Convert.ToDateTime(x.EtaAtPod).AddDays(-12) <= DateTime.Now && x.Status != "Completed");
                }

                else
                {
                    data = data.Where(x => x.Status == searchValue);
                }
            }

            if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
                data = data.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();

            //var fileEntryData = new List<FileEntryData>();
            //var fileEntryViewModels = data.Include(x => x.FileActivity).ThenInclude(x => x.ActivityMaster.ThreadMaster).Select(x => new
            //{
            //    Pod = _ctx.LocationMaster.Where(y => y.Id == x.Pod).Select(y => y.Name).FirstOrDefault(),
            //    EtaAtPod = x.EtaAtPod,
            //    CreatedDate = x.CreatedDate,
            //    ContainerNo = x.ContainerNo,
            //    Pol = _ctx.POLMaster.Where(y => y.Id == x.Pol).Select(y => y.Name).FirstOrDefault(),
            //    AllocatedTo = _ctx.FileActivity.Where(y => y.FileId == x.Id).OrderByDescending(y => y.EnterDate).Select(y => _ctx.User.Where(z => z.Id == y.UserId).Select(z => z.UserName).FirstOrDefault()).FirstOrDefault(),
            //    Status = _ctx.FileActivity.Where(y => y.FileId == x.Id).OrderByDescending(y => y.EnterDate).Select(y => y.CurrentStatus).FirstOrDefault(),
            //    ThreadName = _ctx.FileActivity.Where(y => y.FileId == x.Id && y.ActivityMaster.ThreadMaster.IsActive == true && y.ActivityMaster.IsActive == true).OrderByDescending(y => y.EnterDate).Select(y => y.ActivityMaster.ThreadMaster.Name).FirstOrDefault(),
            //    FileType = x.FileType,
            //    ProductType = x.ProductType,
            //    Hblcount = x.Hblcount,
            //    IsEdi = x.IsEdi == true ? "Yes" : "No",
            //    FileNo = x.FileNo,
            //    VesselName = x.VesselName,
            //    ShippingLine = x.ShippingLine,

            //}).ToList();

            //DataTable dt = new DataTable();
            //dt.Columns.Add("Pod");
            //dt.Columns.Add("EtaAtPod");
            //dt.Columns.Add("Received Date");
            //dt.Columns.Add("ContainerNo");
            //dt.Columns.Add("Pol");
            //dt.Columns.Add("AllocatedTo");
            //dt.Columns.Add("Status");
            //dt.Columns.Add("ThreadName");
            //dt.Columns.Add("FileType");
            //dt.Columns.Add("ProductType");
            //dt.Columns.Add("Hblcount");
            //dt.Columns.Add("IsEdi");
            //dt.Columns.Add("FileNo");
            //dt.Columns.Add("VesselName");
            //dt.Columns.Add("ShippingLine");

            //foreach (var file in fileEntryViewModels)
            //{

            //    DataRow tr = dt.NewRow();
            //    tr[0] = file.Pod;
            //    tr[1] = file.EtaAtPod;
            //    tr[2] = file.CreatedDate;
            //    tr[3] = file.ContainerNo;
            //    tr[4] = file.Pol;
            //    tr[5] = file.AllocatedTo;
            //    tr[6] = file.Status;
            //    tr[7] = file.ThreadName;
            //    tr[8] = file.FileType;
            //    tr[9] = file.ProductType;
            //    tr[10] = file.Hblcount;
            //    tr[11] = file.IsEdi;
            //    tr[12] = file.FileNo;
            //    tr[13] = file.VesselName;
            //    tr[14] = file.ShippingLine;
            //    dt.Rows.Add(tr);

            //}

            //using (XLWorkbook wb = new XLWorkbook())
            //{
            //    dt.TableName = "Pre-Alert Report";

            //    var wsFileData = wb.Worksheets.Add(dt);

            //    using (MemoryStream stream = new MemoryStream())
            //    {
            //        wb.SaveAs(stream);
            //        string excelname = $"PreAlertReport-{DateTime.Now.ToString("ddmmyyyy hh:mm:ss")}.xlsx";
            //        return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
            //    }
            //}

            var fileEntryData = new List<FileEntryData>();
            var fileEntryViewModels = data
                    .Include(x => x.FileActivity)
                    .ThenInclude(fa => fa.ActivityMaster)
                    .ThenInclude(am => am.ThreadMaster)
                    .Select(x => new
                    {
                        CreatedDate = x.CreatedDate.HasValue
                            ? TimeZoneInfo.ConvertTimeFromUtc(x.CreatedDate.Value, indiaTimeZone)
                            : (DateTime?)null,
                        FileNo = x.FileNo,
                        ContainerNo = x.ContainerNo,
                        IsEdi = x.IsEdi,
                        Pol = x.Pol,
                        Pod = _ctx.LocationMaster
                            .Where(y => y.Id == x.Pod && y.IsActive)
                            .Select(y => y.Name)
                            .FirstOrDefault(),
                        FileType = x.FileType,
                        Hblcount = x.Hblcount,
                        EtaAtPod = x.EtaAtPod.HasValue
                            ? TimeZoneInfo.ConvertTimeFromUtc(x.EtaAtPod.Value, indiaTimeZone)
                            : (DateTime?)null,
                        VesselName = x.VesselName,
                        ShippingLine = x.ShippingLine,
                        ThreadName = x.FileActivity
                            .Where(fa => fa.FileId == x.Id && fa.ActivityMaster.IsActive == true && fa.User.IsActive == true && fa.ActivityMaster.ThreadMaster.IsActive == true)
                            .OrderByDescending(fa => fa.EnterDate)
                            .Select(fa => fa.ActivityMaster.ThreadMaster.Name)
                            .FirstOrDefault(),
                        Status = x.FileActivity
                            .Where(fa => fa.FileId == x.Id && fa.ActivityMaster.IsActive == true && fa.User.IsActive == true && fa.ActivityMaster.ThreadMaster.IsActive == true)
                            .OrderByDescending(fa => fa.EnterDate)
                            .Select(fa => fa.CurrentStatus)
                            .FirstOrDefault(),
                        AllocatedTo = x.FileActivity
                            .Where(fa => fa.FileId == x.Id && fa.ActivityMaster.IsActive == true && fa.User.IsActive == true && fa.ActivityMaster.ThreadMaster.IsActive == true)
                            .OrderByDescending(fa => fa.EnterDate)
                            .Select(fa => fa.User != null ? fa.User.UserName : null)
                            .FirstOrDefault(),
                    }).ToList();

            DataTable dt = new DataTable();
            dt.Columns.Add("Received Date");
            dt.Columns.Add("FileNo");
            dt.Columns.Add("ContainerNo");
            dt.Columns.Add("IsEdi");
            dt.Columns.Add("Pol");
            dt.Columns.Add("Pod");
            dt.Columns.Add("FileType");
            dt.Columns.Add("Hblcount");
            dt.Columns.Add("EtaAtPod");
            dt.Columns.Add("VesselName");
            dt.Columns.Add("ShippingLine");
            dt.Columns.Add("ThreadName");
            dt.Columns.Add("Status");
            dt.Columns.Add("AllocatedTo");

            foreach (var file in fileEntryViewModels)
            {

                DataRow tr = dt.NewRow();
                tr[0] = file.CreatedDate;
                tr[1] = file.FileNo;
                tr[2] = file.ContainerNo;
                tr[3] = file.IsEdi;
                tr[4] = file.Pol;
                tr[5] = file.Pod;
                tr[6] = file.FileType;
                tr[7] = file.Hblcount;
                tr[8] = file.EtaAtPod;
                tr[9] = file.VesselName;
                tr[10] = file.ShippingLine;
                tr[11] = file.ThreadName;
                tr[12] = file.Status;
                tr[13] = file.AllocatedTo;
                dt.Rows.Add(tr);

            }

            using (XLWorkbook wb = new XLWorkbook())
            {
                dt.TableName = "Pre-Alert Report";
                var wsFileData = wb.Worksheets.Add(dt);
                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    string excelname = $"PreAlertReport-{DateTime.Now.ToString("ddmmyyyy hh:mm:ss")}.xlsx";
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                }
            }
        }

        [HttpPost]
        public IActionResult PreAlertDataDownload(string fileno, string type, string etadate, string container, string status, string thread, string user)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            int totalRecord = 0;
            int filterRecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var fileActivity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.ThreadMaster.IsActive == true && x.IsActive == true).OrderBy(x => x.BasedOn).ThenBy(x => x.Name).ToList();

            IQueryable<FileEntry> data = _ctx.Set<FileEntry>().AsQueryable();

            totalRecord = data.Count();

            if (!string.IsNullOrEmpty(fileno))
            {
                data = data.Where(x => x.FileNo == fileno.Trim());

            }
            if (!string.IsNullOrEmpty(type) && type != "all" && type != "--select--")
            {
                data = data.Where(x => x.FileType == type.Trim());

            }
            if (!string.IsNullOrEmpty(etadate))
            {
                data = data.Where(x => x.EtaAtPod == Convert.ToDateTime(etadate));

            }

            if (!string.IsNullOrEmpty(container))
            {
                data = data.Where(x => x.ContainerNo == container.Trim());

            }

            if (!string.IsNullOrEmpty(user) && user != "none" && user != "--select--")
            {
                data = data.Where(x => x.CreatedBy == user.Trim());

            }

            if (!string.IsNullOrEmpty(status) && status != "none" && status != "--select--")
            {
                data = data.Where(x => x.Status == status.Trim());

            }

            if (searchValue == "WIP" || searchValue == "Completed" || searchValue == "Pending" || searchValue == "Query" ||
                        searchValue == "Received" || searchValue == "UnAllocated" || searchValue == "eta10" || searchValue == "eta12")
            {
                if (searchValue == "eta10")
                {
                    data = data.Where(x => x.EtaAtPod != null && Convert.ToDateTime(x.EtaAtPod).AddDays(-10) <= DateTime.Now && (x.Status != "Completed"));

                }
                else if (searchValue == "eta12")
                {
                    data = data.Where(x => x.EtaAtPod != null && Convert.ToDateTime(x.EtaAtPod).AddDays(-10) > DateTime.Now && Convert.ToDateTime(x.EtaAtPod).AddDays(-12) <= DateTime.Now && x.Status != "Completed");
                }

                else
                {
                    data = data.Where(x => x.Status == searchValue);
                }
            }


            //var fileEntryData = new List<FileEntryData>();
            //var fileEntryViewModels = data.Include(x => x.FileActivity).ThenInclude(x => x.ActivityMaster.ThreadMaster).Select(x => new
            //{
            //    Pod = _ctx.LocationMaster.Where(y => y.Id == x.Pod).Select(y => y.Name).FirstOrDefault(),
            //    EtaAtPod = x.EtaAtPod,
            //    CreatedDate = x.CreatedDate,
            //    ContainerNo = x.ContainerNo,
            //    Pol = _ctx.POLMaster.Where(y => y.Id == x.Pol).Select(y => y.Name).FirstOrDefault(),
            //    FileType = x.FileType,
            //    ProductType = x.ProductType,
            //    Hblcount = x.Hblcount,
            //    IsEdi = x.IsEdi == true ? "Yes" : "No",
            //    FileNo = x.FileNo,
            //    VesselName = x.VesselName,
            //    ShippingLine = x.ShippingLine,

            //}).ToList();


            //var fileActivityList = _ctx.FileEntry.Include(x => x.User).Include(x => x.FileActivity).ThenInclude(x => x.ActivityMaster).Include(x => x.FileActivity).ThenInclude(x => x.User).ToList();
            //foreach (var file in fileActivity)
            //{
            //    foreach (var item in fileActivityList)
            //    {
            //        fileEntryData.Add(new FileEntryData
            //        {
            //            FileId = item.FileNo,
            //            Activity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.Id == file.Id && x.BasedOn == "File" && x.ThreadMaster.IsActive == true && x.IsActive == true).Select(x => x.Name).FirstOrDefault(),
            //            Date = item.FileActivity.Where(x => x.ActivityId == file.Id && x.UserId != null).Select(x => x.EndTime).FirstOrDefault(),
            //            Status = item.FileActivity.Where(x => x.ActivityId == file.Id && x.UserId != null).Select(x => x.CurrentStatus).FirstOrDefault(),
            //            UserName = item.FileActivity.Where(x => x.ActivityId == file.Id && x.UserId != null).Select(x => x.User.UserName).FirstOrDefault(),
            //            Comment = item.FileActivity.Where(x => x.ActivityId == file.Id && x.UserId != null).Select(x => x.Comment).FirstOrDefault()
            //        });
            //    }

            //}

            //DataTable dt = new DataTable();
            //dt.Columns.Add("Pod");
            //dt.Columns.Add("EtaAtPod");
            //dt.Columns.Add("Received Date");
            //dt.Columns.Add("ContainerNo");
            //dt.Columns.Add("Pol");
            //dt.Columns.Add("FileType");
            //dt.Columns.Add("ProductType");
            //dt.Columns.Add("Hblcount");
            //dt.Columns.Add("IsEdi");
            //dt.Columns.Add("FileNo");
            //dt.Columns.Add("VesselName");
            //dt.Columns.Add("ShippingLine");
            //foreach (var item in _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.BasedOn == "File" && x.ThreadMaster.IsActive == true && x.IsActive == true).OrderBy(x => x.ThreadMaster.Sequance))
            //{
            //    dt.Columns.Add(item.Name + "_" + "Status");
            //    dt.Columns.Add(item.Name + "_" + "Date");
            //    dt.Columns.Add(item.Name + "_" + "UserName");
            //    dt.Columns.Add(item.Name + "_" + "Comment");
            //}
            ////foreach (var file in fileEntryViewModels)
            ////{
            ////    foreach (var item in fileActivity)
            ////    {
            ////        foreach (var dr in fileEntryData.Where(x => x.Activity == item.Name))
            ////        {
            ////            DataRow tr = dt.NewRow();
            ////            tr[0] = file.FileNo;
            ////            tr[1] = file.ContainerNo;
            ////            tr[2] = file.IsEdi;
            ////            tr[3] = file.Pol;
            ////            tr[4] = file.Pod;
            ////            tr[5] = file.FinalDestination;
            ////            tr[6] = file.FileType;
            ////            tr[7] = file.Hblcount;
            ////            tr[8] = file.Cbm;
            ////            tr[9] = file.CoLoader;
            ////            tr[10] = file.SailingDate;
            ////            tr[11] = file.EtaAtPod;
            ////            tr[12] = file.VesselName;
            ////            tr[13] = file.ShippingLine;
            ////            tr[14] = file.ContactPerson;
            ////            tr[item.Name + "_" + "Status"] = dr.Status;
            ////            tr[item.Name + "_" + "Date"] = dr.Date;
            ////            tr[item.Name + "_" + "UserName"] = dr.UserName;
            ////            tr[item.Name + "_" + "Comment"] = dr.Comment;
            ////            dt.Rows.Add(tr);
            ////        }
            ////    }
            ////}

            //foreach (var file in fileEntryViewModels)
            //{
            //    // Create a new DataRow for each file
            //    DataRow tr = dt.NewRow();
            //    tr[0] = file.Pod;
            //    tr[1] = file.EtaAtPod;
            //    tr[2] = file.CreatedDate;
            //    tr[3] = file.ContainerNo;
            //    tr[4] = file.Pol;
            //    tr[5] = file.FileType;
            //    tr[6] = file.ProductType;
            //    tr[7] = file.Hblcount;
            //    tr[8] = file.IsEdi;
            //    tr[9] = file.FileNo;
            //    tr[10] = file.VesselName;
            //    tr[11] = file.ShippingLine;


            //    foreach (var item in fileActivity)
            //    {
            //        foreach (var dr in fileEntryData.Where(x => x.Activity == item.Name && x.FileId == file.FileNo))
            //        {
            //            // Add activity data to the DataRow
            //            tr[item.Name + "_" + "Status"] = dr.Status;
            //            tr[item.Name + "_" + "Date"] = dr.Date;
            //            tr[item.Name + "_" + "UserName"] = dr.UserName;
            //            tr[item.Name + "_" + "Comment"] = dr.Comment;
            //        }
            //    }

            //    // Add the DataRow to the DataTable
            //    dt.Rows.Add(tr);
            //}




            //using (XLWorkbook wb = new XLWorkbook())
            //{
            //    dt.TableName = "Pre-Alert File Log";

            //    var wsFileData = wb.Worksheets.Add(dt);

            //    using (MemoryStream stream = new MemoryStream())
            //    {
            //        wb.SaveAs(stream);
            //        string excelname = $"FileActivityStatusReport-{DateTime.Now.ToString("ddmmyyyy hh:mm:ss")}.xlsx";
            //        return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
            //    }
            //}

            var fileEntryData = new List<FileEntryData>();
            var indiaTimeZone = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");

            var fileEntryViewModels = data
                .Include(x => x.FileActivity)
                    .ThenInclude(x => x.ActivityMaster)
                    .ThenInclude(x => x.ThreadMaster)
                .Select(x => new
                {
                    CreatedDate = x.CreatedDate.HasValue
                        ? TimeZoneInfo.ConvertTimeFromUtc(x.CreatedDate.Value, indiaTimeZone)
                        : (DateTime?)null,
                    FileNo = x.FileNo,
                    ContainerNo = x.ContainerNo,
                    IsEdi = x.IsEdi,
                    Pol = x.Pol,
                    Pod = _ctx.LocationMaster
                        .Where(y => y.Id == x.Pod && y.IsActive)
                        .Select(y => y.Name)
                        .FirstOrDefault(),
                    FileType = x.FileType,
                    Hblcount = x.Hblcount,
                    EtaAtPod = x.EtaAtPod.HasValue
                        ? TimeZoneInfo.ConvertTimeFromUtc(x.EtaAtPod.Value, indiaTimeZone)
                        : (DateTime?)null,
                    VesselName = x.VesselName,
                    ShippingLine = x.ShippingLine,
                }).ToList();

            var fileActivityList = _ctx.FileEntry.Include(x => x.User).Include(x => x.FileActivity).ThenInclude(x => x.ActivityMaster)
                    .ThenInclude(x => x.ThreadMaster).ToList();

            foreach (var file in fileActivity/*.OrderBy(x => x.Sequence).ThenBy(x => x.Name)*/)
            {
                foreach (var item in fileActivityList)
                {
                    fileEntryData.Add(new FileEntryData
                    {
                        FileId = item.FileNo,
                        Activity = _ctx.ActivityMaster.Where(x => x.Id == file.Id && x.BasedOn == "File" && x.IsActive == true && x.ThreadMaster.IsActive == true).Select(x => x.Name).FirstOrDefault(),
                        Date = item.FileActivity.Where(x => x.ActivityId == file.Id && x.ActivityMaster.IsActive == true && x.ActivityMaster.ThreadMaster.IsActive == true).Select(x => x.EndTime != null ? TimeZoneInfo.ConvertTimeFromUtc(x.EndTime.Value, TimeZoneInfo.FindSystemTimeZoneById("India Standard Time")) : (DateTime?)null).FirstOrDefault(),
                        Status = item.FileActivity.Where(x => x.ActivityId == file.Id && x.ActivityMaster.IsActive == true && x.ActivityMaster.ThreadMaster.IsActive == true).Select(x => x.CurrentStatus).FirstOrDefault(),
                        UserName = item.FileActivity.Where(x => x.ActivityId == file.Id && x.ActivityMaster.IsActive == true && x.ActivityMaster.ThreadMaster.IsActive == true).Select(x => x.User == null ? null : x.User.UserName).FirstOrDefault(),
                        Comment = item.FileActivity.Where(x => x.ActivityId == file.Id && x.ActivityMaster.IsActive == true && x.ActivityMaster.ThreadMaster.IsActive == true).Select(x => x.Comment).FirstOrDefault()
                    });
                }
            }

            DataTable dt = new DataTable();
            dt.Columns.Add("Received Date");
            dt.Columns.Add("FileNo");
            dt.Columns.Add("ContainerNo");
            dt.Columns.Add("IsEdi");
            dt.Columns.Add("Pol");
            dt.Columns.Add("Pod");
            dt.Columns.Add("FileType");
            dt.Columns.Add("Hblcount");
            dt.Columns.Add("EtaAtPod");
            dt.Columns.Add("VesselName");
            dt.Columns.Add("ShippingLine");
            foreach (var item in _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.BasedOn == "File"
                        && x.ThreadMaster.IsActive == true)/*.OrderBy(x => x.ThreadMaster.Sequence)*/
            )
            {
                dt.Columns.Add(item.Name + "_" + "Status");
                dt.Columns.Add(item.Name + "_" + "Date");
                dt.Columns.Add(item.Name + "_" + "UserName");
                dt.Columns.Add(item.Name + "_" + "Comment");
            }

            foreach (var file in fileEntryViewModels)
            {
                // Create a new DataRow for each file
                DataRow tr = dt.NewRow();
                tr[0] = file.CreatedDate;
                tr[1] = file.FileNo;
                tr[2] = file.ContainerNo;
                tr[3] = file.IsEdi;
                tr[4] = file.Pol;
                tr[5] = file.Pod;
                tr[6] = file.FileType;
                tr[7] = file.Hblcount;
                tr[8] = file.EtaAtPod;
                tr[9] = file.VesselName;
                tr[10] = file.ShippingLine;

                foreach (var item in fileActivity/*.OrderBy(x => x.Sequence).ThenBy(x => x.Name)*/)
                {
                    foreach (var dr in fileEntryData.Where(x => x.Activity == item.Name && x.FileId == file.FileNo))
                    {
                        // Add activity data to the DataRow
                        tr[item.Name + "_" + "Status"] = dr.Status;
                        tr[item.Name + "_" + "Date"] = dr.Date;
                        tr[item.Name + "_" + "UserName"] = dr.UserName;
                        tr[item.Name + "_" + "Comment"] = dr.Comment;
                    }
                }

                // Add the DataRow to the DataTable
                dt.Rows.Add(tr);
            }

            using (XLWorkbook wb = new XLWorkbook())
            {
                dt.TableName = "Pre-Alert File Log";
                var wsFileData = wb.Worksheets.Add(dt);
                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    string excelname = $"FileActivityStatusReport-{DateTime.Now.ToString("ddmmyyyy hh:mm:ss")}.xlsx";
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                }
            }
        }

        [HttpPost]
        public IActionResult PreAlertHBLDataDownload(string fileno, string type, string etadate, string container, string status, string thread, string user)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            int totalRecord = 0;
            int filterRecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var HBLActivity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.ThreadMaster.IsActive == true && x.IsActive == true).OrderBy(x => x.BasedOn).ThenBy(x => x.Name).ToList();

            IQueryable<HblEntry> data = _ctx.Set<HblEntry>().AsQueryable();

            totalRecord = data.Count();

            if (!string.IsNullOrEmpty(fileno))
            {
                data = data.Where(x => x.FileGuid.FileNo == fileno.Trim());

            }
            if (!string.IsNullOrEmpty(type) && type != "all" && type != "--select--")
            {
                data = data.Where(x => x.FileGuid.FileType == type.Trim());

            }
            if (!string.IsNullOrEmpty(etadate))
            {
                data = data.Where(x => x.FileGuid.EtaAtPod == Convert.ToDateTime(etadate));

            }

            if (!string.IsNullOrEmpty(container))
            {
                data = data.Where(x => x.FileGuid.ContainerNo == container.Trim());

            }

            if (!string.IsNullOrEmpty(user) && user != "none" && user != "--select--")
            {
                data = data.Where(x => x.CreatedBy == user.Trim());

            }

            if (!string.IsNullOrEmpty(status) && status != "none" && status != "--select--")
            {
                data = data.Where(x => x.FileGuid.Status == status.Trim());

            }

            if (searchValue == "WIP" || searchValue == "Completed" || searchValue == "Pending" || searchValue == "Query" ||
                        searchValue == "Received" || searchValue == "UnAllocated" || searchValue == "eta10" || searchValue == "eta12")
            {
                if (searchValue == "eta10")
                {
                    data = data.Where(x => x.FileGuid.EtaAtPod != null && Convert.ToDateTime(x.FileGuid.EtaAtPod).AddDays(-10) <= DateTime.Now && (x.FileGuid.Status != "Completed"));

                }
                else if (searchValue == "eta12")
                {
                    data = data.Where(x => x.FileGuid.EtaAtPod != null && Convert.ToDateTime(x.FileGuid.EtaAtPod).AddDays(-10) > DateTime.Now && Convert.ToDateTime(x.FileGuid.EtaAtPod).AddDays(-12) <= DateTime.Now && x.FileGuid.Status != "Completed");
                }

                else
                {
                    data = data.Where(x => x.FileGuid.Status == searchValue);
                }
            }
            var fileEntryData = new List<FileEntryData>();
            var HBLEntryViewModels = data.Include(x => x.HblActivity).ThenInclude(x => x.ActivityMaster.ThreadMaster).Select(x => new
            {
                FileNo = x.FileGuid.FileNo,
                ContainerNo = x.FileGuid.ContainerNo,
                Hblno = x.Hblno,
                IsDap = x.IsDap == true ? "Yes" : "No",
                CreatedBy = x.CreatedBy,
                CreatedDate = x.CreatedDate,
            }).ToList();


            //var fileActivityList = _ctx.HblEntry.Include(x => x.User).Include(x => x.HblActivity).ThenInclude(x => x.ActivityMaster).Include(x => x.FileGuid).ToList();
            //foreach (var hbl in HBLActivity)
            //{
            //    foreach (var item in fileActivityList)
            //    {
            //        fileEntryData.Add(new FileEntryData
            //        {
            //            FileId = item.FileGuid.FileNo,
            //            HBLId = item.Hblno,
            //            Activity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.Id == hbl.Id && x.BasedOn == "HBL" && x.ThreadMaster.IsActive == true && x.IsActive == true).Select(x => x.Name).FirstOrDefault(),
            //            Date = item.HblActivity.Where(x => x.ActivityId == hbl.Id && x.HblEntry.Hblno == item.Hblno).Select(x => x.EndTime).FirstOrDefault(),
            //            Status = item.HblActivity.Where(x => x.ActivityId == hbl.Id && x.HblEntry.Hblno == item.Hblno).Select(x => x.CurrentStatus).FirstOrDefault(),
            //            UserName = item.HblActivity.Where(x => x.ActivityId == hbl.Id && x.HblEntry.Hblno == item.Hblno).Select(x => x.HblEntry.User.UserName).FirstOrDefault(),
            //            Comment = item.HblActivity.Where(x => x.ActivityId == hbl.Id && x.HblEntry.Hblno == item.Hblno).Select(x => x.Comment).FirstOrDefault()
            //        });
            //    }

            //}

            //DataTable dt = new DataTable();
            //dt.Columns.Add("Received Date");
            //dt.Columns.Add("FileNo");
            //dt.Columns.Add("ContainerNo");
            //dt.Columns.Add("Hblno");
            //dt.Columns.Add("IsDap");
            //dt.Columns.Add("CreatedBy");

            //foreach (var item in _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.BasedOn == "HBL" && x.ThreadMaster.IsActive == true && x.IsActive == true).OrderBy(x => x.ThreadMaster.Sequance))
            //{
            //    dt.Columns.Add(item.Name + "_" + "Status");
            //    dt.Columns.Add(item.Name + "_" + "Date");
            //    dt.Columns.Add(item.Name + "_" + "UserName");
            //    dt.Columns.Add(item.Name + "_" + "Comment");
            //}

            ////foreach (var hbl in HBLEntryViewModels)
            ////{
            ////    DataRow tr = dt.NewRow();
            ////    tr[0] = hbl.FileNo;
            ////    tr[1] = hbl.ContainerNo;
            ////    tr[2] = hbl.Hblno;
            ////    tr[3] = hbl.IsDap;
            ////    tr[4] = hbl.CreatedBy;
            ////    tr[5] = hbl.CreatedDate;
            ////    foreach (var item in HBLActivity)
            ////    {
            ////        foreach (var dr in fileEntryData.Where(x => x.Activity == item.Name && x.FileId == hbl.FileNo))
            ////        {
            ////            tr[item.Name + "_" + "Status"] = dr.Status;
            ////            tr[item.Name + "_" + "Date"] = dr.Date;
            ////            tr[item.Name + "_" + "UserName"] = dr.UserName;
            ////            tr[item.Name + "_" + "Comment"] = dr.Comment;
            ////        }
            ////            dt.Rows.Add(tr);
            ////    }
            ////}

            //foreach (var hbl in HBLEntryViewModels)
            //{
            //    DataRow tr = dt.NewRow();
            //    tr[0] = hbl.CreatedDate;
            //    tr[1] = hbl.FileNo;
            //    tr[2] = hbl.ContainerNo;
            //    tr[3] = hbl.Hblno;
            //    tr[4] = hbl.IsDap;
            //    tr[5] = hbl.CreatedBy;

            //    foreach (var item in HBLActivity)
            //    {
            //        var dr = fileEntryData.FirstOrDefault(x => x.Activity == item.Name && x.FileId == hbl.FileNo && x.HBLId == hbl.Hblno);

            //        if (dr != null)
            //        {
            //            tr[item.Name + "_" + "Status"] = dr.Status;
            //            tr[item.Name + "_" + "Date"] = dr.Date;
            //            tr[item.Name + "_" + "UserName"] = dr.UserName;
            //            tr[item.Name + "_" + "Comment"] = dr.Comment;
            //        }
            //    }

            //    dt.Rows.Add(tr);
            //}

            //using (XLWorkbook wb = new XLWorkbook())
            //{
            //    dt.TableName = "Pre-Alert HBL Log";

            //    var wsFileData = wb.Worksheets.Add(dt);

            //    using (MemoryStream stream = new MemoryStream())
            //    {
            //        wb.SaveAs(stream);
            //        string excelname = $"HBLActivityStatusReport-{DateTime.Now.ToString("ddmmyyyy hh:mm:ss")}.xlsx";
            //        return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
            //    }
            //}

            var indiaTimeZone = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");

            // Perform timezone conversion after fetching data
            var HBLEntryViewModelsWithTimeZone = HBLEntryViewModels.Select(x => new
            {
                x.FileNo,
                x.ContainerNo,
                x.Hblno,
                //x.HBLType,
                x.IsDap,
                x.CreatedBy,
                CreatedDate = x.CreatedDate.HasValue
                    ? TimeZoneInfo.ConvertTimeFromUtc(x.CreatedDate.Value, indiaTimeZone)
                    : (DateTime?)null,
            }).ToList();
            var fileActivityList = _ctx.HblEntry.Include(x => x.User).Include(x => x.HblActivity).ThenInclude(x => x.ActivityMaster).ThenInclude(x => x.ThreadMaster).Include(x => x.FileGuid).ToList();
            foreach (var hbl in HBLActivity)
            {
                foreach (var item in fileActivityList)
                {
                    fileEntryData.Add(new FileEntryData
                    {
                        FileId = item.FileGuid.FileNo,
                        HBLId = item.Hblno,
                        Activity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.Id == hbl.Id && x.BasedOn == "HBL" && x.IsActive == true && x.ThreadMaster.IsActive == true).Select(x => x.Name).FirstOrDefault(),
                        Date = item.HblActivity.Where(x => x.ActivityId == hbl.Id && x.HblEntry.Hblno == item.Hblno && x.ActivityMaster.IsActive == true && x.User.IsActive == true && x.ActivityMaster.ThreadMaster.IsActive == true).Select(x => x.EndTime != null ? TimeZoneInfo.ConvertTimeFromUtc(x.EndTime.Value, TimeZoneInfo.FindSystemTimeZoneById("India Standard Time")) : (DateTime?)null).FirstOrDefault(),
                        Status = item.HblActivity.Where(x => x.ActivityId == hbl.Id && x.HblEntry.Hblno == item.Hblno && x.ActivityMaster.IsActive == true && x.User.IsActive == true && x.ActivityMaster.ThreadMaster.IsActive == true).Select(x => x.CurrentStatus).FirstOrDefault(),
                        UserName = item.HblActivity.Where(x => x.ActivityId == hbl.Id && x.HblEntry.Hblno == item.Hblno && x.ActivityMaster.IsActive == true && x.User.IsActive == true && x.ActivityMaster.ThreadMaster.IsActive == true).Select(x => x.User == null ? null : x.User.UserName).FirstOrDefault(),
                        Comment = item.HblActivity.Where(x => x.ActivityId == hbl.Id && x.HblEntry.Hblno == item.Hblno && x.ActivityMaster.IsActive == true && x.User.IsActive == true && x.ActivityMaster.ThreadMaster.IsActive == true).Select(x => x.Comment).FirstOrDefault()
                    });
                }
            }

            DataTable dt = new DataTable();
            dt.Columns.Add("Received Date");
            dt.Columns.Add("FileNo");
            dt.Columns.Add("ContainerNo");
            dt.Columns.Add("HBL No");
            //dt.Columns.Add("HBL Type");
            dt.Columns.Add("IsDap");
            dt.Columns.Add("CreatedBy");

            foreach (var item in _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.BasedOn == "HBL" && x.IsActive == true && x.ThreadMaster.IsActive == true)/*.OrderBy(x => x.ThreadMaster.Sequence)*/)
            {
                dt.Columns.Add(item.Name + "_" + "Status");
                dt.Columns.Add(item.Name + "_" + "Date");
                dt.Columns.Add(item.Name + "_" + "UserName");
                dt.Columns.Add(item.Name + "_" + "Comment");
            }

            foreach (var hbl in HBLEntryViewModels)
            {
                DataRow tr = dt.NewRow();
                tr[0] = hbl.CreatedDate;
                tr[1] = hbl.FileNo;
                tr[2] = hbl.ContainerNo;
                tr[3] = hbl.Hblno;
                //tr[4] = hbl.HBLType;
                tr[5] = hbl.IsDap;
                tr[6] = hbl.CreatedBy;

                foreach (var item in HBLActivity)
                {
                    var dr = fileEntryData.FirstOrDefault(x => x.Activity == item.Name && x.FileId == hbl.FileNo && x.HBLId == hbl.Hblno);

                    if (dr != null)
                    {
                        tr[item.Name + "_" + "Status"] = dr.Status;
                        tr[item.Name + "_" + "Date"] = dr.Date;
                        tr[item.Name + "_" + "UserName"] = dr.UserName;
                        tr[item.Name + "_" + "Comment"] = dr.Comment;
                    }
                }

                dt.Rows.Add(tr);
            }

            using (XLWorkbook wb = new XLWorkbook())
            {
                dt.TableName = "Pre-Alert HBL Log";
                var wsFileData = wb.Worksheets.Add(dt);
                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    string excelname = $"HBLActivityStatusReport-{DateTime.Now.ToString("ddmmyyyy hh:mm:ss")}.xlsx";
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                }
            }
        }

        [HttpGet]
        public IActionResult UserActivityStatus([FromQuery(Name = "ThreadName")] string threadName, DateTime? StartDate, DateTime? EndDate)
        {
            return View();
        }

        [HttpPost]
        public IActionResult UserActivityStatusList(DateTime? StartDate, DateTime? EndDate)
        {
            if (Convert.ToDateTime(StartDate).Date == DateTime.Now.Date && Convert.ToDateTime(EndDate).Date == DateTime.Now.Date)
            {
                StartDate = null;
                EndDate = null;
            }
            UserActivityStatusViewModel userActivityStatus = new UserActivityStatusViewModel();
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var searchClick = Request.Form["columns[0][search][value]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            var fileActivity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.ThreadMaster.IsActive == true && x.IsActive == true).OrderBy(x => x.BasedOn).ThenBy(x => x.Name).ToList();
            var hblActivity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.ThreadMaster.IsActive == true && x.IsActive == true).OrderBy(x => x.Name).ToList();
            var userList = _ctx.User.Where(x => x.IsActive == true && x.IsDelete == false).ToList();

            if (StartDate != null && EndDate != null)
            {
                foreach (var user in userList)
                {
                    var getFileActivityStatus = new List<FileActivityStatusList>();
                    var getHBLActivityStatus = new List<HBLActivityStatusList>();
                    var fileActivityList = _ctx.FileActivity.Where(x => x.EnterDate.Value.Date >= StartDate.Value.Date && x.EnterDate.Value.Date <= EndDate.Value.Date).ToList();

                    foreach (var item in fileActivity)
                    {
                        getFileActivityStatus.Add(new FileActivityStatusList
                        {
                            Activity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.Id == item.Id && x.ThreadMaster.IsActive == true && x.IsActive == true).Select(x => x.Name).FirstOrDefault(),
                            ActivityType = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.Id == item.Id && x.ThreadMaster.IsActive == true && x.IsActive == true).Select(x => x.BasedOn).FirstOrDefault(),
                            WIP = fileActivityList.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Completed = fileActivityList.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Pending = fileActivityList.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Query = fileActivityList.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            CompletedWithQuery = fileActivityList.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Total = fileActivityList.Where(x => x.ActivityId == item.Id && x.UserId == user.Id).Count(),

                        });
                    }

                    userActivityStatus.GetUserStatusList.Add(new UserStatusList
                    {
                        UserId = user.UserName,
                        WIP = fileActivityList.Where(x => x.CurrentStatus == "WIP" && x.UserId == user.Id).Count(),
                        Completed = fileActivityList.Where(x => x.CurrentStatus == "Completed" && x.UserId == user.Id).Count(),
                        Pending = fileActivityList.Where(x => x.CurrentStatus == "Pending" && x.UserId == user.Id).Count(),
                        Query = fileActivityList.Where(x => x.CurrentStatus == "Query" && x.UserId == user.Id).Count(),
                        CompletedWithQuery = fileActivityList.Where(x => x.CurrentStatus == "Completed With Query" && x.UserId == user.Id).Count(),
                        Total = fileActivityList.Where(x => x.UserId == user.Id).Count(),
                        GetFileActivityStatus = getFileActivityStatus,
                        GetHBLActivityStatus = getHBLActivityStatus
                    });
                }
                var totalrecords = userActivityStatus.GetUserStatusList.Count();
                var SortedData = userActivityStatus.GetUserStatusList.AsQueryable();

                if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
                {
                    if (sortColumn == "userName")
                    {
                        sortColumn = "userId";
                    }
                    SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
                }
                var returnObj = new
                {
                    draw = draw,
                    recordsTotal = totalrecords,
                    recordsFiltered = SortedData.Count(),
                    data = SortedData,
                    skip = skip,
                    pageSize = pageSize,
                };
                return Json(returnObj);

            }
            else
            {

                foreach (var user in userList)
                {
                    var getFileActivityStatus = new List<FileActivityStatusList>();
                    var getHBLActivityStatus = new List<HBLActivityStatusList>();


                    foreach (var item in fileActivity)
                    {
                        getFileActivityStatus.Add(new FileActivityStatusList
                        {
                            Activity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.Id == item.Id && x.ThreadMaster.IsActive == true && x.IsActive == true).Select(x => x.Name).FirstOrDefault(),
                            ActivityType = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.Id == item.Id && x.ThreadMaster.IsActive == true && x.IsActive == true).Select(x => x.BasedOn).FirstOrDefault(),
                            WIP = _ctx.FileActivity.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Completed = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Pending = _ctx.FileActivity.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Query = _ctx.FileActivity.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            CompletedWithQuery = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Total = _ctx.FileActivity.Where(x => x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                        });

                    }
                    userActivityStatus.GetUserStatusList.Add(new UserStatusList
                    {
                        UserId = user.UserName,
                        WIP = _ctx.FileActivity.Where(x => x.CurrentStatus == "WIP" && x.UserId == user.Id).Count(),
                        Completed = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed" && x.UserId == user.Id).Count(),
                        Pending = _ctx.FileActivity.Where(x => x.CurrentStatus == "Pending" && x.UserId == user.Id).Count(),
                        Query = _ctx.FileActivity.Where(x => x.CurrentStatus == "Query" && x.UserId == user.Id).Count(),
                        CompletedWithQuery = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed With Query" && x.UserId == user.Id).Count(),
                        Total = _ctx.FileActivity.Where(x => x.UserId == user.Id).Count(),
                        GetFileActivityStatus = getFileActivityStatus,
                        GetHBLActivityStatus = getHBLActivityStatus
                    });
                }
                var totalrecords = userActivityStatus.GetUserStatusList.Count();
                var SortedData = userActivityStatus.GetUserStatusList.AsQueryable();
                if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
                {
                    if (sortColumn == "userName")
                    {
                        sortColumn = "userId";
                    }
                    SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
                }
                var returnObj = new
                {
                    draw = draw,
                    recordsTotal = totalrecords,
                    recordsFiltered = SortedData.Count(),
                    data = SortedData,
                    skip = skip,
                    pageSize = pageSize,
                };
                return Json(returnObj);
            }

        }

        [HttpPost]
        public IActionResult UserDataDownload(DateTime? StartDate, DateTime? EndDate)
        {
            UserActivityStatusViewModel userActivityStatus = new UserActivityStatusViewModel();
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var fileActivity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.ThreadMaster.IsActive == true && x.IsActive == true).OrderBy(x => x.BasedOn).ThenBy(x => x.Name).ToList();
            var hblActivity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.ThreadMaster.IsActive == true && x.IsActive == true).OrderBy(x => x.Name).ToList();
            var userList = _ctx.User.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            if (Convert.ToDateTime(StartDate).Date == DateTime.Now.Date && Convert.ToDateTime(EndDate).Date == DateTime.Now.Date)
            {
                StartDate = null;
                EndDate = null;
            }
            if (StartDate != null && EndDate != null)
            {
                foreach (var user in userList)
                {
                    var getFileActivityStatus = new List<FileActivityStatusList>();
                    var getHBLActivityStatus = new List<HBLActivityStatusList>();
                    var fileActivityList = _ctx.FileActivity.Where(x => x.EnterDate.Value.Date >= StartDate.Value.Date && x.EnterDate.Value.Date <= EndDate.Value.Date).ToList();

                    foreach (var item in fileActivity)
                    {
                        getFileActivityStatus.Add(new FileActivityStatusList
                        {
                            Activity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.Id == item.Id && x.ThreadMaster.IsActive == true && x.IsActive == true).Select(x => x.Name).FirstOrDefault(),
                            ActivityType = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.Id == item.Id && x.ThreadMaster.IsActive == true && x.IsActive == true).Select(x => x.BasedOn).FirstOrDefault(),
                            WIP = fileActivityList.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Completed = fileActivityList.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Pending = fileActivityList.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Query = fileActivityList.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            CompletedWithQuery = fileActivityList.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Total = fileActivityList.Where(x => x.ActivityId == item.Id && x.UserId == user.Id).Count(),

                        });
                    }

                    userActivityStatus.GetUserStatusList.Add(new UserStatusList
                    {
                        UserId = user.UserName,
                        WIP = fileActivityList.Where(x => x.CurrentStatus == "WIP" && x.UserId == user.Id).Count(),
                        Completed = fileActivityList.Where(x => x.CurrentStatus == "Completed" && x.UserId == user.Id).Count(),
                        Pending = fileActivityList.Where(x => x.CurrentStatus == "Pending" && x.UserId == user.Id).Count(),
                        Query = fileActivityList.Where(x => x.CurrentStatus == "Query" && x.UserId == user.Id).Count(),
                        CompletedWithQuery = fileActivityList.Where(x => x.CurrentStatus == "Completed With Query" && x.UserId == user.Id).Count(),
                        Total = fileActivityList.Where(x => x.UserId == user.Id).Count(),
                        GetFileActivityStatus = getFileActivityStatus,
                        GetHBLActivityStatus = getHBLActivityStatus
                    });
                }
            }
            else
            {

                foreach (var user in userList)
                {
                    var getFileActivityStatus = new List<FileActivityStatusList>();
                    var getHBLActivityStatus = new List<HBLActivityStatusList>();


                    foreach (var item in fileActivity)
                    {
                        getFileActivityStatus.Add(new FileActivityStatusList
                        {
                            Activity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.Id == item.Id && x.ThreadMaster.IsActive == true && x.IsActive == true).Select(x => x.Name).FirstOrDefault(),
                            ActivityType = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.Id == item.Id && x.ThreadMaster.IsActive == true && x.IsActive == true).Select(x => x.BasedOn).FirstOrDefault(),
                            WIP = _ctx.FileActivity.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Completed = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Pending = _ctx.FileActivity.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Query = _ctx.FileActivity.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            CompletedWithQuery = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Total = _ctx.FileActivity.Where(x => x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                        });

                    }
                    userActivityStatus.GetUserStatusList.Add(new UserStatusList
                    {
                        UserId = user.UserName,
                        WIP = _ctx.FileActivity.Where(x => x.CurrentStatus == "WIP" && x.UserId == user.Id).Count(),
                        Completed = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed" && x.UserId == user.Id).Count(),
                        Pending = _ctx.FileActivity.Where(x => x.CurrentStatus == "Pending" && x.UserId == user.Id).Count(),
                        Query = _ctx.FileActivity.Where(x => x.CurrentStatus == "Query" && x.UserId == user.Id).Count(),
                        CompletedWithQuery = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed With Query" && x.UserId == user.Id).Count(),
                        Total = _ctx.FileActivity.Where(x => x.UserId == user.Id).Count(),
                        GetFileActivityStatus = getFileActivityStatus,
                        GetHBLActivityStatus = getHBLActivityStatus
                    });
                }
            }

            var fileStatus = userActivityStatus.GetUserStatusList.Select(x => new UserStatusList
            {
                UserId = x.UserId,
                Total = x.Total,
                WIP = x.WIP,
                Query = x.Query,
                Pending = x.Pending,
                Completed = x.Completed,
                CompletedWithQuery = x.CompletedWithQuery,
                GetFileActivityStatus = x.GetFileActivityStatus

            }).ToList();

            DataTable FileActivityStatus = ToDataTable(fileStatus);

            DataTable dt = new DataTable();
            dt.Columns.Add("Username");
            dt.Columns.Add("Activity");
            dt.Columns.Add("ActivityType");
            dt.Columns.Add("Total");
            dt.Columns.Add("Completed");
            dt.Columns.Add("CompletedWithQuery");
            dt.Columns.Add("Pending");
            dt.Columns.Add("Query");
            dt.Columns.Add("WIP");



            foreach (var dr in fileStatus)
            {
                foreach (var file in dr.GetFileActivityStatus)
                {
                    DataRow tr = dt.NewRow();
                    tr[0] = dr.UserId;
                    tr[0] = dr.UserId;
                    tr[1] = file.Activity;
                    tr[2] = file.ActivityType;
                    tr[3] = file.Total;
                    tr[4] = file.Completed;
                    tr[5] = file.CompletedWithQuery;
                    tr[6] = file.Pending;
                    tr[7] = file.Query;
                    tr[8] = file.WIP;
                    dt.Rows.Add(tr);
                }
            }

            using (XLWorkbook wb = new XLWorkbook())
            {
                dt.TableName = "User Activity Status";
                var wsData = wb.Worksheets.Add(dt);
                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    string excelname = $"UserActivityStatus-{DateTime.UtcNow.ToString("ddmmyyyy hh:mm:ss")}.xlsx";
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                }
            }
        }

        [HttpGet]
        public IActionResult GetActivityFileData()
        {
            ViewData["ActivityMaster"] = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.IsActive == true && x.ThreadMaster.IsActive == true).ToList();

            return View();
        }

        [HttpPost]
        public IActionResult GetActivityFileData(string activity, string activityType, string status)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            int totalRecord = 0;
            int filterRecord = 0;
            int hblrecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var fileEntryData = new List<FileActivityDataList>();
            if (activityType == "HBL")
            {
                fileEntryData = _ctx.HblActivity.Include(x => x.ActivityMaster).ThenInclude(x => x.ThreadMaster).Include(x => x.HblEntry).ThenInclude(x => x.FileGuid).ThenInclude(x => x.FileActivity).Select(x => new FileActivityDataList
                {
                    ActivityId = x.ActivityMaster.Name,
                    BasedOn = x.ActivityMaster.BasedOn,
                    Comment = x.Comment,
                    CurrentStatus = x.CurrentStatus,
                    EndTime = x.EndTime,
                    EnterDate = x.EnterDate,
                    FileNo = x.HblEntry.FileGuid.FileNo,
                    ContainerNo = x.HblEntry.FileGuid.ContainerNo,
                    hblNo = x.HblEntry.Hblno,
                    Id = x.HblEntry.FileGuid.Id,
                    UserId = x.User.UserName,
                    hblCount = x.HblEntry.FileGuid.Hblcount,
                    StartTime = x.StartTime

                }).Skip(skip * pageSize).Take(pageSize == -1 ? 100 : pageSize).ToList();

            }
            else
            {
                fileEntryData = _ctx.FileActivity.Include(x => x.ActivityMaster).ThenInclude(x => x.ThreadMaster).Include(x => x.FileEntry).ThenInclude(x => x.User).Select(x => new FileActivityDataList
                {
                    ActivityId = x.ActivityMaster.Name,
                    BasedOn = x.ActivityMaster.BasedOn,
                    Comment = x.Comment,
                    CurrentStatus = x.CurrentStatus,
                    EndTime = x.EndTime,
                    EnterDate = x.EnterDate,
                    FileNo = x.FileEntry.FileNo,
                    ContainerNo = x.FileEntry.ContainerNo,
                    Id = x.FileId,
                    UserId = x.FileEntry.User.UserName,
                    hblCount = x.FileEntry.Hblcount,
                    StartTime = x.StartTime

                }).Skip(skip * pageSize).Take(pageSize == -1 ? 100 : pageSize).ToList();
            }
            totalRecord = fileEntryData.Count();
            IQueryable<FileActivityDataList> SortedData = fileEntryData.Distinct().AsQueryable();

            if (!string.IsNullOrEmpty(activityType) && activityType != "all" && activityType != "--select--")
            {
                SortedData = SortedData.Where(x => x.BasedOn == activityType.Trim());

            }
            if (!string.IsNullOrEmpty(activity) && activity != "none" && activity != "--Select--")
            {
                SortedData = SortedData.Where(x => x.ActivityId == activity.Trim());

            }
            if (!string.IsNullOrEmpty(status) && status != "none" && status != "--select--")
            {
                SortedData = SortedData.Where(x => x.CurrentStatus == status.Trim());

            }
            else
            {
                SortedData = SortedData.Where(x => x.CurrentStatus != "Completed".Trim());
            }
            if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
            {
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            else
            {
                sortColumn = "fileNo";
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            var returnObj = new
            {
                draw = draw,
                recordsTotal = totalRecord,
                recordsFiltered = SortedData.Count(),
                data = SortedData,
            };

            return Json(returnObj);
        }


        public IActionResult GetActivityHBLData(string fileNo, string activityId, string status)
        {
            var fileId = _ctx.FileEntry.Where(x => x.FileNo == fileNo).Select(x => x.Id).FirstOrDefault();

            var hblEntry = (from FE in _ctx.FileEntry
                            join HE in _ctx.HblEntry on FE.Id equals HE.FileGuidId
                            join hbl in _ctx.HblActivity on HE.Id equals hbl.HblId
                            select new HBLActivityDataList
                            {
                                Id = HE.Id,
                                Hblno = HE.Hblno,
                                FileGuidId = HE.FileGuidId,
                                IsDap = HE.IsDap == true ? "Yes" : "No",
                                CreatedDate = HE.CreatedDate,
                                BasedOn = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(y => y.Id == hbl.ActivityId && y.IsActive == true && y.ThreadMaster.IsActive == true).Select(x => x.BasedOn).FirstOrDefault(),
                                CreatedBy = _ctx.User.Where(y => y.Id == HE.CreatedBy).Select(y => y.UserName).FirstOrDefault(),
                                Comment = hbl.Comment,
                                CurrentStatus = hbl.CurrentStatus,
                                StartTime = hbl.StartTime,
                                EndTime = hbl.EndTime,
                                EnterBy = hbl.EnterBy,
                                ActivityId = _ctx.HblActivity.Where(y => y.ActivityId == hbl.ActivityId).Select(y => y.ActivityMaster.Name).FirstOrDefault(),
                            }).ToList();

            if (activityId == "File Processing Status")
            {
                hblEntry = hblEntry.Where(x => x.FileGuidId == fileId && x.ActivityId == "HBL Status").ToList();
            }
            else
            {
                hblEntry = hblEntry.Where(x => x.FileGuidId == fileId && x.ActivityId == activityId).ToList();
            }
            if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--")
            {
                hblEntry = hblEntry.Where(x => x.CurrentStatus == status.Trim()).ToList();

            }
            else
            {
                hblEntry = hblEntry.Where(x => x.CurrentStatus != "Completed").ToList();
            }

            return Json(hblEntry);
        }

        [HttpGet]
        public IActionResult GetHblActivityData(string hblId)
        {
            ViewData["hblActivityList"] = _ctx.HblActivity.Where(x => x.HblId == hblId).Select(x => new HBLActivityDataList
            {
                Id = x.Id,
                Hblno = x.HblEntry.Hblno == null ? "" : x.HblEntry.Hblno,
                ActivityId = x.ActivityMaster.Name,
                EndTime = x.EndTime,
                CurrentStatus = x.CurrentStatus,
                Comment = x.Comment == null ? "" : x.Comment,
                EnterBy = x.User.CitrixId == null ? "" : x.User.CitrixId
            }).ToList();
            return PartialView();
        }

        [HttpPost]
        public IActionResult GetHblActivityData(string hblno, string hbl)
        {
            var hblact = _ctx.HblActivity.Include(x => x.HblEntry).Include(x => x.ActivityMaster).Include(x => x.User).Where(x => x.HblEntry.Hblno == hblno).ToList();
            List<HBLActivityDataList> hblActivityLog = new List<HBLActivityDataList>();
            foreach (var item in hblact)
            {
                hblActivityLog.Add(new HBLActivityDataList
                {
                    Hblno = hblno == null ? "" : hblno,
                    ActivityId = item.ActivityMaster.Name == null ? "" : item.ActivityMaster.Name,
                    EndTime = item.EndTime,
                    CurrentStatus = item.CurrentStatus,
                    EnterBy = item.User.CitrixId,

                });
            }
            return Json(hblActivityLog);
        }
        public IActionResult GetActivityType(string fileType)
        {

            ViewData["ActivityMaster"] = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.BasedOn == fileType && x.IsActive == true && x.ThreadMaster.IsActive == true).ToList();
            var activity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.BasedOn == fileType && x.IsActive == true && x.ThreadMaster.IsActive == true).ToList();

            return Json(activity);
        }

        [HttpPost]
        public IActionResult HBLSubmit(HBLActivityDataList model, string fileType, string activityId, string status, DateTime startDate)
        {
            var activity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.BasedOn == fileType && x.IsActive == true && x.ThreadMaster.IsActive == true).ToList();
            var hblId = _ctx.HblEntry.Where(x => x.Hblno == model.Hblno).Select(x => x.Id).FirstOrDefault();
            var hblActivityId = _ctx.HblActivity.Where(x => x.HblId == hblId).Select(x => x.Id).FirstOrDefault();
            HblActivity hblActivity = _ctx.HblActivity.Where(x => x.Id == model.Id.Trim()).FirstOrDefault();
            var hblActivityList = _ctx.HblActivity.Where(x => x.HblEntry.FileGuidId == model.FileGuidId).ToList();
            if (fileType == "HBL")
            {
                var hbllog = _ctx.HBLHistoryLog.Add(new HBLHistoryLog
                {

                    HBLActivityId = hblActivityId,
                    CurrentStatus = model.CurrentStatus,
                    Comment = model.Comment,
                    EnterBy = model.EnterBy,
                    StartTime = startDate,
                    EndTime = model.EndTime,
                    EnterDate = model.CreatedDate,
                    EnterStartDate = DateTime.UtcNow.AddMinutes(-2),
                    EnterEndDate = DateTime.UtcNow,

                });
                _ctx.SaveChanges();

                hblActivity.CurrentStatus = model.CurrentStatus;
                hblActivity.Comment = model.Comment;
                hblActivity.StartTime = startDate;
                hblActivity.EndTime = DateTime.Now.ToUniversalTime();
                _ctx.HblActivity.Update(hblActivity);
                _ctx.SaveChanges();

                if (model.FileGuidId != null)
                {
                    if (hblActivityList != null)
                    {
                        foreach (var hbl in hblActivityList)
                        {
                            var hblStatus = hblActivityList.Where(x => x.CurrentStatus != "Completed").Count();
                            if (hblStatus == 0)
                            {
                                var fileActivity = _ctx.FileActivity.Where(x => x.FileId == model.FileGuidId).FirstOrDefault();
                                fileActivity.CurrentStatus = model.CurrentStatus;
                                fileActivity.Comment = "All Hbl in this file are completed.";
                                fileActivity.StartTime = startDate;
                                fileActivity.EndTime = DateTime.Now.ToUniversalTime();
                                _ctx.FileActivity.Update(fileActivity);
                                _ctx.SaveChanges();
                            }
                        }
                    }

                }
                return Json("Success");
            }
            else
            {
                return Json("Failed");

            }
        }

        [HttpPost]
        public JsonResult UpdateData(string? columnName, string? editedValue, string? containerId, string? fileId, string? fileActivityLogId, string? startDateTime)
        {

            //var file = _context.FileMaster.Where(x => x.Id == fileId).FirstOrDefault();
            //var container = _context.ContainerMaster.Where(x => x.Id == containerId).FirstOrDefault();
            var file = _ctx.FileEntry.Where(x => x.Id == fileId).FirstOrDefault();
            DateTime date = Convert.ToDateTime(startDateTime).ToUniversalTime();
            var fileList = _ctx.FileEntry.ToList();

            //_context.FileAcitivityLogHistory.Add(new FileAcitivityLogHistory
            //{
            //    FileLogId = fileActivityLogId,
            //    ActivityId = fileLog.ActivityId,
            //    StatusId = fileLog.StatusId,
            //    UserId = fileLog.UserId,
            //    StartDate = fileLog.StartDate,
            //    EndDate = fileLog.EndDate,
            //    Comment = fileLog.Comment,
            //    Roe = fileLog.Roe
            //});
            //_context.SaveChanges();
            //if (columnName == "sailingDate")
            //{
            //    DateTime dateTime = Convert.ToDateTime(editedValue).ToUniversalTime();
            //    file.SailingDate = dateTime;
            //    //fileLog.StartDate = date;
            //    //fileLog.EndDate = DateTime.UtcNow;
            //    _ctx.FileEntry.Update(file);
            //    //_ctx.FileActivityLog.Update(fileLog);
            //}
            if (columnName == "etaAtPod")
            {
                DateTime dateTime = Convert.ToDateTime(editedValue).ToUniversalTime();
                file.EtaAtPod = dateTime;
                //fileLog.StartDate = date;
                //fileLog.EndDate = DateTime.UtcNow;
                _ctx.FileEntry.Update(file);
                //_ctx.FileActivityLog.Update(fileLog);
            }
            else if (columnName == "containerNo")
            {
                fileList = fileList.Where(x => x.FileNo == file.FileNo && x.ContainerNo == editedValue).ToList();
                if (fileList.Count() != 0)
                {
                    return Json("Duplicate Container in Same File.");
                }
                else
                {
                    //DateTime dateTime = Convert.ToDateTime(editedValue).ToUniversalTime();
                    file.ContainerNo = editedValue;
                    //fileLog.StartDate = date;
                    //fileLog.EndDate = DateTime.UtcNow;
                    _ctx.FileEntry.Update(file);
                    //_ctx.FileActivityLog.Update(fileLog);
                }

            }
            //else if (columnName == "etaAtFD")
            //{
            //    DateTime dateTime = Convert.ToDateTime(editedValue).ToUniversalTime();
            //    file.EtaAtFD = dateTime;
            //    //fileLog.StartDate = date;
            //    //fileLog.EndDate = DateTime.UtcNow;
            //    _ctx.FileEntry.Update(file);
            //    //_ctx.FileActivityLog.Update(fileLog);
            //}
            else if (columnName == "fileNo")
            {


                fileList = fileList.Where(x => x.FileNo == editedValue).ToList();
                if (fileList.Count() != 0)
                {
                    return Json("Duplicate File.");
                }
                else
                {
                    //DateTime dateTime = Convert.ToDateTime(editedValue).ToUniversalTime();
                    file.FileNo = editedValue;
                    //fileLog.StartDate = date;
                    //fileLog.EndDate = DateTime.UtcNow;
                    _ctx.FileEntry.Update(file);
                    //_ctx.FileActivityLog.Update(fileLog);
                }
            }
            _ctx.SaveChanges();
            return Json("Success");

        }

        public JsonResult ActivateThread(string Id)
        {
            string message = "";
            if (Id != null)
            {
                ThreadMaster master = _ctx.ThreadMaster.Where(x => x.Id.ToLower() == Id.ToLower()).FirstOrDefault();
                if (master != null)
                {
                    //master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    _ctx.ThreadMaster.Update(master);
                    _ctx.SaveChanges();
                    message = master.IsActive == true ? master.Name + " Thread Active!" : master.Name + " Thread InActive!";

                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }

        public JsonResult ActivateActivity(string Id)
        {
            string message = "";
            if (Id != null)
            {
                ActivityMaster master = _ctx.ActivityMaster.Where(x => x.Id.ToLower() == Id.ToLower()).FirstOrDefault();
                if (master != null)
                {
                    //master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    _ctx.ActivityMaster.Update(master);
                    _ctx.SaveChanges();
                    message = master.IsActive == true ? master.Name + " Activity Active!" : master.Name + " Activity InActive!";

                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }
        public JsonResult ActivateUser(string Id)
        {
            string message = "";
            if (Id != null)
            {
                User master = _ctx.Users.Where(x => x.CitrixId.ToLower() == Id.ToLower()).FirstOrDefault();
                if (master != null)
                {
                    //master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    _ctx.Users.Update(master);
                    _ctx.SaveChanges();
                    message = master.IsActive == true ? master.UserName + " Active!" : master.UserName + " InActive!";

                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }

        [Authorize(Roles = "Admin,Supervisor,Manager")]

        public JsonResult DeleteUser(string Id)
        {
            string message = "";
            if (Id != null)
            {
                User master = _ctx.User.Where(x => x.CitrixId.ToLower() == Id.ToLower()).FirstOrDefault();
                if (master != null)
                {
                    //master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    master.IsDelete = master.IsDelete != null ? !master.IsDelete : true;
                    _ctx.User.Update(master);
                    _ctx.SaveChanges();
                    message = master.IsDelete == true ? master.CitrixId + " User Delete!" : master.CitrixId + " User Restore!";

                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }


        public JsonResult UpdateIsLDAP(string Id)
        {
            string message = "";
            if (Id != null)
            {
                User master = _ctx.Users.Where(x => x.CitrixId.ToLower() == Id.ToLower()).FirstOrDefault();
                if (master != null)
                {
                    //master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    master.IsLDAP = master.IsLDAP != null ? !master.IsLDAP : true;
                    _ctx.Users.Update(master);
                    _ctx.SaveChanges();
                    message = master.IsLDAP == true ? master.UserName + " LDAP Active!" : master.UserName + " LDAP InActive!";

                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }

        public JsonResult UpdateIsReset(string Id)
        {
            string message = "";
            User master = _ctx.Users.Where(x => x.CitrixId.ToLower() == Id.ToLower()).FirstOrDefault();
            if (Id != null)
            {
                if (master != null)
                {
                    //master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    master.IsReset = master.IsReset != null ? !master.IsReset : true;
                    _ctx.Users.Update(master);
                    _ctx.SaveChanges();
                    message = master.IsReset == true ? master.UserName + " Password Unset!" : master.UserName + " Password Reset!";

                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(new { Message = message, UserName = master.UserName, CitrixId = master.CitrixId, UserId = master.Id });
        }

        [Authorize(Roles = "Admin,Supervisor,Manager")]
        [HttpGet]
        public IActionResult EditFile(string id)
        {
            var query = _ctx.Set<AdminDashboardViewModel>().FromSqlRaw("SELECT * FROM vw_AdminDashboardViewModels").AsQueryable();
            var data = query.Where(x => x.Id == id).AsQueryable();
            ViewData["EditFile"] = data.FirstOrDefault();
            ViewData["Country"] = _ctx.LocationMaster.OrderBy(x => x.Name).ToList();
            ViewData["Pol"] = _ctx.POLMaster.OrderBy(x => x.Name).ToList();
            return View();
        }

        [HttpPost]
        public IActionResult EditFile(FileEntryViewModel model)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var present = _ctx.FileEntry.Where(x => x.Id == model.Id).FirstOrDefault();
            if (present != null)
            {
                present.FileNo = model.FileNo != null ? model.FileNo : null;
                present.ContainerNo = model.ContainerNo != null ? model.ContainerNo : null;
                present.IsEdi = model.IsEdi != "Yes" ? false : true;
                present.Pol = model.Pol != null ? model.Pol : null;
                present.Pod = model.Pod != null ? model.Pod : null;
                present.Hblcount = model.Hblcount != null ? model.Hblcount : null;
                //present.ActualHblcount = model.ActualHblcount != null ? model.ActualHblcount : null;
                present.EtaAtPod = model.EtaAtPod != null ? Convert.ToDateTime(model.EtaAtPod).ToUniversalTime() : null;
                //present.Status = null;
                present.CreatedDate = model.CreatedDate != null ? Convert.ToDateTime(model.CreatedDate.Value.Date).ToUniversalTime() : DateTime.UtcNow.Date;
                present.CreatedBy = userid;
                present.FileType = model.FileType != null ? model.FileType : null;
                present.ProductType = model.ProductType != null ? model.ProductType : null;
                //present.ShippingLine = model.ShippingLine != null ? model.ShippingLine : null;
                //present.VesselName = model.VesselName != null ? model.VesselName : null;
            }
            _ctx.FileEntry.Update(present);
            _ctx.SaveChanges();
            return Json("Update");
        }

    }
}


