﻿using CAImportWorkflow.Data;
using CAImportWorkflow.LDAP;
using CAImportWorkflow.Models;
using DocumentFormat.OpenXml.Spreadsheet;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.RegularExpressions;

namespace CAImportWorkflow.Controllers
{
    public class AccountController : Controller
    {
        private readonly UserManager<User> userManger;
        private readonly LdapUserManager<User> ldapUserManager;

        private readonly SignInManager<User> defaultsignInManager;
        private readonly RoleManager<Role> roleManager;
        public ApplicationDbContext _ctx;


        public AccountController(UserManager<User> userManger, LdapUserManager<User> ldapUserManager, SignInManager<User> defaultsignInManager, RoleManager<Role> roleManager, ApplicationDbContext ctx)
        {
            this.userManger = userManger;
            this.ldapUserManager = ldapUserManager;
            //this.signInManager = signInManager;
            this.defaultsignInManager = defaultsignInManager;
            this.roleManager = roleManager;
            _ctx = ctx;
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpGet]

        public IActionResult Index()
        {
            var roleList = _ctx.Role.Where(x => x.IsActive == true).ToList();
            var result = _ctx.Users.Select(x => new RegisterViewModel
            {
                Id = x.Id,
                UserName = x.UserName,
                CitrixId = x.CitrixId,
                Wnsid = x.Wnsid,
                RoleList = roleList,
                assingedRoleList = _ctx.UserRoles.Where(y => y.UserId == x.Id).Select(x => x.RoleId).ToList(),
                threadMasters = _ctx.ThreadMaster.Where(z => z.IsActive == true).Select(z => new ThreadMaster
                { Id = z.Id, Name = z.Name }).ToList(),
                assignedThreads = _ctx.ThreadRelation.Include(x => x.ThreadMaster).Where(z => z.UserId == x.Id && z.IsActive == true && z.ThreadMaster.IsActive == true).Select(z => z.ThreadId).ToList(),
                locationMasterList = _ctx.LocationMaster.Where(x => x.IsActive == true).Select(z => new LocationMaster
                { Id = z.Id, Name = z.Name }).ToList(),
                assignedLocation = _ctx.UserLocationRelation.Include(x => x.LocationMaster).Where(y => y.UserId == x.Id && y.LocationMaster.IsActive == true).Select(x => x.LocationId).ToList(),
                IsActive = x.IsActive,
                IsDelete = x.IsDelete,
                IsLDAP = x.IsLDAP,
                IsReset = x.IsReset

            }).Where(x => x.IsDelete == false).ToList();
            ViewData["User"] = _ctx.Users.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["Roles"] = _ctx.Role.OrderBy(x => x.Name).ToList();

            return View(result);
        }


        [HttpGet]

        public IActionResult DeletedUserIndex()
        {
            var roleList = _ctx.Role.Where(x => x.IsActive == true).ToList();

            var result = _ctx.Users.Select(x => new RegisterViewModel
            {
                Id = x.Id,
                UserName = x.UserName,
                CitrixId = x.CitrixId,
                Wnsid = x.Wnsid,
                IsActive = x.IsActive,
                IsDelete = x.IsDelete,
                IsLDAP = x.IsLDAP,
                IsReset = x.IsReset

            }).Where(x => (x.IsActive == null && x.IsDelete == null) || ((x.IsActive == true || x.IsActive == false || x.IsActive == null) && (x.IsDelete == true || x.IsDelete == null)) || (x.IsDelete == true || x.IsDelete == null || x.IsActive == null)).ToList();
            //}).Where(x => (x.IsDelete == true || x.IsDelete == null || (x.IsActive == null && x.IsDelete == null) || x.IsActive == null || ((x.IsActive == true || x.IsActive == false || x.IsActive == null) && (x.IsDelete == true || x.IsDelete == false || x.IsDelete == null)) ).ToList();

            ViewData["User"] = _ctx.Users.Where(x => x.IsActive == true).OrderBy(x => x.CitrixId).ToList();
            ViewData["Roles"] = roleManager.Roles.OrderBy(x => x.Name).ToList();

            return View(result);
        }
        #region commented
        //[HttpPost]
        //public async Task<IActionResult> Login(LoginViewModel model)
        //{

        //    if (ModelState.IsValid)
        //    {
        //        User users = _ctx.User.Where(x => x.CitrixId.ToLower() == model.CitrixId.ToLower()).FirstOrDefault();

        //        if (users != null)
        //        {
        //            var user = await userManger.FindByNameAsync(model.CitrixId);
        //            var roles = await userManger.GetRolesAsync(user);
        //            if (users.IsLDAP == true)
        //            {
        //                //var result = await defaultsignInManager.PasswordSignInAsync(users, model.Password, false, false);
        //                //var result = await defaultsignInManager.CheckPasswordSignInAsync(users, model.Password, false);
        //                //var result = await signInManager.CheckPasswordSignInAsync(users, model.Password, false);
        //                var result = await signInManager.CheckPasswordSignInAsync(users, model.Password, false);


        //                if (result.Succeeded)
        //                {
        //                    if (roles.Count != 0)
        //                    {
        //                        //if (roles.Count() == 1)
        //                        //{
        //                        if (roles[0].ToString().ToUpper() == "ADMIN")
        //                        {
        //                            return RedirectToAction("AdminDashboard", "Admin");
        //                        }
        //                        else if (roles[0].ToString().ToUpper() == "USER")
        //                        {
        //                            return RedirectToAction("UserThread", "User");
        //                        }
        //                        //}
        //                        //else
        //                        //    return RedirectToAction("SelectRole", "User");
        //                        //RolesAssign(roles, true);
        //                    }
        //                    else
        //                    {
        //                        ModelState.AddModelError(string.Empty, "No roles assigned, Please contact Admin");
        //                    }

        //                }
        //                else
        //                {
        //                    ModelState.AddModelError("", "Invalid Login Attempt");
        //                }
        //                    return View(model);
        //            }
        //            else
        //            {
        //                var passwordHasher = new PasswordHasher<User>();
        //                var passwordVerificationResult = passwordHasher.VerifyHashedPassword(users, users.PasswordHash, model.Password);

        //                if (passwordVerificationResult == PasswordVerificationResult.Success)
        //                {
        //                    if (roles.Count != 0)
        //                    {
        //                        //if (roles.Count() == 1)
        //                        //{
        //                        if (roles[0].ToString().ToUpper() == "ADMIN")
        //                        {
        //                            return RedirectToAction("AdminDashboard", "Admin");
        //                        }
        //                        else if (roles[0].ToString().ToUpper() == "USER")
        //                        {
        //                            return RedirectToAction("UserThread", "User");
        //                        }

        //                        //RolesAssign(roles, true);
        //                        //}
        //                        //else
        //                        //{
        //                        //    return RedirectToAction("SelectRole", "User");
        //                        //}
        //                    }
        //                    else
        //                    {
        //                        ModelState.AddModelError(string.Empty, "No roles assigned, Please contact Admin");
        //                    }

        //                }
        //                else
        //                {
        //                    ModelState.AddModelError("", "Invalid Login Attempt");
        //                }
        //                    return View(model);

        //            }
        //        }
        //        else
        //        {
        //            ModelState.AddModelError("", "User Not Found, Please contact Maneger to add new user.");
        //            return View(model);
        //        }

        //    }
        //    else
        //    {
        //        ModelState.AddModelError(string.Empty, "Invalid login attempt.");
        //        return View(model);
        //    }
        //}

        //[HttpPost]
        //public async Task<IActionResult> Login(LoginViewModel model)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        User user = _ctx.Users.FirstOrDefault(x => x.CitrixId.ToLower() == model.CitrixId.ToLower());
        //        var users = await userManger.FindByNameAsync(model.CitrixId);

        //        if (user != null)
        //        {
        //            var roles = await userManger.GetRolesAsync(users);

        //            if (user.IsLDAP)
        //            {
        //                var result = await defaultsignInManager.CheckPasswordSignInAsync(users, model.Password, false);

        //                if (result.Succeeded)
        //                {
        //                    if (roles.Any())
        //                    {
        //                        string userRole = roles.First().ToUpper();

        //                        if (userRole == "ADMIN")
        //                        {
        //                            return RedirectToAction("AdminDashboard", "Admin");
        //                        }
        //                        else if (userRole == "USER")
        //                        {
        //                            return RedirectToAction("UserThread", "User");
        //                        }
        //                    }
        //                    else
        //                    {
        //                        ModelState.AddModelError(string.Empty, "No roles assigned, please contact Admin.");
        //                    }
        //                }
        //                else
        //                {
        //                    ModelState.AddModelError("", "Invalid Login Attempt");
        //                }
        //            }
        //            else
        //            {
        //            //    var passwordHasher = new PasswordHasher<User>();
        //            //    var passwordVerificationResult = passwordHasher.VerifyHashedPassword(user, user.PasswordHash, model.Password);
        //                var result = await signInManager.CheckPasswordSignInAsync(users, model.Password, false);
        //                if (result.Succeeded)
        //                {
        //                    if (roles.Any())
        //                    {
        //                        string userRole = roles.First().ToUpper();

        //                        if (userRole == "ADMIN")
        //                        {
        //                            return RedirectToAction("AdminDashboard", "Admin");
        //                        }
        //                        else if (userRole == "USER")
        //                        {
        //                            return RedirectToAction("UserThread", "User");
        //                        }
        //                    }
        //                    else
        //                    {
        //                        ModelState.AddModelError(string.Empty, "No roles assigned, please contact Admin.");
        //                    }
        //                }
        //                else
        //                {
        //                    ModelState.AddModelError("", "Invalid Login Attempt");
        //                }
        //            }
        //        }
        //        else
        //        {
        //            ModelState.AddModelError("", "User not found, please contact Manager to add a new user.");
        //        }
        //    }
        //    else
        //    {
        //        ModelState.AddModelError(string.Empty, "Invalid login attempt.");
        //    }

        //    return View(model);
        //}
        #endregion

        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                User users = _ctx.User.Where(x => x.CitrixId == model.CitrixId && x.IsDelete == false && x.IsActive == true).FirstOrDefault();
                if (users == null)
                {
                    ModelState.AddModelError(string.Empty, "Invalid user id.");
                    return View(model);
                }
                if (users.IsLDAP == false)
                {
                    if (users.IsReset == false)
                    {
                        //var token = await userManger.GeneratePasswordResetTokenAsync(users);
                        //var result1 = await userManger.ResetPasswordAsync(users, token, "Abcd@1234");
                        //_ctx.SaveChanges();
                        var result = await defaultsignInManager.PasswordSignInAsync(users, model.Password, false, false);
                        if (result.Succeeded)
                        {
                            var user = await userManger.FindByNameAsync(model.CitrixId);
                            var roles = await userManger.GetRolesAsync(user);

                            if (roles.Count != 0)
                            {
                                if (roles.Count() == 1)
                                {
                                    if (roles[0].ToString().ToUpper() == "ADMIN" || roles[0].ToString().ToUpper() == "SUPERVISOR" || roles[0].ToString().ToUpper() == "MANAGER")
                                    {
                                        return RedirectToAction("AdminDashboard", "Admin");
                                    }
                                    else if (roles[0].ToString().ToUpper() == "USER")
                                    {
                                        return RedirectToAction("UserThread", "User");
                                    }
                                }
                                else
                                    return RedirectToAction("SelectRole", "User");
                            }
                            else
                                ModelState.AddModelError(string.Empty, "No roles assigned, Please contact Admin");

                        }
                        ModelState.AddModelError("", "Invalid Login Attempt");
                        return View(model);
                    }
                    else
                    {

                        return RedirectToAction("ChangePassword", "Account", new { Username = users.UserName });
                    }
                }
                else
                {
                    var result = await ldapUserManager.CheckPasswordAsync(users, model.Password);

                    if (result)
                    {
                        await defaultsignInManager.SignInAsync(users, isPersistent: false);
                        var user = await userManger.FindByNameAsync(model.CitrixId);
                        var roles = await userManger.GetRolesAsync(user);

                        if (roles.Count != 0)
                        {
                            if (roles.Count() == 1)
                            {
                                if (roles[0].ToString().ToUpper() == "ADMIN" || roles[0].ToString().ToUpper() == "SUPERVISOR" || roles[0].ToString().ToUpper() == "MANAGER")
                                {
                                    return RedirectToAction("AdminDashboard", "Admin");
                                }
                                else if (roles[0].ToString().ToUpper() == "USER")
                                {
                                    return RedirectToAction("UserThread", "User");
                                }
                            }
                            else
                                return RedirectToAction("SelectRole", "User");
                        }
                        else
                            ModelState.AddModelError(string.Empty, "No roles assigned, Please contact Admin");

                    }
                    ModelState.AddModelError("", "Invalid Login Attempt");
                    return View(model);
                }
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Invalid login attempt.");
                return View(model);
            }
        }
        [HttpGet]
        public IActionResult Register()
        {
            ViewData["roles"] = roleManager.Roles.ToList();


            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {

            var user = new User
            {
                CitrixId = model.CitrixId.Trim(),
                Wnsid = model.Wnsid,
                UserName = model.UserName.ToString().Trim(),
                DocContact = string.Empty,
            };
            var result = await userManger.CreateAsync(user);

            _ctx.SaveChanges();
            if (result.Succeeded)
            {
                return RedirectToAction("Index", "Account");
            }
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError("", error.Description);
            }
            //}

            return View(model);
        }

        [HttpPost]
        public async Task<JsonResult> UpdateRoles(UpdateRoleModel assignedRole)
        {
            var userrole = _ctx.UserRoles.Where(x => x.UserId == assignedRole.UserId).ToList();
            try
            {
                _ctx.RemoveRange(userrole);

                if (assignedRole.RoleList != null)
                    foreach (var multi in assignedRole.RoleList)
                    {
                        _ctx.UserRoles.Add(new IdentityUserRole<string>
                        {
                            UserId = assignedRole.UserId,
                            RoleId = multi.RoleId,
                        });
                    }

                _ctx.SaveChanges();
                return Json("success");

            }
            catch (Exception ex)
            {
                return Json("failed");
            }
        }

        [HttpPost]
        public async Task<JsonResult> UpdateThread(UpdateThreadModel assignedThread)
        {
            var threadRelation = _ctx.ThreadRelation.Where(x => x.UserId == assignedThread.UserId).ToList();

            try
            {
                _ctx.RemoveRange(threadRelation);

                if (assignedThread.ThreadList != null)
                    foreach (var multi in assignedThread.ThreadList)
                    {
                        _ctx.ThreadRelation.Add(new ThreadRelation
                        {
                            Id = Guid.NewGuid().ToString(),
                            UserId = assignedThread.UserId,
                            ThreadId = multi.ThreadId,
                            IsActive = true
                        });
                    }

                _ctx.SaveChanges();
                return Json("success");

            }
            catch (Exception ex)
            {
                return Json("failed");
            }
        }


        [HttpPost]
        public async Task<JsonResult> UpdateLocation(UpdateLocationModel assignedLocation)
        {
            var locationRelation = _ctx.UserLocationRelation.Where(x => x.UserId == assignedLocation.UserId).ToList();

            try
            {
                _ctx.RemoveRange(locationRelation);

                if (assignedLocation.LocationList != null)
                    foreach (var multi in assignedLocation.LocationList)
                    {
                        _ctx.UserLocationRelation.Add(new UserLocationRelation
                        {
                            Id = Guid.NewGuid().ToString(),
                            UserId = assignedLocation.UserId,
                            LocationId = multi.LocationId,
                            Sequance = 999
                        });
                    }

                _ctx.SaveChanges();
                return Json("success");

            }
            catch (Exception ex)
            {
                return Json("failed");
            }
        }

        // POST action to update user information
        [HttpPost]
        public IActionResult EditUser(string userId, string newUsername, string newCitrixId, string newWnsId)
        {
            try
            {
                // Find the user in the database by userId
                var user = _ctx.User.FirstOrDefault(u => u.Id == userId);

                if (user == null)
                {
                    return NotFound(); // User not found
                }

                // Update the user's information
                user.UserName = newUsername;
                user.CitrixId = newCitrixId;
                user.Wnsid = newWnsId;
                user.NormalizedUserName = newCitrixId.ToUpper();
                // Hash the password before storing it in the database
                //var passwordHash = new PasswordHasher<User>();
                //user.PasswordHash = passwordHash.HashPassword(user, "Abcd@1234");
                _ctx.SaveChanges(); // Save changes to the database

                return Json("User updated successfully");
            }
            catch (Exception ex)
            {
                // Handle any exceptions here, e.g., log the error
                return Json(500, "An error occurred while updating user information");
            }
        }

        [HttpGet]
        public IActionResult ChangePassword(string Username)
        {
            if (Username == null)
            {
                if (User.Identity.IsAuthenticated)
                {
                    Username = userManger.GetUserName(User).ToString();
                }
            }

            ViewData["roles"] = roleManager.Roles.ToList();
            ViewData["User"] = userManger.Users.FirstOrDefault(x => x.UserName == Username);

            return View();
        }


        //[HttpPost]
        //public async Task<IActionResult> ResetPassword(ChangePasswordViewModel model)
        //{
        //    //var users = _ctx.User.Where(x => x.UserName == "ravindram").FirstOrDefault();
        //    var user1 = await userManger.GetUserAsync(User);
        //    var result = await userManger.ChangePasswordAsync(user1, model.CurrentPassword, model.NewPassword);
        //    _ctx.SaveChanges();

        //    if (result.Succeeded)
        //    {
        //        return RedirectToAction("Index", "Account");
        //    }
        //    foreach (var error in result.Errors)
        //    {
        //        ModelState.AddModelError("", error.Description);
        //    }

        //    //return View(model);
        //    return RedirectToAction("Login", "Account");
        //}

        [HttpPost]
        public async Task<IActionResult> ChangePassword(ChangePasswordViewModel model)
        {
            //var user = await userManger.GetUserAsync(User);

            //if (user == null)
            //{
            //    // Handle the case where the user is not found
            //    return NotFound();
            //}

            if (ModelState.IsValid)
            {
                User user = new User();

                if (User.Identity.IsAuthenticated)
                {
                    user = await userManger.GetUserAsync(User);
                }
                else
                {
                    user = _ctx.User.FirstOrDefault(x => x.UserName == model.Username);
                    user.IsReset = false;
                    _ctx.Update(user);
                }

                var result = await userManger.ChangePasswordAsync(user, model.CurrentPassword.Trim(), model.NewPassword.Trim());

                if (result.Succeeded)
                {
                    return Json("success");
                }

                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError("", error.Description);
                }
            }

            ViewData["roles"] = roleManager.Roles.ToList();
            return View("ChangePassword", model);
        }




        private bool IsPasswordValid(string password)
        {
            // Add your password validation logic here
            // For example, using a regular expression
            const string passwordRegex = @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\da-zA-Z]).{8,}$";
            return Regex.IsMatch(password, passwordRegex);
        }


        public IActionResult ResetPassword()
        {
            // Retrieve users based on role (in this case, "user")
            ViewData["User"] = _ctx.Users.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            return View();
        }

        // POST: /User/GeneratePassword
        [HttpPost]
        public IActionResult GeneratePassword(string userName)
        {
            // Generate random password
            string newPassword = GenerateRandomPassword();
            newPassword = newPassword.Trim();

            // Update user's password
            var user = userManger.FindByNameAsync(userName).Result;
            var token = userManger.GeneratePasswordResetTokenAsync(user).Result;
            var result = userManger.ResetPasswordAsync(user, token, newPassword).Result;


            if (result.Succeeded)
            {
                // Save the new password to the database or perform any other necessary actions
                // You can add code here to save the newPassword to the database
                // For simplicity, I'll assume you have a method like SavePasswordToDatabase(userId, newPassword)

                // SavePasswordToDatabase(userId, newPassword);

                // Return the new password to the view
                return Json(new { newPassword });
            }
            else
            {
                // Handle password reset failure
                return Json(new { error = "Password reset failed." });
            }
        }

        //private string GenerateRandomPassword()
        //{
        //    // Implement your logic to generate a random password here
        //    // For simplicity, I'll generate a random string of length 8
        //    const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789~!@#$%^&*()_+/`';.,/][}{:?><";
        //    var random = new Random();
        //    return new string(Enumerable.Repeat(chars, 12)
        //      .Select(s => s[random.Next(s.Length)]).ToArray());
        //}


        // While creating random password check validation for must contain at least 1 digit one uppercase and one special character
        private string GenerateRandomPassword()
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789~!@#$%^&*()_+/`';.,/][}{:?><";
            var random = new Random();

            // Generate until the password meets the requirements
            string newPassword;
            do
            {
                newPassword = new string(Enumerable.Repeat(chars, 12)
                  .Select(s => s[random.Next(s.Length)]).ToArray());
            } while (!PasswordMeetsRequirements(newPassword));

            return newPassword;
        }

        private bool PasswordMeetsRequirements(string password)
        {
            // Check if the password contains at least one digit, one uppercase letter, and one special character
            return password.Any(char.IsDigit) && password.Any(char.IsUpper) && password.Any(char.IsLower) && password.Any(IsSpecialCharacter);
        }

        private bool IsSpecialCharacter(char c)
        {
            const string specialCharacters = "~!@#$%^&*()_+/`';.,/][}{:?<>";

            // Check if the character is a special character
            return specialCharacters.Contains(c);
        }



        //public async Task<IActionResult> RolesAssign(IList<string>? roles, bool success)
        //{
        //    if (roles[0].ToString().ToUpper() == "ADMIN")
        //    {
        //        return RedirectToAction("AdminDashboard", "Admin");
        //    }
        //    else if (roles[0].ToString().ToUpper() == "USER")
        //    {
        //        return RedirectToAction("UserThread", "User");
        //    }
        //    ModelState.AddModelError("", "Invalid Login Attempt");
        //    return View("Roles not found, please conatct admin to create role.");
        //}

        public async Task<IActionResult> Logout()
        {
            await defaultsignInManager.SignOutAsync();
            return RedirectToAction("Login", "Account");
        }
    }
}