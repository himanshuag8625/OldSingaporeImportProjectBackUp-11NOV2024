﻿using CAImportWorkflow.Data;
using CAImportWorkflow.Models;
using ClosedXML.Excel;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Globalization;
using System.Linq.Dynamic.Core;
using System.Reflection;
using System.Security.Claims;

namespace CAImportWorkflow.Controllers
{
    public class UserController : Controller
    {
        ApplicationDbContext _ctx;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly RoleManager<Role> roleManager;
        private readonly UserManager<User> userManger;
        private readonly SignInManager<User> signInManager;
        public UserController(ApplicationDbContext ctx, IHttpContextAccessor httpContextAccessor, UserManager<User> userManger, SignInManager<User> signInManager, RoleManager<Role> roleManager)
        {
            _ctx = ctx;
            _httpContextAccessor = httpContextAccessor;
            this.roleManager = roleManager;
            this.userManger = userManger;
            this.signInManager = signInManager;

        }

        [HttpGet]
        public IActionResult SelectRole()
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

            ViewData["AssignedRoles"] = _ctx.UserRoles.Where(x => x.UserId == userid).Select(x => new RoleNameList
            {
                RoleId = x.RoleId,
                RoleName = _ctx.Roles.Where(y => y.Id == x.RoleId).Select(x => x.Name).FirstOrDefault()

            }).ToList();
            return View();
        }
        public IActionResult UserThread()
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

            ViewData["UserThread"] = _ctx.ThreadRelation.Include(x => x.ThreadMaster).Where(x => x.UserId == userid && x.ThreadMaster.IsActive == true).Select(x => new ThreadMaster
            {
                Id = x.ThreadMaster.Id,
                Name = x.ThreadMaster.Name,

            }).ToList();
            return View();
        }


        [HttpGet]
        public IActionResult RoleAction(string RoleName)
        {
            if (RoleName.ToUpper() == "ADMIN" || RoleName.ToUpper() == "SUPERVISOR" || RoleName.ToUpper() == "MANAGER")
            {
                return RedirectToAction("AdminDashboard", "Admin");
            }
            else if (RoleName.ToUpper() == "USER")
            {
                return RedirectToAction("UserThread", "User");
            }
            else
            {
                return RedirectToAction("GetItem", "Invoice");
            }

            return View();
        }

        [HttpGet]
        public IActionResult UserAction(string ThreadName)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            ViewData["ThreadName"] = _ctx.ThreadMaster.Where(x => x.Id == ThreadName).FirstOrDefault();
            ViewData["ThreadList"] = _ctx.ThreadMaster.Where(x => x.Id == ThreadName).ToList();
            ViewData["HblactivityList"] = _ctx.ActivityMaster.Where(x => x.IsActive == true && x.BasedOn == "HBL" && x.ThreadId == ThreadName).Select(x => new ActivityMaster
            {
                Id = x.Id,
                Name = x.Name,
                BasedOn = x.BasedOn,
                ThreadId = x.ThreadId,
            }).ToList();

            ViewData["FileactivityList"] = _ctx.ActivityMaster.Where(x => x.IsActive == true && x.BasedOn == "File" && x.ThreadId == ThreadName).Select(x => new ActivityMaster
            {
                Id = x.Id,
                Name = x.Name,
                BasedOn = x.BasedOn,
                ThreadId = x.ThreadId,
            }).ToList();

            ViewData["ActivityMappingList"] = _ctx.ActivityMapping.Include(x => x.FileActivityMaster).Where(x => x.IsActive == true && x.FileActivityMaster.BasedOn == "File" && x.FileActivityMaster.ThreadId == ThreadName).ToList();

            ViewData["Location"] = _ctx.UserLocationRelation.Where(x => x.UserId == userid).Select(x => new LocationMaster
            {
                Id = x.LocationMaster.Id,
                Name =x.LocationMaster.Name,

            }).ToList();

            return View();
        }

        [HttpGet]
        public JsonResult CheckHBLActivityStatus(string fileActivityId)
        {
            List<ActivityMapping> activityMappings = _ctx.ActivityMapping.Where(x => x.IsActive == true && x.FileActivityId == fileActivityId).ToList();
            return Json(activityMappings);

        }

        [HttpGet]
        public JsonResult ResetFileActivityStatus(string hblActivityId)
        {
            List<ActivityMapping> activityMappings = _ctx.ActivityMapping.Where(x => x.IsActive == true && x.HBLActivityId == hblActivityId).ToList();
            return Json(activityMappings);
        }

        static DateTime GetDate(string Column0)
        {
            DateTime dt;
            if (!DateTime.TryParseExact(Column0, "yyyy/dd/MM hh:mm:ss tt",
                       CultureInfo.InvariantCulture,
                       DateTimeStyles.None, out dt))
            {
                dt = DateTime.MinValue;
            }

            return dt;
        }

        [HttpGet]
        public JsonResult GetNextFile(string threadmasterId, string Location)
        {
            if (Location == null || Location.ToString().Trim() == "" || Location.ToString().Trim() == "--Select")
            {
                return Json("Select Location");
            }
            else
            {


                var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);


                SubmitDataViewModel submitDataViewModel = new SubmitDataViewModel();

                submitDataViewModel.HBLDataSubmit = new List<HblDataSubmitViewModel>();
                submitDataViewModel.FileActivityStatusSubmit = new List<FileActivityStatus>();
                submitDataViewModel.Activities = new List<ActivityMaster>();
                submitDataViewModel.file = new List<FileData>();

                List<HblEntry> hblEntryResult = new List<HblEntry>();
                List<FileActivity> fileActresult = new List<FileActivity>();
                List<HblActivity> hblActResult = new List<HblActivity>();

                submitDataViewModel.Activities = _ctx.ActivityMaster.Where(x => x.ThreadId == threadmasterId.Trim() && x.ThreadMaster.IsActive == true && x.IsActive == true).ToList();
                DateTime dtETA;

                var allocates = _ctx.FileActivity.Include(x => x.FileEntry).Where(x => x.CurrentStatus == "WIP" && x.UserId == userid && 
                                x.ActivityMaster.ThreadId == threadmasterId.Trim() && x.ActivityMaster.ThreadMaster.IsActive == true && 
                                x.ActivityMaster.IsActive == true).Select(x => new 
                                { 
                                    x.FileId, 
                                    x.FileEntry.EtaAtPod 
                                }).Distinct().ToList();///Distinct Removed
                var allocate = allocates.OrderBy(x => x.EtaAtPod).FirstOrDefault();
                if (allocate == null)
                {
                    allocates = _ctx.FileActivity.Include(x => x.FileEntry).Where(x => x.CurrentStatus == "WIP" && x.UserId == null && 
                                x.ActivityMaster.ThreadId == threadmasterId.Trim() && x.FileEntry.Pod == Location.Trim() && 
                                x.ActivityMaster.ThreadMaster.IsActive == true && x.ActivityMaster.IsActive == true).Select(x => new 
                                { 
                                    x.FileId, 
                                    x.FileEntry.EtaAtPod 
                                }).Distinct().ToList();///Distinct Removed
                    allocate = allocates.OrderBy(x => x.EtaAtPod).FirstOrDefault();
                    if (allocate != null)
                    {
                        List<FileActivity> fileActivityList = _ctx.FileActivity.Include(x => x.FileEntry).Where(x => x.CurrentStatus == "WIP" && 
                                                               x.UserId == null && x.ActivityMaster.ThreadId == threadmasterId.Trim() && 
                                                               x.FileId == allocate.FileId.ToString() && x.ActivityMaster.ThreadMaster.IsActive == true && 
                                                               x.ActivityMaster.IsActive == true).OrderBy(x => x.FileEntry.EtaAtPod).ToList();

                        foreach (FileActivity activity in fileActivityList)
                        {
                            activity.UserId = userid;
                            activity.StartTime = DateTime.UtcNow;
                            _ctx.FileActivity.Update(activity);
                        }
                        _ctx.SaveChanges();

                        allocate = _ctx.FileActivity.Include(x => x.FileEntry).Where(x => x.CurrentStatus == "WIP" && x.UserId == userid && 
                                    x.ActivityMaster.ThreadId == threadmasterId.Trim() && x.FileEntry.Pod == Location.Trim() && 
                                    x.ActivityMaster.ThreadMaster.IsActive == true && x.ActivityMaster.IsActive == true).OrderBy(x => x.FileEntry.EtaAtPod).Select(x => new 
                                    { 
                                        x.FileId, 
                                        x.FileEntry.EtaAtPod 
                                    }).Distinct().FirstOrDefault(); ///Distinct Removed
                    }
                }

                if (allocate != null)
                {
                    submitDataViewModel.file = _ctx.FileEntry.Where(x => x.Id == allocate.FileId.ToString() && x.Pod == Location.Trim())
                        .Select(x => new FileData 
                        { 
                            FileNo = x.FileNo, 
                            Id = x.Id, 
                            ContainerNo = x.ContainerNo, 
                            pol = _ctx.POLMaster.Where(y => y.Id == x.Pol).Select(y => y.Name).FirstOrDefault(), 
                            pod = _ctx.LocationMaster.Where(y => y.Id == x.Pod).Select(y => y.Name).FirstOrDefault(), 
                            ETAatPOD = x.EtaAtPod, 
                            Hblcount = x.Hblcount, 
                            ProductType = x.ProductType, 
                            FileType = x.FileType 
                        }).ToList();

                    if (submitDataViewModel.file == null || submitDataViewModel.file.Count() <= 0)
                    {
                        var loc = _ctx.FileEntry.Where(x => x.Id == allocate.FileId).Select(x => x.Pod).FirstOrDefault();
                        var locationname = _ctx.LocationMaster.Where(x => x.Id == loc).FirstOrDefault();
                        return Json("You Already have allocated file in " + locationname.Name + " Location");
                    }
                    else
                    {
                        //submitDataViewModel.file = _ctx.FileEntry.Where(x => x.Id == allocate.FileId.ToString()).Select(x => new FileData { FileNo = x.FileNo, Id = x.Id, ContainerNo = x.ContainerNo, pol = x.Pol, pod = _ctx.LocationMaster.Where(y => y.Id == x.Pod).Select(y => y.Name).FirstOrDefault(), ETAatPOD = x.EtaAtPod, Hblcount = x.Hblcount }).ToList();
                        fileActresult = _ctx.FileActivity.Include(y => y.ActivityMaster).ThenInclude(x => x.ThreadMaster).Where(x => 
                                        x.FileId == submitDataViewModel.file[0].Id.ToString() && x.ActivityMaster.ThreadId == threadmasterId.Trim() && 
                                        x.FileEntry.Pod == Location.Trim() && x.ActivityMaster.ThreadMaster.IsActive == true && 
                                        x.ActivityMaster.IsActive == true).ToList();
                        //if(fileActresult != null)
                        //{
                        //    var locationname = _ctx.LocationMaster.Where(x => x.Id == Location).FirstOrDefault();
                        //    return Json("You Already have allocated file in "+locationname.Name+" Location");
                        //}
                        //else
                        //{
                        foreach (FileActivity fileActivity in fileActresult)
                        {
                            fileActivity.StartTime = DateTime.UtcNow;
                            _ctx.FileActivity.Update(fileActivity);

                            submitDataViewModel.FileActivityStatusSubmit.Add(new FileActivityStatus
                            {
                                ActivityId = fileActivity.ActivityId.ToString(),
                                CurrentStatus = fileActivity.CurrentStatus,
                                Comments = fileActivity.Comment == null ? "" : fileActivity.Comment
                            });
                        }

                        hblEntryResult = _ctx.HblEntry.Where(x => x.FileGuidId == submitDataViewModel.file[0].Id.ToString()).ToList();
                        foreach (HblEntry hbl in hblEntryResult)
                        {
                            hblActResult = _ctx.HblActivity.Include(y => y.ActivityMaster).ThenInclude(x => x.ThreadMaster).Where(x => x.HblId == hbl.Id && 
                                            x.ActivityMaster.ThreadMaster.IsActive == true && x.ActivityMaster.IsActive == true).ToList();

                            List<HBLActivityStatus> hBLActivityStatuses = new List<HBLActivityStatus>();

                            foreach (HblActivity hblActivity in hblActResult)
                            {
                                HBLActivityStatus hBLActivityStatus = new HBLActivityStatus
                                {
                                    ActivityId = hblActivity.ActivityId.ToString(),
                                    Status = hblActivity.CurrentStatus,
                                    HblComments = hblActivity.Comment
                                };

                                hBLActivityStatuses.Add(hBLActivityStatus);
                            }

                            if (hBLActivityStatuses.Count > 0)
                            {
                                HblDataSubmitViewModel hblDataSubmitViewModel = new HblDataSubmitViewModel
                                {
                                    HblNo = hbl.Hblno,
                                    IsDap = hbl.IsDap == true ? "Yes" : "No",
                                    HBLActivityStatuses = hBLActivityStatuses
                                };
                                submitDataViewModel.HBLDataSubmit.Add(hblDataSubmitViewModel);

                            }
                            else
                            {
                                HblDataSubmitViewModel hblDataSubmitViewModel = new HblDataSubmitViewModel
                                {
                                    HblNo = hbl.Hblno,
                                    IsDap = hbl.IsDap == true ? "Yes" : "No",
                                };
                                submitDataViewModel.HBLDataSubmit.Add(hblDataSubmitViewModel);
                            }



                            //}
                        }
                    }

                }

                return Json(submitDataViewModel);
            }
            return Json("Failed");

        }

        [HttpPost]
        public JsonResult SaveData(SubmitDataViewModel model)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

            if (model.HBLDataSubmit != null)
            {
                foreach (HblDataSubmitViewModel hblvm in model.HBLDataSubmit)
                {
                    string hblId = "";

                    if (hblvm.HblNo != null && hblvm.HblNo.Trim() != "")
                    {
                        HblEntry hblEntry = _ctx.HblEntry.Where(x => x.Hblno == hblvm.HblNo).FirstOrDefault();
                        if (hblEntry == null)
                        {
                            HblEntry hblentry = new HblEntry
                            {
                                Id = Guid.NewGuid().ToString(),
                                FileGuidId = model.file[0].Id,
                                Hblno = hblvm.HblNo,
                                IsDap = hblvm.IsDap.ToUpper() == "YES" || hblvm.IsDap.ToUpper() == "TRUE" ? true : false,
                                CreatedBy = userid,
                                CreatedDate = DateTime.Now.ToUniversalTime(),
                            };

                            hblId = hblentry.Id;

                            _ctx.HblEntry.Add(hblentry);
                        }
                        else
                        {
                            hblId = hblEntry.Id;
                            hblEntry.Hblno = hblvm.HblNo;
                            hblEntry.IsDap = hblvm.IsDap.ToUpper() == "YES" || hblvm.IsDap.ToUpper() == "TRUE" ? true : false;
                            hblEntry.CreatedDate = DateTime.Now.ToUniversalTime();
                            _ctx.HblEntry.Update(hblEntry);
                        }

                        foreach (HBLActivityStatus status in hblvm.HBLActivityStatuses)
                        {
                            if (status.Status != "" && !status.Status.Contains("Select"))
                            {

                                HblActivity hblact = _ctx.HblActivity.Where(x => x.ActivityId == status.ActivityId && x.HblId == hblId).FirstOrDefault();
                                if (hblact == null)
                                {
                                    HblActivity hblActivity = new HblActivity
                                    {
                                        Id = Guid.NewGuid().ToString(),
                                        HblId = hblId,
                                        ActivityId = status.ActivityId,
                                        CurrentStatus = status.Status,
                                        Comment = status.HblComments,
                                        StartTime = status.StartTime,
                                        EndTime = DateTime.Now.ToUniversalTime(),
                                        EnterBy = userid,
                                        EnterDate = DateTime.Now.ToUniversalTime()
                                    };
                                    _ctx.HblActivity.Add(hblActivity);
                                }
                                else
                                {
                                    hblact.StartTime = status.StartTime;
                                    hblact.CurrentStatus = status.Status;
                                    hblact.Comment = status.HblComments;
                                    hblact.EndTime = DateTime.Now.ToUniversalTime();

                                    _ctx.HblActivity.Update(hblact);
                                }
                            }
                        }
                    }
                    _ctx.SaveChanges();
                }


            }

            FileEntry fileEntry = _ctx.FileEntry.Where(x => x.Id == model.file[0].Id).FirstOrDefault();
            var pol = _ctx.POLMaster.Where(x => x.Name == model.file[0].pol).FirstOrDefault();
            var pod = _ctx.LocationMaster.Where(x => x.Name == model.file[0].pod).FirstOrDefault();
            if (fileEntry != null)
            {
                fileEntry.FileNo = model.file[0].FileNo;
                fileEntry.ContainerNo = model.file[0].ContainerNo;
                fileEntry.EtaAtPod = model.file[0].ETAatPOD;
                fileEntry.Pol = pol.Id;
                fileEntry.Pod = pod.Id;
                fileEntry.ProductType = model.file[0].ProductType;
                fileEntry.FileType = model.file[0].FileType;

                _ctx.FileEntry.Update(fileEntry);
                string firstActivity = "";

                bool flag = false;
                foreach (var fileActivityStatus in model.FileActivityStatusSubmit)
                {
                    if (!fileActivityStatus.CurrentStatus.Contains("Select"))
                    {
                        if (!flag)
                        {
                            firstActivity = fileActivityStatus.ActivityId;
                            flag = true;
                        }

                        FileActivity fileActivity = _ctx.FileActivity.Where(x => x.ActivityId == fileActivityStatus.ActivityId && x.FileId == model.file[0].Id).FirstOrDefault();

                        fileActivity.StartTime = fileActivityStatus.StartTime;
                        fileActivity.CurrentStatus = fileActivityStatus.CurrentStatus;
                        fileActivity.Comment = fileActivityStatus.Comments;
                        fileActivity.Pages = fileActivityStatus.Pages;
                        fileActivity.EndTime = DateTime.Now.ToUniversalTime();
                        _ctx.FileActivity.Update(fileActivity);
                        _ctx.SaveChanges();
                    }
                }

                var CurrentThreadId = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.Id == firstActivity && x.IsActive == true && x.ThreadMaster.IsActive == true).Select(x => x.ThreadMaster).FirstOrDefault();

                ThreadMaster threadMaster = _ctx.ThreadMaster.Include(x => x.ActivityMaster.Where(x => x.BasedOn == "File")).Where(x => x.Sequance > CurrentThreadId.Sequance && x.IsActive == true).OrderBy(i => i.Sequance).FirstOrDefault();//_ctx.ThreadMaster.SkipWhile(x => x.Id != CurrentThreadId).Skip(1).FirstOrDefault();
                if (threadMaster != null && threadMaster.ActivityMaster.Count > 0)
                {
                    foreach (ActivityMaster activity in threadMaster.ActivityMaster.ToList())
                    {

                        FileActivity fileNextActivity = _ctx.FileActivity.Where(x => x.ActivityId == activity.Id && x.FileId == model.file[0].Id && x.ActivityMaster.IsActive == true).FirstOrDefault();

                        if (fileNextActivity == null)
                        {
                            _ctx.FileActivity.Add(new FileActivity
                            {
                                Id = Guid.NewGuid().ToString(),
                                FileId = model.file[0].Id,
                                ActivityId = activity.Id,
                                CurrentStatus = "WIP",
                                Comment = null,
                                UserId = null,
                                EnterDate = DateTime.Now.ToUniversalTime(),
                                StartTime = null,
                                EndTime = null
                            });
                        }
                    }
                    _ctx.SaveChanges();
                }

            }
            return Json("Success");
        }

        [HttpGet]
        public IActionResult UserActivityStatus([FromQuery(Name = "ThreadName")] string threadName, DateTime? StartDate, DateTime? EndDate)
        {

            UserActivityStatusViewModel userActivityStatus = new UserActivityStatusViewModel();
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var fileActivity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.BasedOn == "File" && x.ThreadMaster.IsActive == true && x.IsActive == true).OrderBy(x => x.Name).ToList();
            var hblActivity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.BasedOn == "HBL" && x.ThreadMaster.IsActive == true && x.IsActive == true).OrderBy(x => x.Name).ToList();
            foreach (var item in fileActivity)
            {
                userActivityStatus.GetFileActivityStatus.Add(new FileActivityStatusList
                {
                    Activity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.Id == item.Id && x.BasedOn == "File" && x.ThreadMaster.IsActive == true && x.IsActive == true).Select(x => x.Name).FirstOrDefault(),
                    UserId = _ctx.User.Where(x => x.Id == userid).Select(x => x.UserName).FirstOrDefault(),
                    WIP = _ctx.FileActivity.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                    Completed = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                    CompletedWithQuery = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                    Pending = _ctx.FileActivity.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                    Query = _ctx.FileActivity.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                    Total = _ctx.FileActivity.Where(x => x.ActivityId == item.Id && x.UserId == userid).Count(),
                });
            }


            foreach (var item in hblActivity)
            {
                userActivityStatus.GetHBLActivityStatus.Add(new HBLActivityStatusList
                {
                    Activity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.Id == item.Id && x.BasedOn == "HBL" && x.ThreadMaster.IsActive == true && x.IsActive == true).Select(x => x.Name).FirstOrDefault(),
                    UserId = _ctx.User.Where(x => x.Id == userid).Select(x => x.UserName).FirstOrDefault(),
                    WIP = _ctx.HblActivity.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.EnterBy == userid).Count(),
                    Completed = _ctx.HblActivity.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.EnterBy == userid).Count(),
                    CompletedWithQuery = _ctx.HblActivity.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.EnterBy == userid).Count(),
                    Pending = _ctx.HblActivity.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.EnterBy == userid).Count(),
                    Query = _ctx.HblActivity.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.EnterBy == userid).Count(),
                    Total = _ctx.HblActivity.Where(x => x.ActivityId == item.Id && x.EnterBy == userid).Count(),
                });
            }
            return View(userActivityStatus);
        }

        [HttpPost]
        public IActionResult UserActivityStatusList(DateTime? StartDate, DateTime? EndDate)
        {

            UserActivityStatusViewModel userActivityStatus = new UserActivityStatusViewModel();
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var fileActivity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.BasedOn == "File" && x.ThreadMaster.IsActive == true && x.IsActive == true).OrderBy(x => x.Name).ToList();
            var hblActivity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.BasedOn == "HBL" && x.ThreadMaster.IsActive == true && x.IsActive == true).OrderBy(x => x.Name).ToList();
            if (StartDate != null && EndDate != null)
            {
                var fileActivityList = _ctx.FileActivity.Where(x => x.EndTime != null && x.EndTime.Value.Date >= StartDate.Value.Date && x.EndTime.Value.Date <= EndDate.Value.Date).ToList();
                var hblActivityList = _ctx.HblActivity.Where(x => x.EndTime != null && x.EndTime.Value.Date >= StartDate.Value.Date && x.EndTime.Value.Date <= EndDate.Value.Date).ToList();
                foreach (var item in fileActivity)
                {
                    userActivityStatus.GetFileActivityStatus.Add(new FileActivityStatusList
                    {
                        Activity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.Id == item.Id && x.BasedOn == "File" && x.ThreadMaster.IsActive == true && x.IsActive == true).Select(x => x.Name).FirstOrDefault(),
                        UserId = _ctx.User.Where(x => x.Id == userid).Select(x => x.UserName).FirstOrDefault(),
                        WIP = fileActivityList.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Completed = fileActivityList.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        CompletedWithQuery = fileActivityList.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Pending = fileActivityList.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Query = fileActivityList.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Total = fileActivityList.Where(x => x.ActivityId == item.Id && x.UserId == userid).Count(),
                    });
                }

                foreach (var item in hblActivity)
                {
                    userActivityStatus.GetHBLActivityStatus.Add(new HBLActivityStatusList
                    {
                        Activity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.Id == item.Id && x.BasedOn == "HBL" && x.ThreadMaster.IsActive == true && x.IsActive == true).Select(x => x.Name).FirstOrDefault(),
                        UserId = _ctx.User.Where(x => x.Id == userid).Select(x => x.UserName).FirstOrDefault(),
                        WIP = hblActivityList.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.EnterBy == userid).Count(),
                        Completed = hblActivityList.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.EnterBy == userid).Count(),
                        CompletedWithQuery = hblActivityList.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.EnterBy == userid).Count(),
                        Pending = hblActivityList.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.EnterBy == userid).Count(),
                        Query = hblActivityList.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.EnterBy == userid).Count(),
                        Total = hblActivityList.Where(x => x.ActivityId == item.Id && x.EnterBy == userid).Count(),
                    });
                }
            }
            else
            {
                foreach (var item in fileActivity)
                {
                    userActivityStatus.GetFileActivityStatus.Add(new FileActivityStatusList
                    {
                        Activity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.Id == item.Id && x.BasedOn == "File" && x.ThreadMaster.IsActive == true && x.IsActive == true).Select(x => x.Name).FirstOrDefault(),
                        UserId = _ctx.User.Where(x => x.Id == userid).Select(x => x.UserName).FirstOrDefault(),
                        WIP = _ctx.FileActivity.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Completed = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        CompletedWithQuery = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Pending = _ctx.FileActivity.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Query = _ctx.FileActivity.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Total = _ctx.FileActivity.Where(x => x.ActivityId == item.Id && x.UserId == userid).Count(),
                    });
                }


                foreach (var item in hblActivity)
                {
                    userActivityStatus.GetHBLActivityStatus.Add(new HBLActivityStatusList
                    {
                        Activity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.Id == item.Id && x.BasedOn == "HBL" && x.ThreadMaster.IsActive == true && x.IsActive == true).Select(x => x.Name).FirstOrDefault(),
                        UserId = _ctx.User.Where(x => x.Id == userid).Select(x => x.UserName).FirstOrDefault(),
                        WIP = _ctx.HblActivity.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.EnterBy == userid).Count(),
                        Completed = _ctx.HblActivity.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.EnterBy == userid).Count(),
                        CompletedWithQuery = _ctx.HblActivity.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.EnterBy == userid).Count(),
                        Pending = _ctx.HblActivity.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.EnterBy == userid).Count(),
                        Query = _ctx.HblActivity.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.EnterBy == userid).Count(),
                        Total = _ctx.HblActivity.Where(x => x.ActivityId == item.Id && x.EnterBy == userid).Count(),
                    });
                }
            }
            return Json(userActivityStatus);
        }

        [HttpPost]
        public IActionResult UserDataDownload(DateTime? StartDate, DateTime? EndDate)
        {
            UserActivityStatusViewModel userActivityStatus = new UserActivityStatusViewModel();
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var fileActivity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.BasedOn == "File" && x.ThreadMaster.IsActive == true && x.IsActive == true).OrderBy(x => x.Name).ToList();
            var hblActivity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.BasedOn == "HBL").OrderBy(x => x.Name).ToList();
            if (StartDate != null && EndDate != null)
            {
                var fileActivityList = _ctx.FileActivity.Where(x => x.EnterDate.Value.Date >= StartDate.Value.Date && x.EnterDate.Value.Date <= EndDate.Value.Date).ToList();
                foreach (var item in fileActivity)
                {
                    userActivityStatus.GetFileActivityStatus.Add(new FileActivityStatusList
                    {
                        Activity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.Id == item.Id && x.BasedOn == "File" && x.ThreadMaster.IsActive == true && x.IsActive == true).Select(x => x.Name).FirstOrDefault(),
                        UserId = _ctx.User.Where(x => x.Id == userid).Select(x => x.UserName).FirstOrDefault(),
                        WIP = fileActivityList.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Completed = fileActivityList.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        CompletedWithQuery = fileActivityList.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Pending = fileActivityList.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Query = fileActivityList.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Total = fileActivityList.Where(x => x.ActivityId == item.Id && x.UserId == userid).Count(),
                    });
                }

                foreach (var item in hblActivity)
                {
                    userActivityStatus.GetHBLActivityStatus.Add(new HBLActivityStatusList
                    {
                        Activity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.Id == item.Id && x.BasedOn == "HBL" && x.ThreadMaster.IsActive == true && x.IsActive == true).Select(x => x.Name).FirstOrDefault(),
                        UserId = _ctx.User.Where(x => x.Id == userid).Select(x => x.UserName).FirstOrDefault(),
                        WIP = fileActivityList.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Completed = fileActivityList.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        CompletedWithQuery = fileActivityList.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Pending = fileActivityList.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Query = fileActivityList.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Total = fileActivityList.Where(x => x.ActivityId == item.Id && x.UserId == userid).Count(),
                    });
                }
            }
            else
            {
                foreach (var item in fileActivity)
                {
                    userActivityStatus.GetFileActivityStatus.Add(new FileActivityStatusList
                    {
                        Activity = _ctx.ActivityMaster.Include(x => x.ThreadMaster ).Where(x => x.Id == item.Id && x.BasedOn == "File" && x.ThreadMaster.IsActive == true && x.IsActive == true).Select(x => x.Name).FirstOrDefault(),
                        UserId = _ctx.User.Where(x => x.Id == userid).Select(x => x.UserName).FirstOrDefault(),
                        WIP = _ctx.FileActivity.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Completed = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        CompletedWithQuery = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Pending = _ctx.FileActivity.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Query = _ctx.FileActivity.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Total = _ctx.FileActivity.Where(x => x.ActivityId == item.Id && x.UserId == userid).Count(),
                    });
                }


                foreach (var item in hblActivity)
                {
                    userActivityStatus.GetHBLActivityStatus.Add(new HBLActivityStatusList
                    {
                        Activity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.Id == item.Id && x.BasedOn == "HBL" && x.ThreadMaster.IsActive == true && x.IsActive == true).Select(x => x.Name).FirstOrDefault(),
                        UserId = _ctx.User.Where(x => x.Id == userid).Select(x => x.UserName).FirstOrDefault(),
                        WIP = _ctx.FileActivity.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Completed = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        CompletedWithQuery = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Pending = _ctx.FileActivity.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Query = _ctx.FileActivity.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Total = _ctx.FileActivity.Where(x => x.ActivityId == item.Id && x.UserId == userid).Count(),
                    });
                }
            }

            var fileStatus = userActivityStatus.GetFileActivityStatus.Select(x => new FileStatusList
            {
                Activity = x.Activity,
                Total = x.Total,
                WIP = x.WIP,
                Query = x.Query,
                Pending = x.Pending,
                Completed = x.Completed

            }).ToList();

            var hblStatus = userActivityStatus.GetHBLActivityStatus.Select(x => new HBLStatusList
            {
                Activity = x.Activity,
                Total = x.Total,
                WIP = x.WIP,
                Query = x.Query,
                Pending = x.Pending,
                Completed = x.Completed

            }).ToList();
            DataTable FileActivityStatus = ToDataTable(fileStatus);
            DataTable HBLActivityStatus = ToDataTable(hblStatus);

            using (XLWorkbook wb = new XLWorkbook())
            {
                FileActivityStatus.TableName = "File Activity Status";
                HBLActivityStatus.TableName = "HBL Activity Status";
                var wsData = wb.Worksheets.Add(FileActivityStatus);
                var ws = wb.Worksheets.Add(HBLActivityStatus);
                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    string excelname = $"UserActivityStatus-{DateTime.UtcNow.ToString("ddmmyyyy hh:mm:ss")}.xlsx";
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                }
            }
        }

        [HttpGet]
        public IActionResult GetActivityFileData()
        {
            ViewData["ActivityMaster"] = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.ThreadMaster.IsActive == true && x.IsActive == true).ToList();

            return View();
        }

        [HttpPost]
        public IActionResult GetActivityFileData(string activity, string activityType, string status, string startDate, string fileNo, string containerNo, string hblNo)
        {
            DateTime DateTime = Convert.ToDateTime(startDate);
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            int totalRecord = 0;
            int filterRecord = 0;
            int hblrecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var fileEntryData = new List<FileActivityDataList>();
            var userName = _ctx.User.Where(x => x.Id == userid && x.IsActive == true && x.IsDelete == false).Select(x => x.UserName).FirstOrDefault();
            if (activityType == "HBL")
            {

                fileEntryData = _ctx.HblActivity.Include(x => x.ActivityMaster).Include(x => x.User).Include(x => x.HblEntry)
                    .Include(x => x.HblEntry.FileGuid).Include(x => x.HblEntry.FileGuid.FileActivity)
                    .Select(x => new FileActivityDataList
                    {
                        ActivityId = x.ActivityMaster.Name,
                        BasedOn = x.ActivityMaster.BasedOn,
                        Comment = x.Comment == null ? "" : x.Comment,
                        CurrentStatus = x.CurrentStatus,
                        EndTime = x.EndTime,
                        EnterDate = x.EnterDate,
                        CreatedDate = x.HblEntry.CreatedDate,
                        FileNo = x.HblEntry.FileGuid.FileNo,
                        ContainerNo = x.HblEntry.FileGuid.ContainerNo,
                        hblNo = x.HblEntry.Hblno,
                        Id = x.HblEntry.FileGuidId,
                        HBLId = x.HblId,
                        UserId = x.User.UserName,
                        Activity = x.ActivityId,
                        hblCount = x.HblEntry.FileGuid.Hblcount,
                        StartTime = x.StartTime

                    }).ToList();

            }
            else
            {

                fileEntryData = _ctx.FileActivity.Include(x => x.ActivityMaster).Include(x => x.FileEntry.HblEntry).Select(x => new FileActivityDataList
                {
                    ActivityId = x.ActivityMaster.Name,
                    BasedOn = x.ActivityMaster.BasedOn,
                    Comment = x.Comment == null ? "" : x.Comment,
                    CurrentStatus = x.CurrentStatus,
                    EndTime = x.EndTime,
                    EnterDate = x.EnterDate,
                    CreatedDate = x.FileEntry.CreatedDate,
                    FileNo = x.FileEntry.FileNo,
                    ContainerNo = x.FileEntry.ContainerNo,
                    Id = x.FileId,
                    HBLId = x.FileEntry.HblEntry.Where(y => y.FileGuidId == x.FileId).Select(y => y.Id).FirstOrDefault(),
                    UserId = x.User.UserName,
                    hblCount = x.FileEntry.Hblcount,
                    StartTime = x.StartTime,
                    Activity = x.ActivityId,
                    hblNo = x.FileEntry.HblEntry.Where(y => y.FileGuidId == x.FileId).Select(y => y.Hblno).FirstOrDefault(),

                }).ToList();
            }

            totalRecord = fileEntryData.Count();

            IQueryable<FileActivityDataList> SortedData = fileEntryData.AsQueryable();
            if (!string.IsNullOrEmpty(fileNo))
            {
                SortedData = SortedData.Where(x => x.FileNo == fileNo.Trim());

            }

            if (!string.IsNullOrEmpty(containerNo))
            {
                SortedData = SortedData.Where(x => x.ContainerNo == containerNo.Trim());

            }

            if (!string.IsNullOrEmpty(hblNo))
            {
                SortedData = SortedData.Where(x => x.hblNo == hblNo.Trim());

            }

            if (!string.IsNullOrEmpty(activityType) && activityType != "all" && activityType != "--select--")
            {
                SortedData = SortedData.Where(x => x.BasedOn == activityType.Trim());

            }

            if (!string.IsNullOrEmpty(userid) && userid != "none" && userid != "--select--")
            {
                SortedData = SortedData.Where(x => x.UserId == userName.Trim());

            }

            if (!string.IsNullOrEmpty(activity) && activity != "none" && activity != "--Select--")
            {
                SortedData = SortedData.Where(x => x.ActivityId == activity.Trim());

            }

            if (!string.IsNullOrEmpty(status) && status != "none" && status != "--select--")
            {
                SortedData = SortedData.Where(x => x.CurrentStatus == status.Trim());

            }
            else
            {
                SortedData = SortedData.Where(x => x.CurrentStatus != "Completed".Trim());
            }

            if (sortColumn == "HBL")
            {
                sortColumn = "hblNo";
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();

            }
            else if (sortColumn == "activityName")
            {
                sortColumn = "activityId";
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            else if (sortColumn == "createdDate")
            {
                sortColumnDirection = "desc";
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            else if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
            {
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            else
            {
                sortColumn = "createdDate";
                sortColumnDirection = "desc";
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }

            var returnObj = new
            {
                draw = draw,
                recordsTotal = totalRecord,
                recordsFiltered = SortedData.Count(),
                data = SortedData,
                skip = skip,
                pageSize = pageSize,
            };

            return Json(returnObj);
        }


        public IActionResult GetActivityHBLData(string fileNo, string activityId, string status, string startDate)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

            var fileActivity = _ctx.FileActivity.Include(x => x.FileEntry).Where(x => x.FileEntry.FileNo == fileNo && x.ActivityId == activityId).FirstOrDefault();

            var hblEntry = _ctx.HblActivity.Include(x => x.HblEntry).Include(x => x.ActivityMaster).Include(x => x.User)
                            .Select(x => new HBLActivityDataList
                            {
                                Id = x.Id,
                                Hblno = x.HblEntry.Hblno,
                                FileGuidId = x.HblEntry.FileGuidId,
                                HBLId = x.HblId,
                                IsDap = x.HblEntry.IsDap == true ? "Yes" : "No",
                                CreatedDate = x.EnterDate,
                                BasedOn = x.ActivityMaster.BasedOn,
                                CreatedBy = x.HblEntry.User.UserName,
                                Comment = x.Comment == null ? "" : x.Comment,
                                CurrentStatus = x.CurrentStatus,
                                StartTime = x.StartTime,
                                EndTime = x.EndTime,
                                EnterBy = x.EnterBy,
                                ActivityId = x.ActivityMaster.Name,
                                Activity = x.ActivityId,
                            }).ToList();


            var HBLActivityMapId = _ctx.ActivityMapping.Include(x => x.FileActivityMaster).Where(x => x.FileActivityId == fileActivity.ActivityId).Select(x => x.HBLActivityId).FirstOrDefault();

            if (hblEntry != null)
            {
                hblEntry = hblEntry.Where(x => x.Activity == HBLActivityMapId && x.FileGuidId == fileActivity.FileId).ToList();
            }
            if (!string.IsNullOrEmpty(userid) && userid != "none" && userid != "--Select--")
            {
                hblEntry = hblEntry.Where(x => x.EnterBy == userid).ToList();
            }
            if (!string.IsNullOrEmpty(status) && status == "Completed")
            {
                hblEntry = hblEntry.Where(x => x.CurrentStatus == "Completed").ToList();
            }
            else
            {
                hblEntry = hblEntry.Where(x => x.CurrentStatus != "Completed").ToList();
            }


            return Json(hblEntry);
        }

        public IActionResult GetActivityType(string fileType)
        {

            ViewData["ActivityMaster"] = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.BasedOn == fileType && x.ThreadMaster.IsActive == true && x.IsActive == true).ToList();
            var activity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.BasedOn == fileType && x.ThreadMaster.IsActive == true && x.IsActive == true).ToList();

            return Json(activity);
        }

        [HttpPost]
        public IActionResult HBLSubmit(HBLActivityDataList model, string status, string comment, string startDate)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            HblActivity hblActivity = _ctx.HblActivity.Include(x => x.HblEntry).Include(x => x.ActivityMaster).Where(x => x.HblId == model.HBLId && x.ActivityId == model.Activity && x.ActivityMaster.BasedOn == model.BasedOn && x.ActivityMaster.IsActive == true ).FirstOrDefault();

            var hblActivityList = _ctx.HblActivity.Include(x => x.HblEntry).Where(x => x.HblEntry.FileGuidId == model.Id).ToList();

            if (model != null)
            {
                var hbllog = _ctx.HBLHistoryLog.Add(new HBLHistoryLog
                {

                    HBLActivityId = hblActivity.Id,
                    CurrentStatus = model.CurrentStatus,
                    Comment = model.Comment,
                    EnterBy = userid,
                    StartTime = model.StartTime,
                    EndTime = model.EndTime,
                    EnterDate = model.CreatedDate,
                    EnterStartDate = DateTime.UtcNow.AddMinutes(-2),
                    EnterEndDate = DateTime.UtcNow,

                });
                _ctx.SaveChanges();

                hblActivity.EnterBy = userid;
                hblActivity.CurrentStatus = status;
                hblActivity.Comment = comment;
                hblActivity.StartTime = Convert.ToDateTime(startDate).ToUniversalTime();
                hblActivity.EndTime = DateTime.Now.ToUniversalTime();
                _ctx.HblActivity.Update(hblActivity);
                _ctx.SaveChanges();

                if (model.FileGuidId != null)
                {
                    if (hblActivityList != null)
                    {
                        var HBLActivityMapId = _ctx.ActivityMapping.Include(x => x.FileActivityMaster).Where(x => x.FileActivityId == model.Activity).Select(x => x.HBLActivityId).FirstOrDefault();

                        var hblStatus = hblActivityList.Where(x => x.CurrentStatus != "Completed" && x.ActivityId == HBLActivityMapId).ToList().Count();
                        if (hblStatus == 0)
                        {
                            var fileActivity = _ctx.FileActivity.Where(x => x.FileId == model.Id && x.ActivityId == hblActivity.ActivityId).FirstOrDefault();
                            if (fileActivity != null)
                            {
                                fileActivity.UserId = userid;
                                fileActivity.CurrentStatus = "Completed";
                                fileActivity.Comment = "All Hbl in this file are completed.";
                                fileActivity.StartTime = Convert.ToDateTime(startDate).ToUniversalTime();
                                fileActivity.EndTime = DateTime.Now.ToUniversalTime();
                                _ctx.FileActivity.Update(fileActivity);
                                _ctx.SaveChanges();
                            }
                        }

                    }

                }
                return Json("Success");
            }
            else
            {
                return Json("Failed");

            }
        }

        [HttpPost]
        public IActionResult FileSubmit(FileActivityDataList model, string status, string comment, string startDate)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            FileActivity fileActivity = _ctx.FileActivity.Include(x => x.FileEntry).Include(x => x.ActivityMaster).ThenInclude(x => x.ThreadMaster).Where(x => x.FileId == model.Id.Trim() && x.ActivityId == model.Activity && x.ActivityMaster.ThreadMaster.IsActive == true && x.ActivityMaster.IsActive == true).FirstOrDefault();
            var hblActivityList = _ctx.HblActivity.ToList();

            if (model != null)
            {
                if (model.FileNo != null)
                {
                    if (fileActivity != null)
                    {
                        var HBLActivityMapId = _ctx.ActivityMapping.Include(x => x.FileActivityMaster).Where(x => x.FileActivityId == fileActivity.ActivityId).Select(x => x.HBLActivityId).FirstOrDefault();
                        if (HBLActivityMapId != null)
                        {

                            var hblStatus = hblActivityList.Where(x => x.CurrentStatus != "Completed" && x.ActivityId == HBLActivityMapId && x.EnterBy == userid).Count();
                            if (hblStatus == 0)
                            {
                                var hbllog = _ctx.FileHistoryLog.Add(new FileHistoryLog
                                {

                                    FileActivityId = fileActivity.Id,
                                    CurrentStatus = model.CurrentStatus,
                                    Comment = model.Comment,
                                    UserId = userid,
                                    StartTime = model.StartTime,
                                    EndTime = model.EndTime,
                                    EnterDate = model.EnterDate,
                                    EnterStartDate = DateTime.UtcNow.AddMinutes(-2),
                                    EnterEndDate = DateTime.UtcNow,


                                });
                                _ctx.SaveChanges();

                                var file = _ctx.FileActivity.Include(x => x.ActivityMaster).ThenInclude(x => x.ThreadMaster).Where(x => x.Id == fileActivity.Id && x.ActivityId == fileActivity.ActivityId && x.ActivityMaster.ThreadMaster.IsActive == true && x.ActivityMaster.IsActive == true).FirstOrDefault();
                                file.UserId = userid;
                                file.CurrentStatus = status;
                                file.Comment = comment;
                                file.StartTime = Convert.ToDateTime(startDate).ToUniversalTime();
                                file.EndTime = DateTime.Now.ToUniversalTime();
                                _ctx.FileActivity.Update(file);
                                _ctx.SaveChanges();

                            }
                            else
                            {
                                return Json("Please Update HBL in selected file");
                            }
                        }
                        else
                        {
                            return Json("MapActivity");
                        }
                    }

                }
                return Json("Success");
            }
            else
            {
                return Json("Failed");

            }
        }
        public DataTable ToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);
            //Get all the properties by using reflection   
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Setting column names as Property names  B
                dataTable.Columns.Add(prop.Name);
            }
            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {

                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }

            return dataTable;
        }

        public ActionResult Reports()
        {
            return View();
        }

        //Report download
        [HttpPost]
        public ActionResult Reports(ReportViewModel report)
        {
            //Main Report file and HBL also activity wise filelevel and hbllevel report
            //DataTable filedt = new DataTable();
            DataTable fileactivity = new DataTable();
            DataTable hblactivity = new DataTable();
            var fileactivtydata = new List<FileReportViewModel>();
            var fileactivtyHistory = new List<FileReportViewModel>();
            var HBLdata = new List<HBLReportViewModel>();
            var HBLHistory = new List<HBLReportViewModel>();
            var getFileActivityStatus = new List<FileActivityStatusList>();
            var getHBLActivityStatus = new List<HBLActivityStatusList>();
            //var fileActivityList = new List<FileActivityLog>();
            UserActivityStatusViewModel userActivityStatus = new UserActivityStatusViewModel();
            //var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var fileActivitys = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.IsActive == true && x.ThreadMaster.Name == "File").OrderBy(x => x.Name).ToList();
            var hblActivitys = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.IsActive == true && x.ThreadMaster.Name == "HBL").OrderBy(x => x.Name).ToList();
            var userList = _ctx.User.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CitrixId).ToList();
            //Adhoc Report 
            DataTable adhoc = new DataTable();
            DataTable adhocHBL = new DataTable();
            DataTable adhocfileActivity = new DataTable();
            DataTable adhochblActivity = new DataTable();
            var startDate = report.start_date;
            var endDate = report.end_date;
            IQueryable<User> udata = _ctx.Set<User>().AsQueryable();
            DataTable dt = new DataTable();
            DataTable dt1 = new DataTable();
            const string ISTTimeZoneId = "India Standard Time";
            var istTimeZone = TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId);
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);


            if (report.start_date != null && report.end_date != null)
            {
                if (report.ReportType == "File")
                {
                    //DataTable dt = new DataTable();
                    dt.Columns.Add("Pod");
                    dt.Columns.Add("EtaAtPod");
                    dt.Columns.Add("Received Date");
                    dt.Columns.Add("ContainerNo");
                    dt.Columns.Add("Pol");
                    dt.Columns.Add("FileType");
                    dt.Columns.Add("ProductType");
                    dt.Columns.Add("Hblcount");
                    dt.Columns.Add("IsEdi");
                    dt.Columns.Add("Activity");
                    dt.Columns.Add("Current Status");
                    dt.Columns.Add("Comment");
                    dt.Columns.Add("UserName");
                    dt.Columns.Add("Pages");
                    dt.Columns.Add("StartDate");
                    dt.Columns.Add("EndDate");
                    dt.Columns.Add("FileNo");
                    dt.Columns.Add("VesselName");
                    dt.Columns.Add("ShippingLine");

                    dt1.Columns.Add("Pod");
                    dt1.Columns.Add("EtaAtPod");
                    dt1.Columns.Add("Received Date");
                    dt1.Columns.Add("ContainerNo");
                    dt1.Columns.Add("Pol");
                    dt1.Columns.Add("FileType");
                    dt1.Columns.Add("ProductType");
                    dt1.Columns.Add("Hblcount");
                    dt1.Columns.Add("IsEdi");
                    dt1.Columns.Add("Activity");
                    dt1.Columns.Add("Current Status");
                    dt1.Columns.Add("Comment");
                    dt1.Columns.Add("UserName");
                    dt1.Columns.Add("Pages");
                    dt1.Columns.Add("StartDate");
                    dt1.Columns.Add("EndDate");
                    dt1.Columns.Add("FileNo");
                    dt1.Columns.Add("VesselName");
                    dt1.Columns.Add("ShippingLine");

                    //dt.Columns.Add("Received Date");
                    //dt.Columns.Add("File Number");
                    //dt.Columns.Add("Container Number");
                    //dt.Columns.Add("SI Cut Off");
                    //dt.Columns.Add("User");
                    //dt.Columns.Add("Activity");
                    //dt.Columns.Add("Status");
                    //dt.Columns.Add("Comment");
                    //dt.Columns.Add("ROE");


                    if (report.DateType == "ReceivedDate")
                    {
                        fileactivtydata = _ctx.FileActivity.Include(x => x.FileEntry).Include(x => x.User).Include(x => x.ActivityMaster).Where(x => x.UserId == userid && x.FileEntry.CreatedDate != null && x.FileEntry.CreatedDate.Value.Date >= startDate.Date &&
                                              x.FileEntry.CreatedDate.Value.Date <= endDate.Date)
                                              .Select(x => new FileReportViewModel
                                              {
                                                  POD = _ctx.LocationMaster.Where(y => y.Id == x.FileEntry.Pod).Select(y => y.Name).FirstOrDefault(),
                                                  ETA = x.FileEntry.EtaAtPod,
                                                  ReceivedDate = x.FileEntry.CreatedDate,
                                                  ContainerNo = x.FileEntry.ContainerNo,
                                                  POL = _ctx.POLMaster.Where(y => y.Id == x.FileEntry.Pol).Select(y => y.Name).FirstOrDefault(),
                                                  FileType = x.FileEntry.FileType,
                                                  ProductType = x.FileEntry.ProductType,
                                                  HBLCount = x.FileEntry.Hblcount,
                                                  IsEdi = x.FileEntry.IsEdi,
                                                  Activity = x.ActivityId != null ? x.ActivityMaster.Name : "",
                                                  Status = x.CurrentStatus != null ? x.CurrentStatus : "",
                                                  Comment = x.Comment != null ? x.Comment : "",
                                                  User = x.UserId != null ? x.User.CitrixId : "",
                                                  Pages = x.Pages,
                                                  StartDate = x.StartTime != null ? x.StartTime : (DateTime?)null,
                                                  EndDate = x.EndTime != null ? x.EndTime : (DateTime?)null,
                                                  FileNo = x.FileEntry.FileNo,
                                                  VesselName = x.FileEntry.VesselName,
                                                  ShippingLine = x.FileEntry.ShippingLine,
                                              }).ToList();
                        fileactivtydata = fileactivtydata.Select(x => new FileReportViewModel
                        {
                            POD = x.POD,
                            ETA = x.ETA.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETA.Value, istTimeZone) : (DateTime?)null,
                            ReceivedDate = x.ReceivedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ReceivedDate.Value, istTimeZone) : (DateTime?)null,
                            ContainerNo = x.ContainerNo,
                            POL = x.POL,
                            FileType = x.FileType,
                            ProductType = x.ProductType,
                            HBLCount = x.HBLCount,
                            IsEdi = x.IsEdi,
                            Activity = x.Activity,
                            Status = x.Status,
                            Comment = x.Comment,
                            User = x.User,
                            Pages = x.Pages,
                            StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
                            EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null,
                            FileNo = x.FileNo,
                            VesselName = x.VesselName,
                            ShippingLine = x.ShippingLine,
                        }).ToList();

                        fileactivtyHistory = _ctx.FileHistoryLog.Include(x => x.FileActivity).Include(x => x.FileActivity.FileEntry).Include(x => x.User).Include(x => x.FileActivity.ActivityMaster).Where(x => x.UserId == userid && x.FileActivity.FileEntry.CreatedDate != null && x.FileActivity.FileEntry.CreatedDate.Value.Date >= startDate.Date &&
                                             x.FileActivity.FileEntry.CreatedDate.Value.Date <= endDate.Date)
                                             .Select(x => new FileReportViewModel
                                             {
                                                 POD = _ctx.LocationMaster.Where(y => y.Id == x.FileActivity.FileEntry.Pod).Select(y => y.Name).FirstOrDefault(),
                                                 ETA = x.FileActivity.FileEntry.EtaAtPod,
                                                 ReceivedDate = x.FileActivity.FileEntry.CreatedDate,
                                                 ContainerNo = x.FileActivity.FileEntry.ContainerNo,
                                                 POL = _ctx.POLMaster.Where(y => y.Id == x.FileActivity.FileEntry.Pol).Select(y => y.Name).FirstOrDefault(),
                                                 FileType = x.FileActivity.FileEntry.FileType,
                                                 ProductType = x.FileActivity.FileEntry.ProductType,
                                                 HBLCount = x.FileActivity.FileEntry.Hblcount,
                                                 IsEdi = x.FileActivity.FileEntry.IsEdi,
                                                 Activity = x.FileActivity.ActivityId != null ? x.FileActivity.ActivityMaster.Name : "",
                                                 Status = x.CurrentStatus != null ? x.CurrentStatus : "",
                                                 Comment = x.Comment != null ? x.Comment : "",
                                                 User = x.UserId != null ? x.User.CitrixId : "",
                                                 Pages = x.FileActivity.Pages,
                                                 StartDate = x.StartTime != null ? x.StartTime : (DateTime?)null,
                                                 EndDate = x.EndTime != null ? x.EndTime : (DateTime?)null,
                                                 FileNo = x.FileActivity.FileEntry.FileNo,
                                                 VesselName = x.FileActivity.FileEntry.VesselName,
                                                 ShippingLine = x.FileActivity.FileEntry.ShippingLine,
                                             }).ToList();
                        fileactivtyHistory = fileactivtyHistory.Select(x => new FileReportViewModel
                        {
                            POD = x.POD,
                            ETA = x.ETA.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETA.Value, istTimeZone) : (DateTime?)null,
                            ReceivedDate = x.ReceivedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ReceivedDate.Value, istTimeZone) : (DateTime?)null,
                            ContainerNo = x.ContainerNo,
                            POL = x.POL,
                            FileType = x.FileType,
                            ProductType = x.ProductType,
                            HBLCount = x.HBLCount,
                            IsEdi = x.IsEdi,
                            Activity = x.Activity,
                            Status = x.Status,
                            Comment = x.Comment,
                            User = x.User,
                            Pages = x.Pages,
                            StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
                            EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null,
                            FileNo = x.FileNo,
                            VesselName = x.VesselName,
                            ShippingLine = x.ShippingLine,
                        }).ToList();

                        //fileactivity = ToDataTable(fileactivtydata);
                    }
                    else if ((report.DateType == "EndDate"))
                    {
                        fileactivtydata = _ctx.FileActivity.Include(x => x.FileEntry).Include(x => x.User).Include(x => x.ActivityMaster).Where(x => x.UserId == userid && x.EndTime != null && x.EndTime.Value.Date >= startDate.Date &&
                                             x.EndTime.Value.Date <= endDate.Date)
                                             .Select(x => new FileReportViewModel
                                             {
                                                 POD = _ctx.LocationMaster.Where(y => y.Id == x.FileEntry.Pod).Select(y => y.Name).FirstOrDefault(),
                                                 ETA = x.FileEntry.EtaAtPod,
                                                 ReceivedDate = x.FileEntry.CreatedDate,
                                                 ContainerNo = x.FileEntry.ContainerNo,
                                                 POL = _ctx.POLMaster.Where(y => y.Id == x.FileEntry.Pol).Select(y => y.Name).FirstOrDefault(),
                                                 FileType = x.FileEntry.FileType,
                                                 ProductType = x.FileEntry.ProductType,
                                                 HBLCount = x.FileEntry.Hblcount,
                                                 IsEdi = x.FileEntry.IsEdi,
                                                 Activity = x.ActivityId != null ? x.ActivityMaster.Name : "",
                                                 Status = x.CurrentStatus != null ? x.CurrentStatus : "",
                                                 Comment = x.Comment != null ? x.Comment : "",
                                                 User = x.UserId != null ? x.User.CitrixId : "",
                                                 Pages = x.Pages,
                                                 StartDate = x.StartTime != null ? x.StartTime : (DateTime?)null,
                                                 EndDate = x.EndTime != null ? x.EndTime : (DateTime?)null,
                                                 FileNo = x.FileEntry.FileNo,
                                                 VesselName = x.FileEntry.VesselName,
                                                 ShippingLine = x.FileEntry.ShippingLine,
                                             }).ToList();
                        fileactivtydata = fileactivtydata.Select(x => new FileReportViewModel
                        {
                            POD = x.POD,
                            ETA = x.ETA.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETA.Value, istTimeZone) : (DateTime?)null,
                            ReceivedDate = x.ReceivedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ReceivedDate.Value, istTimeZone) : (DateTime?)null,
                            ContainerNo = x.ContainerNo,
                            POL = x.POL,
                            FileType = x.FileType,
                            ProductType = x.ProductType,
                            HBLCount = x.HBLCount,
                            IsEdi = x.IsEdi,
                            Activity = x.Activity,
                            Status = x.Status,
                            Comment = x.Comment,
                            User = x.User,
                            Pages = x.Pages,
                            StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
                            EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null,
                            FileNo = x.FileNo,
                            VesselName = x.VesselName,
                            ShippingLine = x.ShippingLine,
                        }).ToList();

                        fileactivtyHistory = _ctx.FileHistoryLog.Include(x => x.FileActivity).Include(x => x.FileActivity.FileEntry).Include(x => x.User).Include(x => x.FileActivity.ActivityMaster).Where(x => x.UserId == userid && x.EnterEndDate != null && x.EnterEndDate.Value.Date >= startDate.Date &&
                                             x.EnterEndDate.Value.Date <= endDate.Date)
                                             .Select(x => new FileReportViewModel
                                             {
                                                 POD = _ctx.LocationMaster.Where(y => y.Id == x.FileActivity.FileEntry.Pod).Select(y => y.Name).FirstOrDefault(),
                                                 ETA = x.FileActivity.FileEntry.EtaAtPod,
                                                 ReceivedDate = x.FileActivity.FileEntry.CreatedDate,
                                                 ContainerNo = x.FileActivity.FileEntry.ContainerNo,
                                                 POL = _ctx.POLMaster.Where(y => y.Id == x.FileActivity.FileEntry.Pol).Select(y => y.Name).FirstOrDefault(),
                                                 FileType = x.FileActivity.FileEntry.FileType,
                                                 ProductType = x.FileActivity.FileEntry.ProductType,
                                                 HBLCount = x.FileActivity.FileEntry.Hblcount,
                                                 IsEdi = x.FileActivity.FileEntry.IsEdi,
                                                 Activity = x.FileActivity.ActivityId != null ? x.FileActivity.ActivityMaster.Name : "",
                                                 Status = x.CurrentStatus != null ? x.CurrentStatus : "",
                                                 Comment = x.Comment != null ? x.Comment : "",
                                                 User = x.UserId != null ? x.User.CitrixId : "",
                                                 Pages = x.FileActivity.Pages,
                                                 StartDate = x.StartTime != null ? x.StartTime : (DateTime?)null,
                                                 EndDate = x.EndTime != null ? x.EndTime : (DateTime?)null,
                                                 FileNo = x.FileActivity.FileEntry.FileNo,
                                                 VesselName = x.FileActivity.FileEntry.VesselName,
                                                 ShippingLine = x.FileActivity.FileEntry.ShippingLine,
                                             }).ToList();
                        fileactivtyHistory = fileactivtyHistory.Select(x => new FileReportViewModel
                        {
                            POD = x.POD,
                            ETA = x.ETA.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETA.Value, istTimeZone) : (DateTime?)null,
                            ReceivedDate = x.ReceivedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ReceivedDate.Value, istTimeZone) : (DateTime?)null,
                            ContainerNo = x.ContainerNo,
                            POL = x.POL,
                            FileType = x.FileType,
                            ProductType = x.ProductType,
                            HBLCount = x.HBLCount,
                            IsEdi = x.IsEdi,
                            Activity = x.Activity,
                            Status = x.Status,
                            Comment = x.Comment,
                            User = x.User,
                            Pages = x.Pages,
                            StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
                            EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null,
                            FileNo = x.FileNo,
                            VesselName = x.VesselName,
                            ShippingLine = x.ShippingLine,
                        }).ToList();

                        //fileactivity = ToDataTable(fileactivtydata);
                    }
                    else
                    {
                        fileactivtydata = _ctx.FileActivity.Include(x => x.FileEntry).Include(x => x.User).Include(x => x.ActivityMaster).Where(x => x.UserId == userid && x.StartTime != null && x.StartTime.Value.Date >= startDate.Date &&
                                             x.StartTime.Value.Date <= endDate.Date)
                                             .Select(x => new FileReportViewModel
                                             {
                                                 POD = _ctx.LocationMaster.Where(y => y.Id == x.FileEntry.Pod).Select(y => y.Name).FirstOrDefault(),
                                                 ETA = x.FileEntry.EtaAtPod,
                                                 ReceivedDate = x.FileEntry.CreatedDate,
                                                 ContainerNo = x.FileEntry.ContainerNo,
                                                 POL = _ctx.POLMaster.Where(y => y.Id == x.FileEntry.Pol).Select(y => y.Name).FirstOrDefault(),
                                                 FileType = x.FileEntry.FileType,
                                                 ProductType = x.FileEntry.ProductType,
                                                 HBLCount = x.FileEntry.Hblcount,
                                                 IsEdi = x.FileEntry.IsEdi,
                                                 Activity = x.ActivityId != null ? x.ActivityMaster.Name : "",
                                                 Status = x.CurrentStatus != null ? x.CurrentStatus : "",
                                                 Comment = x.Comment != null ? x.Comment : "",
                                                 User = x.UserId != null ? x.User.CitrixId : "",
                                                 Pages = x.Pages,
                                                 StartDate = x.StartTime != null ? x.StartTime : (DateTime?)null,
                                                 EndDate = x.EndTime != null ? x.EndTime : (DateTime?)null,
                                                 FileNo = x.FileEntry.FileNo,
                                                 VesselName = x.FileEntry.VesselName,
                                                 ShippingLine = x.FileEntry.ShippingLine,
                                             }).ToList();
                        fileactivtydata = fileactivtydata.Select(x => new FileReportViewModel
                        {
                            POD = x.POD,
                            ETA = x.ETA.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETA.Value, istTimeZone) : (DateTime?)null,
                            ReceivedDate = x.ReceivedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ReceivedDate.Value, istTimeZone) : (DateTime?)null,
                            ContainerNo = x.ContainerNo,
                            POL = x.POL,
                            FileType = x.FileType,
                            ProductType = x.ProductType,
                            HBLCount = x.HBLCount,
                            IsEdi = x.IsEdi,
                            Activity = x.Activity,
                            Status = x.Status,
                            Comment = x.Comment,
                            User = x.User,
                            Pages = x.Pages,
                            StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
                            EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null,
                            FileNo = x.FileNo,
                            VesselName = x.VesselName,
                            ShippingLine = x.ShippingLine,
                        }).ToList();

                        fileactivtyHistory = _ctx.FileHistoryLog.Include(x => x.FileActivity).Include(x => x.FileActivity.FileEntry).Include(x => x.User).Include(x => x.FileActivity.ActivityMaster).Where(x => x.UserId == userid && x.EnterStartDate != null && x.EnterStartDate.Value.Date >= startDate.Date &&
                                             x.EnterStartDate.Value.Date <= endDate.Date)
                                             .Select(x => new FileReportViewModel
                                             {
                                                 POD = _ctx.LocationMaster.Where(y => y.Id == x.FileActivity.FileEntry.Pod).Select(y => y.Name).FirstOrDefault(),
                                                 ETA = x.FileActivity.FileEntry.EtaAtPod,
                                                 ReceivedDate = x.FileActivity.FileEntry.CreatedDate,
                                                 ContainerNo = x.FileActivity.FileEntry.ContainerNo,
                                                 POL = _ctx.POLMaster.Where(y => y.Id == x.FileActivity.FileEntry.Pol).Select(y => y.Name).FirstOrDefault(),
                                                 FileType = x.FileActivity.FileEntry.FileType,
                                                 ProductType = x.FileActivity.FileEntry.ProductType,
                                                 HBLCount = x.FileActivity.FileEntry.Hblcount,
                                                 IsEdi = x.FileActivity.FileEntry.IsEdi,
                                                 Activity = x.FileActivity.ActivityId != null ? x.FileActivity.ActivityMaster.Name : "",
                                                 Status = x.CurrentStatus != null ? x.CurrentStatus : "",
                                                 Comment = x.Comment != null ? x.Comment : "",
                                                 User = x.UserId != null ? x.User.CitrixId : "",
                                                 Pages = x.FileActivity.Pages,
                                                 StartDate = x.StartTime != null ? x.StartTime : (DateTime?)null,
                                                 EndDate = x.EndTime != null ? x.EndTime : (DateTime?)null,
                                                 FileNo = x.FileActivity.FileEntry.FileNo,
                                                 VesselName = x.FileActivity.FileEntry.VesselName,
                                                 ShippingLine = x.FileActivity.FileEntry.ShippingLine,
                                             }).ToList();
                        fileactivtyHistory = fileactivtyHistory.Select(x => new FileReportViewModel
                        {
                            POD = x.POD,
                            ETA = x.ETA.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETA.Value, istTimeZone) : (DateTime?)null,
                            ReceivedDate = x.ReceivedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ReceivedDate.Value, istTimeZone) : (DateTime?)null,
                            ContainerNo = x.ContainerNo,
                            POL = x.POL,
                            FileType = x.FileType,
                            ProductType = x.ProductType,
                            HBLCount = x.HBLCount,
                            IsEdi = x.IsEdi,
                            Activity = x.Activity,
                            Status = x.Status,
                            Comment = x.Comment,
                            User = x.User,
                            Pages = x.Pages,
                            StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
                            EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null,
                            FileNo = x.FileNo,
                            VesselName = x.VesselName,
                            ShippingLine = x.ShippingLine,
                        }).ToList();

                        //fileactivity = ToDataTable(fileactivtydata);
                    }

                    DataTable dtt = ToDataTable(fileactivtydata);
                    DataTable dtt1 = ToDataTable(fileactivtyHistory);

                    foreach (DataRow item in dtt.Rows)
                    {
                        DataRow dr = dt.NewRow();
                        for (int i = 0; i < dtt.Columns.Count; i++)
                        {
                            dr[i] = item[i];

                        }
                        dt.Rows.Add(dr);
                    }

                    foreach (DataRow item in dtt1.Rows)
                    {
                        DataRow dr = dt1.NewRow();
                        for (int i = 0; i < dtt1.Columns.Count; i++)
                        {
                            dr[i] = item[i];

                        }
                        dt1.Rows.Add(dr);
                    }

                    string filename = "";
                    //filename = saveFile.FileName;
                    string apath = filename + ".xlsx";
                    using (XLWorkbook wb = new XLWorkbook())
                    {
                        dt.TableName = "File Data Report";
                        dt1.TableName = "File History Data Report";
                        var wsFileData = wb.Worksheets.Add(dt);
                        var wsFileData1 = wb.Worksheets.Add(dt1);
                        wsFileData.Columns().AdjustToContents();
                        wsFileData1.Columns().AdjustToContents();

                        try
                        {
                            using (MemoryStream stream = new MemoryStream())
                            {
                                wb.SaveAs(stream);
                                string excelname = $"FileDataReport-{DateTime.Now.ToString("ddMMyyyy hh:mm:ss")}.xlsx";
                                return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                            }

                            // System.Windows.Forms.MessageBox.Show("File Save Successfully.!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        catch (Exception ex)
                        {
                            // System.Windows.Forms.MessageBox.Show("Something went wrong.!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }

                }
                else if (report.ReportType == "HBL")
                {
                    dt.Columns.Add("Received Date");
                    dt.Columns.Add("FileNo");
                    dt.Columns.Add("ContainerNo");
                    dt.Columns.Add("HBLNo");
                    dt.Columns.Add("IsDap");
                    dt.Columns.Add("Activity");
                    dt.Columns.Add("Current Status");
                    dt.Columns.Add("Comment");
                    dt.Columns.Add("UserName");
                    dt.Columns.Add("StartDate");
                    dt.Columns.Add("EndDate");

                    dt1.Columns.Add("Received Date");
                    dt1.Columns.Add("FileNo");
                    dt1.Columns.Add("ContainerNo");
                    dt1.Columns.Add("HBLNo");
                    dt1.Columns.Add("IsDap");
                    dt1.Columns.Add("Activity");
                    dt1.Columns.Add("Current Status");
                    dt1.Columns.Add("Comment");
                    dt1.Columns.Add("UserName");
                    dt1.Columns.Add("StartDate");
                    dt1.Columns.Add("EndDate");

                    if (report.DateType == "ReceivedDate")
                    {
                        HBLdata = _ctx.HblActivity.Include(x => x.HblEntry).Include(x => x.HblEntry.FileGuid).Include(x => x.ActivityMaster).Include(x => x.User).Where(x => x.EnterBy == userid && x.HblEntry.CreatedDate != null && x.HblEntry.CreatedDate.Value.Date >= startDate.Date &&
                                  x.HblEntry.CreatedDate.Value.Date <= endDate.Date).Select(x => new HBLReportViewModel
                                  {
                                      ReceivedDate = x.HblEntry.CreatedDate,
                                      FileNo = x.HblEntry.FileGuid.FileNo,
                                      ContainerNo = x.HblEntry.FileGuid.ContainerNo,
                                      HBLNo = x.HblEntry.Hblno,
                                      IsDap = x.HblEntry.IsDap,
                                      Activity = x.ActivityMaster.Name,
                                      Status = x.CurrentStatus,
                                      Comment = x.Comment,
                                      User = x.User.CitrixId,
                                      StartDate = x.StartTime,
                                      EndDate = x.EndTime
                                  }).ToList();

                        HBLdata = HBLdata.Select(x => new HBLReportViewModel
                        {
                            ReceivedDate = x.ReceivedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ReceivedDate.Value, istTimeZone) : (DateTime?)null,
                            FileNo = x.FileNo,
                            ContainerNo = x.ContainerNo,
                            HBLNo = x.HBLNo,
                            IsDap = x.IsDap,
                            Activity = x.Activity,
                            Status = x.Status,
                            Comment = x.Comment,
                            User = x.User,
                            StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
                            EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null

                        }).ToList();

                        HBLHistory = _ctx.HBLHistoryLog.Include(x => x.HblActivity).Include(x => x.HblActivity.HblEntry).Include(x => x.HblActivity.HblEntry.FileGuid).Include(x => x.HblActivity.ActivityMaster).Include(x => x.User).Where(x => x.EnterBy == userid && x.HblActivity.HblEntry.CreatedDate != null && x.HblActivity.HblEntry.CreatedDate.Value.Date >= startDate.Date &&
                                  x.HblActivity.HblEntry.CreatedDate.Value.Date <= endDate.Date).Select(x => new HBLReportViewModel
                                  {
                                      ReceivedDate = x.HblActivity.HblEntry.CreatedDate,
                                      FileNo = x.HblActivity.HblEntry.FileGuid.FileNo,
                                      ContainerNo = x.HblActivity.HblEntry.FileGuid.ContainerNo,
                                      HBLNo = x.HblActivity.HblEntry.Hblno,
                                      IsDap = x.HblActivity.HblEntry.IsDap,
                                      Activity = x.HblActivity.ActivityMaster.Name,
                                      Status = x.CurrentStatus,
                                      Comment = x.Comment,
                                      User = x.User.CitrixId,
                                      StartDate = x.StartTime,
                                      EndDate = x.EndTime
                                  }).ToList();

                        HBLHistory = HBLHistory.Select(x => new HBLReportViewModel
                        {
                            ReceivedDate = x.ReceivedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ReceivedDate.Value, istTimeZone) : (DateTime?)null,
                            FileNo = x.FileNo,
                            ContainerNo = x.ContainerNo,
                            HBLNo = x.HBLNo,
                            IsDap = x.IsDap,
                            Activity = x.Activity,
                            Status = x.Status,
                            Comment = x.Comment,
                            User = x.User,
                            StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
                            EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null

                        }).ToList();

                        //hblactivity = ToDataTable(HBLdata);
                    }
                    else if (report.DateType == "EndDate")
                    {
                        HBLdata = _ctx.HblActivity.Include(x => x.HblEntry).Include(x => x.HblEntry.FileGuid).Include(x => x.ActivityMaster).Include(x => x.User).Where(x => x.EnterBy == userid && x.EndTime != null && x.EndTime.Value.Date >= startDate.Date &&
                                  x.EndTime.Value.Date <= endDate.Date).Select(x => new HBLReportViewModel
                                  {
                                      ReceivedDate = x.HblEntry.CreatedDate,
                                      FileNo = x.HblEntry.FileGuid.FileNo,
                                      ContainerNo = x.HblEntry.FileGuid.ContainerNo,
                                      HBLNo = x.HblEntry.Hblno,
                                      IsDap = x.HblEntry.IsDap,
                                      Activity = x.ActivityMaster.Name,
                                      Status = x.CurrentStatus,
                                      Comment = x.Comment,
                                      User = x.User.CitrixId,
                                      StartDate = x.StartTime,
                                      EndDate = x.EndTime
                                  }).ToList();

                        HBLdata = HBLdata.Select(x => new HBLReportViewModel
                        {
                            ReceivedDate = x.ReceivedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ReceivedDate.Value, istTimeZone) : (DateTime?)null,
                            FileNo = x.FileNo,
                            ContainerNo = x.ContainerNo,
                            HBLNo = x.HBLNo,
                            IsDap = x.IsDap,
                            Activity = x.Activity,
                            Status = x.Status,
                            Comment = x.Comment,
                            User = x.User,
                            StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
                            EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null

                        }).ToList();

                        HBLHistory = _ctx.HBLHistoryLog.Include(x => x.HblActivity).Include(x => x.HblActivity.HblEntry).Include(x => x.HblActivity.HblEntry.FileGuid).Include(x => x.HblActivity.ActivityMaster).Include(x => x.User).Where(x => x.EnterBy == userid && x.EnterEndDate != null && x.EnterEndDate.Value.Date >= startDate.Date &&
                                  x.EnterEndDate.Value.Date <= endDate.Date).Select(x => new HBLReportViewModel
                                  {
                                      ReceivedDate = x.HblActivity.HblEntry.CreatedDate,
                                      FileNo = x.HblActivity.HblEntry.FileGuid.FileNo,
                                      ContainerNo = x.HblActivity.HblEntry.FileGuid.ContainerNo,
                                      HBLNo = x.HblActivity.HblEntry.Hblno,
                                      IsDap = x.HblActivity.HblEntry.IsDap,
                                      Activity = x.HblActivity.ActivityMaster.Name,
                                      Status = x.CurrentStatus,
                                      Comment = x.Comment,
                                      User = x.User.CitrixId,
                                      StartDate = x.StartTime,
                                      EndDate = x.EndTime
                                  }).ToList();

                        HBLHistory = HBLHistory.Select(x => new HBLReportViewModel
                        {
                            ReceivedDate = x.ReceivedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ReceivedDate.Value, istTimeZone) : (DateTime?)null,
                            FileNo = x.FileNo,
                            ContainerNo = x.ContainerNo,
                            HBLNo = x.HBLNo,
                            IsDap = x.IsDap,
                            Activity = x.Activity,
                            Status = x.Status,
                            Comment = x.Comment,
                            User = x.User,
                            StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
                            EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null

                        }).ToList();

                        //hblactivity = ToDataTable(HBLdata);
                    }
                    else
                    {
                        HBLdata = _ctx.HblActivity.Include(x => x.HblEntry).Include(x => x.HblEntry.FileGuid).Include(x => x.ActivityMaster).Include(x => x.User).Where(x => x.EnterBy == userid && x.StartTime != null && x.StartTime.Value.Date >= startDate.Date &&
                                  x.StartTime.Value.Date <= endDate.Date).Select(x => new HBLReportViewModel
                                  {
                                      ReceivedDate = x.HblEntry.CreatedDate,
                                      FileNo = x.HblEntry.FileGuid.FileNo,
                                      ContainerNo = x.HblEntry.FileGuid.ContainerNo,
                                      HBLNo = x.HblEntry.Hblno,
                                      IsDap = x.HblEntry.IsDap,
                                      Activity = x.ActivityMaster.Name,
                                      Status = x.CurrentStatus,
                                      Comment = x.Comment,
                                      User = x.User.CitrixId,
                                      StartDate = x.StartTime,
                                      EndDate = x.EndTime
                                  }).ToList();

                        HBLdata = HBLdata.Select(x => new HBLReportViewModel
                        {
                            ReceivedDate = x.ReceivedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ReceivedDate.Value, istTimeZone) : (DateTime?)null,
                            FileNo = x.FileNo,
                            ContainerNo = x.ContainerNo,
                            HBLNo = x.HBLNo,
                            IsDap = x.IsDap,
                            Activity = x.Activity,
                            Status = x.Status,
                            Comment = x.Comment,
                            User = x.User,
                            StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
                            EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null

                        }).ToList();

                        HBLHistory = _ctx.HBLHistoryLog.Include(x => x.HblActivity).Include(x => x.HblActivity.HblEntry).Include(x => x.HblActivity.HblEntry.FileGuid).Include(x => x.HblActivity.ActivityMaster).Include(x => x.User).Where(x => x.EnterBy == userid && x.EnterStartDate != null && x.EnterStartDate.Value.Date >= startDate.Date &&
                                  x.EnterStartDate.Value.Date <= endDate.Date).Select(x => new HBLReportViewModel
                                  {
                                      ReceivedDate = x.HblActivity.HblEntry.CreatedDate,
                                      FileNo = x.HblActivity.HblEntry.FileGuid.FileNo,
                                      ContainerNo = x.HblActivity.HblEntry.FileGuid.ContainerNo,
                                      HBLNo = x.HblActivity.HblEntry.Hblno,
                                      IsDap = x.HblActivity.HblEntry.IsDap,
                                      Activity = x.HblActivity.ActivityMaster.Name,
                                      Status = x.CurrentStatus,
                                      Comment = x.Comment,
                                      User = x.User.CitrixId,
                                      StartDate = x.StartTime,
                                      EndDate = x.EndTime
                                  }).ToList();

                        HBLHistory = HBLHistory.Select(x => new HBLReportViewModel
                        {
                            ReceivedDate = x.ReceivedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ReceivedDate.Value, istTimeZone) : (DateTime?)null,
                            FileNo = x.FileNo,
                            ContainerNo = x.ContainerNo,
                            HBLNo = x.HBLNo,
                            IsDap = x.IsDap,
                            Activity = x.Activity,
                            Status = x.Status,
                            Comment = x.Comment,
                            User = x.User,
                            StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
                            EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null

                        }).ToList();

                        //hblactivity = ToDataTable(HBLdata);

                    }
                    DataTable dtt = ToDataTable(HBLdata);
                    DataTable dtt1 = ToDataTable(HBLHistory);

                    foreach (DataRow item in dtt.Rows)
                    {
                        DataRow dr = dt.NewRow();
                        for (int i = 0; i < dtt.Columns.Count; i++)
                        {
                            dr[i] = item[i];

                        }
                        dt.Rows.Add(dr);
                    }

                    foreach (DataRow item in dtt1.Rows)
                    {
                        DataRow dr = dt1.NewRow();
                        for (int i = 0; i < dtt1.Columns.Count; i++)
                        {
                            dr[i] = item[i];

                        }
                        dt1.Rows.Add(dr);
                    }

                    string filename = "";
                    string apath = filename + ".xlsx";
                    using (XLWorkbook wb = new XLWorkbook())
                    {
                        dt.TableName = "HBL Data Report";
                        dt1.TableName = "HBL History Data Report";
                        var wsFileData = wb.Worksheets.Add(dt);
                        var wsFileData1 = wb.Worksheets.Add(dt1);
                        wsFileData.Columns().AdjustToContents();
                        wsFileData1.Columns().AdjustToContents();

                        try
                        {
                            using (MemoryStream stream = new MemoryStream())
                            {
                                wb.SaveAs(stream);
                                string excelname = $"HBLDataReport-{DateTime.Now.ToString("ddMMyyyy hh:mm:ss")}.xlsx";
                                return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                            }
                        }
                        catch (Exception ex)
                        {

                        }
                    }

                }
            }
            else
            {
                ViewBag.ErrorMessage = "Please Select Date";
            }

            return View();
        }

    }
}
