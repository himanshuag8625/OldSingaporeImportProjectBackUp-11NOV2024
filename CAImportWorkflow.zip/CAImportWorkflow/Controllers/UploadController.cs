﻿using ClosedXML.Excel;
using DocumentFormat.OpenXml.Spreadsheet;
using CAImportWorkflow.Data;
using CAImportWorkflow.Models;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Drawing;
using System.Net;
using CAImportWorkflow;
using Microsoft.AspNetCore.Authorization;
using DocumentFormat.OpenXml.Office2010.Excel;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;


namespace CAImportWorkflow.Controllers
{
    public class UploadController : Controller
    {
        ApplicationDbContext _context;
        public UploadController(ApplicationDbContext context)
        {
            _context = context;
        }

        [Authorize(Roles = "Supervisor,Manager,Admin")]
        public IActionResult Index()
        {
            ViewData["Location"] = _context.LocationMaster.Where(x => x.IsActive == true).OrderBy(x => x.Name).ToList();
            ViewData["POL"] = _context.POLMaster.Where(x => x.IsActive == true).OrderBy(x => x.Name).ToList();
            return View(new UploadViewModel());
        }
        [Authorize(Roles = "Supervisor,Manager,Admin")]
        [HttpPost]
        public async Task<IActionResult> Index(UploadViewModel model)
        {


            if (ModelState.IsValid)
            {
                // Save the uploaded file to the server
                var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads", model.File.FileName);
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await model.File.CopyToAsync(stream);
                }
                var uploadResult = UploadFile(filePath);

                // Check if the UploadFile method was successful
                if (uploadResult is JsonResult && ((JsonResult)uploadResult).Value.ToString() == "success")
                {
                    return Json("success");
                }
                else
                {
                    return Json("error");
                }

            }
            else
            {
                return Json("Invalid file.");
                //return Json(new { success = false, message = "Invalid file." });
            }
            // Return a response to the client
        }

        [Authorize(Roles = "Supervisor,Manager,Admin")]
        public JsonResult UploadFile(string filePath)
        {
            DataTable Rawdata = new DataTable();
            List<FileEntry> filemaster = new List<FileEntry>();
            List<HblEntry> hBLMaster = new List<HblEntry>();
            List<FileActivity> fileActivityLog = new List<FileActivity>();
            //var carrierRequest = _context.ActivityMaster.FirstOrDefault(x => x.Name == "Carrier Request" && x.IsActive == true && x.IsDelete == false)?.Id;
            //var pending = _context.StatusMaster.FirstOrDefault(x => x.Status == "Pending" && x.IsActive == true && x.IsDelete == false)?.Id;
            DataTable UploadRawdata = GeneralFunction.GetDataFromExcel(filePath);
            var isfilepresent = _context.FileEntry.ToList();

            try
            {
                var filemasterdata = UploadRawdata.AsEnumerable().ToList();

                foreach (DataRow dr in filemasterdata)
                {
                    string containerNo = dr["Container No"].ToString().Trim();
                    //string[] parts = containerNo.Split('/');
                    string locationName = dr["Location"].ToString().Trim();
                    string polName = dr["POL"].ToString().Trim();
                    var duplicate = isfilepresent.FirstOrDefault(x => x.ContainerNo == containerNo);

                    var locationId = _context.LocationMaster
                        .FirstOrDefault(x => x.Name == locationName && x.IsActive == true)?.Id;
                    var polId = _context.POLMaster
                        .FirstOrDefault(x => x.Name == polName && x.IsActive == true)?.Id;

                    if (duplicate == null)
                    {
                        try
                        {
                            FileEntry filemas = InsertIntoDB(dr, locationName, polName, polId, locationId);
                            filemaster.Add(filemas);
                        }
                        catch (Exception ex)
                        {
                            return Json("error");
                        }
                    }
                    else
                    {
                        try
                        {
                            UpdateFileMaster(duplicate, dr, locationName, polName, polId, locationId);
                        }
                        catch (Exception ex)
                        {
                            return Json("error");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return Json("error");
            }

            _context.FileEntry.AddRange (filemaster);
            _context.SaveChanges();

            //var fileList = _context.FileEntry.ToList();

            //var activityMasterQuery = _context.ActivityMaster
            //    .Include(x => x.ThreadMaster)
            //    .Where(x => x.BasedOn == "File" && x.ThreadMaster.Name == "HBL User" && x.ThreadMaster.IsActive == true && x.IsActive == true);
            //var activities = activityMasterQuery.ToList();

            //foreach (var item in fileList)
            //{
            //    var filelog = _context.FileActivity.FirstOrDefault(x => x.FileId == item.Id);

            //    if (filelog == null)
            //    {
            //        foreach (var activity in activities)
            //        {
            //            var filelogs = _context.FileActivity.FirstOrDefault(x => x.FileId == item.Id && x.ActivityId == activity.Id);
            //            if (filelogs == null)
            //            {
            //                _context.FileActivity.Add(new FileActivity
            //                {
            //                    Id = Guid.NewGuid().ToString(),
            //                    FileId = item.Id,
            //                    ActivityId = activity.Id,
            //                    CurrentStatus = "WIP",
            //                    UserId = item.AllocatedTo != null ? item.AllocatedTo : null,
            //                    EnterDate = DateTime.UtcNow,
            //                });
            //                _context.SaveChanges();
            //            }
            //            else
            //            {
            //                filelogs.FileId = item.Id;
            //                filelogs.ActivityId = activity.Id;
            //                //filelogs.CurrentStatus = item.Status != null ? item.Status : "WIP"; // assuming you want to update the status
            //                //filelogs.UserId = item.AllocatedTo != null ? item.AllocatedTo : null;
            //                //filelogs.EnterDate = filelog.EnterDate != null ? filelog.EnterDate : (DateTime?)null;
            //            }
            //            _context.FileActivity.Update(filelogs);
            //        }
            //    }
            //    else
            //    {
            //        foreach (var activity in activities)
            //        {
            //            var filelogs = _context.FileActivity.FirstOrDefault(x => x.FileId == item.Id && x.ActivityId == activity.Id);
            //            if(filelogs == null)
            //            {
            //                _context.FileActivity.Add(new FileActivity
            //                {
            //                    Id = Guid.NewGuid().ToString(),
            //                    FileId = item.Id,
            //                    ActivityId = activity.Id,
            //                    CurrentStatus = "WIP",
            //                    UserId = item.AllocatedTo != null ? item.AllocatedTo : null,
            //                    EnterDate = DateTime.UtcNow,
            //                });
            //                _context.SaveChanges();
            //            }
            //            else
            //            {
            //                filelogs.FileId = item.Id;
            //                filelogs.ActivityId = activity.Id;
            //                //filelogs.CurrentStatus = item.Status != null ? item.Status : "WIP"; // assuming you want to update the status
            //                //filelogs.UserId = item.AllocatedTo != null ? item.AllocatedTo : null;
            //                //filelogs.EnterDate = filelog.EnterDate != null ? filelog.EnterDate : (DateTime?)null;
            //            }


            //            _context.FileActivity.Update(filelogs);
            //        }
            //    }
            //}

            //_context.SaveChanges();

            //return Json("success");

            var fileList = _context.FileEntry.ToList();

            var activityMasterQuery = _context.ActivityMaster
                .Include(x => x.ThreadMaster)
                .Where(x => x.BasedOn == "File" && x.ThreadMaster.Name == "HBL User" && x.ThreadMaster.IsActive == true && x.IsActive == true);
            var activities = activityMasterQuery.ToList();

            foreach (var item in fileList)
            {
                var filelog = _context.FileActivity.FirstOrDefault(x => x.FileId == item.Id);

                foreach (var activity in activities)
                {
                    var filelogs = _context.FileActivity.FirstOrDefault(x => x.FileId == item.Id && x.ActivityId == activity.Id);

                    if (filelogs == null)
                    {
                        _context.FileActivity.Add(new FileActivity
                        {
                            Id = Guid.NewGuid().ToString(),
                            FileId = item.Id,
                            ActivityId = activity.Id,
                            CurrentStatus = "WIP",
                            UserId = item.AllocatedTo, // Simplified null handling since it's already a nullable type
                            EnterDate = DateTime.UtcNow
                        });
                    }
                    else
                    {
                        filelogs.FileId = item.Id;
                        filelogs.ActivityId = activity.Id;
                        // Uncomment if you want to update these fields based on the latest filelog
                        //filelogs.CurrentStatus = item.Status ?? "WIP"; // Null-coalescing operator to handle null values
                        //filelogs.UserId = item.AllocatedTo;
                        //filelogs.EnterDate = filelog.EnterDate ?? (DateTime?)null;
                        _context.FileActivity.Update(filelogs);
                    }
                }
            }

            _context.SaveChanges();

            return Json("success");


            //return Json("success");
        }

        [Authorize(Roles = "Supervisor,Manager,Admin")]
        public FileEntry InsertIntoDB(DataRow dr, string locationName, string polName, string polId, string locationId)
        {
            var location = _context.LocationMaster.FirstOrDefault(x => x.Name == locationName && x.IsActive == true);
            var pol = _context.POLMaster.FirstOrDefault(x => x.Name == polName && x.IsActive == true);
            var userId = _context.User.FirstOrDefault(x => x.CitrixId == dr["Allocated To"].ToString().Trim() && x.IsActive == true && x.IsDelete == false)?.Id; 

            if (location == null)
            {
                location = new LocationMaster
                {
                    Name = locationName,
                    IsActive = true
                };

                _context.LocationMaster.Add(location);
                _context.SaveChanges();
            }
            else
            {
                location.Name = locationName;
            }

            if (pol == null)
            {
                pol = new POLMaster
                {
                    Name = polName,
                    IsActive = true
                };

                _context.POLMaster.Add(pol);
                _context.SaveChanges();
            }
            else
            {
                pol.Name = polName;
            }

            var efile = new FileEntry
            {
                Id = Guid.NewGuid().ToString(),
                CreatedDate = Convert.ToDateTime(dr["Received Date"]).ToUniversalTime() != null ? Convert.ToDateTime(dr["Received Date"]).ToUniversalTime() : DateTime.UtcNow,
                FileNo = dr["File No"].ToString().Trim(),
                ContainerNo = dr["Container No"].ToString().Trim(),
                EtaAtPod = Convert.ToDateTime(dr["ETA"]).ToUniversalTime(),
                Pod = location.Id,
                Pol = pol.Id,
                FileType = dr["File Type"].ToString().Trim(),
                ProductType = dr["Product Type"].ToString().Trim(),
                Hblcount = dr["HBL Count"].ToString().Trim() == "" ? "0" : dr["HBL Count"].ToString().Trim(),
                IsEdi = dr["IsEdi"].ToString().Trim().ToLower() == "yes" ? true : false,
                AllocatedTo = userId != null ? userId : null,
            };

            return efile;
        }

        private void UpdateFileMaster(FileEntry duplicate, DataRow dr, string locationName, string polName, string polId, string locationId)
        {
            var userId = _context.User.FirstOrDefault(x => x.CitrixId == dr["Allocated To"].ToString().Trim() && x.IsActive == true && x.IsDelete == false)?.Id;

            duplicate.CreatedDate = Convert.ToDateTime(dr["Received Date"]).ToUniversalTime() != null ? Convert.ToDateTime(dr["Received Date"]).ToUniversalTime() : DateTime.UtcNow;
            duplicate.FileNo = dr["File No"].ToString().Trim();
            duplicate.ContainerNo = dr["Container No"].ToString().Trim();
            duplicate.EtaAtPod = Convert.ToDateTime(dr["ETA"]).ToUniversalTime();
            duplicate.Pod = locationId;
            duplicate.Pol = polId;
            duplicate.FileType = dr["File Type"].ToString().Trim();
            duplicate.ProductType = dr["Product Type"].ToString().Trim();
            duplicate.Hblcount = dr["HBL Count"].ToString().Trim() == "" ? "0" : dr["HBL Count"].ToString().Trim();
            duplicate.IsEdi = dr["IsEdi"].ToString().Trim().ToLower() == "yes" ? true : false;
            duplicate.AllocatedTo = userId != null ? userId : null;

            _context.FileEntry.Update(duplicate);
        }
    }
}
