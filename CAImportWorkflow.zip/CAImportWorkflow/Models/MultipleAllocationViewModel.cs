﻿namespace CAImportWorkflow.Models
{
    public class MultipleAllocationViewModel
    {
        public string uname { get; set; }
        public List<MultiSelectViewModel> multiSelectViewModels { get; set; }
    }
    public class MultiSelectViewModel
    {
        public string? eId { get; set; }
       
    }
}
