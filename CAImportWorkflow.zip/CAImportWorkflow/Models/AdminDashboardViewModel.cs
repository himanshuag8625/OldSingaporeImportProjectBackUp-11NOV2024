﻿using CAImportWorkflow.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CAImportWorkflow.Models
{
    public class AdminDashboardViewModel
    {
        public string? Id { get; set; }
        public string? FileNo { get; set; }
        public string? ContainerNo { get; set; }
        public string? IsEdi { get; set; }
        public string? Pol { get; set; }
        public string? Pod { get; set; }
        public string? FileType { get; set; }
        public string? ProductType { get; set; }
        public string? Hblcount { get; set; }
        public DateTime? EtaAtPod { get; set; }
        public string? VesselName { get; set; }
        public string? ThreadName { get; set; }
        public string? ShippingLine { get; set; }
        public string? Status { get; set; }
        public string? AllocatedTo { get; set; }
        public DateTime? CreatedDate { get; set; }
    }
}
