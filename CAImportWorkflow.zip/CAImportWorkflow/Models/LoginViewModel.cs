﻿using System.ComponentModel.DataAnnotations;

namespace CAImportWorkflow.Models
{
	public class LoginViewModel
	{
		[Required]
		public string CitrixId { get; set; }

		[Required]
		[DataType(DataType.Password)]
		public string Password { get; set; }

	}
}
