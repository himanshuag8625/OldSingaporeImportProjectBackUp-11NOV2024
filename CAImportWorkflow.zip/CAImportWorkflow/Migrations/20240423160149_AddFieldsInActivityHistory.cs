﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CAImportWorkflow.Migrations
{
    public partial class AddFieldsInActivityHistory : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<DateTime>(
                name: "EnterEndDate",
                table: "HBLHistoryLog",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "EnterStartDate",
                table: "HBLHistoryLog",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "EnterEndDate",
                table: "FileHistoryLog",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "EnterStartDate",
                table: "FileHistoryLog",
                type: "datetime2",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "EnterEndDate",
                table: "HBLHistoryLog");

            migrationBuilder.DropColumn(
                name: "EnterStartDate",
                table: "HBLHistoryLog");

            migrationBuilder.DropColumn(
                name: "EnterEndDate",
                table: "FileHistoryLog");

            migrationBuilder.DropColumn(
                name: "EnterStartDate",
                table: "FileHistoryLog");
        }
    }
}
