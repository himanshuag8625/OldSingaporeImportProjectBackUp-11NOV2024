﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CAImportWorkflow.Migrations
{
    public partial class ActivityMapping : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ActivityMapping",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    FileActivityId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    HBLActivityId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ActivityMapping", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ActivityMapping_ActivityMaster_FileActivityId",
                        column: x => x.FileActivityId,
                        principalTable: "ActivityMaster",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.NoAction);
                    table.ForeignKey(
                        name: "FK_ActivityMapping_ActivityMaster_HBLActivityId",
                        column: x => x.HBLActivityId,
                        principalTable: "ActivityMaster",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateIndex(
                name: "IX_ActivityMapping_FileActivityId",
                table: "ActivityMapping",
                column: "FileActivityId");

            migrationBuilder.CreateIndex(
                name: "IX_ActivityMapping_HBLActivityId",
                table: "ActivityMapping",
                column: "HBLActivityId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ActivityMapping");
        }
    }
}
