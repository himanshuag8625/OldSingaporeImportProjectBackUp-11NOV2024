﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CAImportWorkflow.Migrations
{
    public partial class Historylogchange : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_FileHistoryLog_ActivityMaster_ActivityId",
                table: "FileHistoryLog");

            migrationBuilder.DropIndex(
                name: "IX_FileHistoryLog_ActivityId",
                table: "FileHistoryLog");

            migrationBuilder.DropColumn(
                name: "ActivityId",
                table: "HBLHistoryLog");

            migrationBuilder.DropColumn(
                name: "ActivityId",
                table: "FileHistoryLog");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "ActivityId",
                table: "HBLHistoryLog",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "ActivityId",
                table: "FileHistoryLog",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_FileHistoryLog_ActivityId",
                table: "FileHistoryLog",
                column: "ActivityId");

            migrationBuilder.AddForeignKey(
                name: "FK_FileHistoryLog_ActivityMaster_ActivityId",
                table: "FileHistoryLog",
                column: "ActivityId",
                principalTable: "ActivityMaster",
                principalColumn: "Id");
        }
    }
}
