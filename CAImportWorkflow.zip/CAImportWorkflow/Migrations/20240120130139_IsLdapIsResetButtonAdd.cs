﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CAImportWorkflow.Migrations
{
    public partial class IsLdapIsResetButtonAdd : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "IsLDAP",
                table: "AspNetUsers",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "IsReset",
                table: "AspNetUsers",
                type: "bit",
                nullable: false,
                defaultValue: false);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsLDAP",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "IsReset",
                table: "AspNetUsers");
        }
    }
}
