﻿using System.DirectoryServices;

namespace CAImportWorkflow.LDAP
{
    public class LdapAuthentication: IDisposable
    {
        private readonly LdapAuthenticationOptions _options;
        private readonly LdapOptions _ldapOptions;

        //private readonly LdapConnection _connection;
        private bool _isDisposed = false;

        /// <summary>
        /// Initializes a new instance with the the given options.
        /// </summary>
        /// <param name="options"></param>
        public LdapAuthentication(LdapAuthenticationOptions options, LdapOptions ldapOptions/*, IConfiguration configuration*/)
        {
            _options = options;
            _ldapOptions = ldapOptions;
            //_connection = new LdapConnection();
        }

        /// <summary>
        /// Cleans up any connections and other resources.
        /// </summary>
        public void Dispose()
		{
			if (_isDisposed)
			{
				return;
			}

			//_connection.Dispose();
			_isDisposed = true;
		}
		public bool ValidatePassword(string distinguishedName, string password)
		{
			
			//remove in Production	   

			if (distinguishedName.ToLower() == "tusharp" || distinguishedName.ToLower() == "deepaks" || distinguishedName.ToLower() == "rahulw" || distinguishedName.ToLower() == "vaibhava" || distinguishedName.ToLower() == "ravindram" || distinguishedName.ToLower() == "supervisor" || distinguishedName.ToLower() == "himanshua" || distinguishedName.ToLower().Contains("user"))
			{
				return true;
			}
			string ldap1 = "LDAP://10.90.30.1:389/DC=AM,DC=ECULINE,DC=NET";
			string ldap2 = "LDAP://10.1.30.1:389/DC=EU,DC=ECULINE,DC=NET";


            //if (AuthenticateAndGetUserDataFromAD(distinguishedName, "AM", password, ldap1))
            //{
            //	return true;

            //}
            //else if (AuthenticateAndGetUserDataFromAD(distinguishedName, "EU", password, ldap2))
            //{
            //	return true;
            //}
            //         else
            //         {
            string region = _ldapOptions.lDapRegion.ToString().ToUpper();
            foreach (var ldapConfig in _ldapOptions.LdapConfigurations.Where(x => x.Name == region))
            {
                string ldapConnection = $"LDAP://{ldapConfig.Server}:{ldapConfig.Port}/DC={ldapConfig.Domain},DC={ldapConfig.SubDomain},DC={ldapConfig.DomainCode}";

                if (AuthenticateAndGetUserDataFromAD(distinguishedName, ldapConfig.Name, password, ldapConnection))
                {
                    return true;
                }
            }
            //}

            return false;
		}
		public bool AuthenticateAndGetUserDataFromAD(string strusername, string strDomain, string strPassword, string LdapConnection)
		{
            string strRootDN = string.Empty;
            DirectoryEntry objDseSearchRoot = null, objDseUserEntry = null;
            DirectorySearcher objDseSearcher = null;
            SearchResultCollection objResults = null;
            string strLDAPPath = string.Empty;
            try
            {
                /* Give LDAP Server IP along with OU
                 * e.g : LDAP://29.29.29.29:389/DC=YourDomain,DC=com"
                 */
                strLDAPPath = LdapConnection;// "Your LDAP ServerPath";
                string strDomainname = strDomain;
                objDseSearchRoot = new DirectoryEntry(strLDAPPath, strDomainname + "\\" + strusername, strPassword, AuthenticationTypes.None);
                strRootDN = objDseSearchRoot.Properties["defaultNamingContext"].Value as string;
                objDseSearcher = new DirectorySearcher(objDseSearchRoot);
                objDseSearcher.CacheResults = false;
                objResults = objDseSearcher.FindAll();
                if (objResults.Count > 0)
                {
                    objDseUserEntry = objResults[0].GetDirectoryEntry();
                }

                if (objDseUserEntry == null)
                {

                    return false;
                }
            }

            catch (Exception e)
            {

                return false; ;
            }
            finally
            {
                //Dipose Object Over Here
            }

            return true;
		}
	}
}
